<?php

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found.\n");
}

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/mail.php';

$daysValue = getenv('PETCARE_REMINDER_DAYS');
if ($daysValue === false || $daysValue === '') {
    $daysValue = '7';
}
if (!ctype_digit($daysValue) || (int) $daysValue > 365) {
    throw new InvalidArgumentException('PETCARE_REMINDER_DAYS must be between 0 and 365.');
}
$daysAhead = (int) $daysValue;
$connection = db();
$dueQuery = $connection->prepare(
    'SELECT r.id
     FROM reminders r
     INNER JOIN users u ON u.user_id = r.user_id
     INNER JOIN settings s ON s.user_id = u.user_id
     WHERE r.status = \'pending\' AND r.is_done = 0
       AND r.last_notified_at IS NULL
       AND r.remind_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :days_ahead DAY)
       AND s.notifications_enabled = 1
     ORDER BY r.remind_date, r.id'
);
$dueQuery->bindValue(':days_ahead', $daysAhead, PDO::PARAM_INT);
$dueQuery->execute();
$reminderIds = $dueQuery->fetchAll(PDO::FETCH_COLUMN);

$sentCount = 0;
$failedCount = 0;
foreach ($reminderIds as $reminderId) {
    $connection->beginTransaction();
    try {
        $reminderQuery = $connection->prepare(
            'SELECT r.id, r.remind_date, r.message, u.email, u.name AS user_name,
                    p.name AS pet_name, v.vaccine_name
             FROM reminders r
             INNER JOIN users u ON u.user_id = r.user_id
             INNER JOIN settings s ON s.user_id = u.user_id
             INNER JOIN pets p ON p.pet_id = r.pet_id
             LEFT JOIN vaccinations v ON v.vaccination_id = r.vaccine_id
             WHERE r.id = :id AND r.status = \'pending\' AND r.is_done = 0
               AND r.last_notified_at IS NULL
               AND r.remind_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :days_ahead DAY)
               AND s.notifications_enabled = 1
             LIMIT 1 FOR UPDATE'
        );
        $reminderQuery->bindValue(':id', (int) $reminderId, PDO::PARAM_INT);
        $reminderQuery->bindValue(':days_ahead', $daysAhead, PDO::PARAM_INT);
        $reminderQuery->execute();
        $reminder = $reminderQuery->fetch();
        if (!$reminder) {
            $connection->commit();
            continue;
        }

        $vaccineName = $reminder['vaccine_name'] ?? 'General reminder';
        $message = sprintf(
            "Hello %s,\n\n%s\nPet: %s\nVaccine: %s\nDue date: %s\n\nView your reminders: %s",
            $reminder['user_name'],
            $reminder['message'],
            $reminder['pet_name'],
            $vaccineName,
            $reminder['remind_date'],
            petCarePublicBaseUrl() . appUrl('/php/reminders.php')
        );
        if (sendPetCareMail((string) $reminder['email'], 'PetCare Log vaccination reminder', $message)) {
            $markNotified = $connection->prepare(
                'UPDATE reminders SET last_notified_at = NOW()
                 WHERE id = :id AND last_notified_at IS NULL'
            );
            $markNotified->execute(['id' => $reminder['id']]);
            if ($markNotified->rowCount() !== 1) {
                throw new RuntimeException('The reminder notification could not be recorded.');
            }
            $sentCount++;
        } else {
            $failedCount++;
        }
        $connection->commit();
    } catch (Throwable $exception) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $exception;
    }
}

printf("Reminder emails sent: %d; failed: %d.\n", $sentCount, $failedCount);
if ($failedCount > 0) {
    exit(1);
}
