<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/auth.php';
$userId = requireLogin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Method not allowed.');
}

verifyCsrfToken();
$hasTheme = array_key_exists('theme', $_POST);
$hasLanguage = array_key_exists('language', $_POST);
$theme = (string) ($_POST['theme'] ?? '');
$language = (string) ($_POST['language'] ?? '');
if (!$hasTheme && !$hasLanguage) {
    http_response_code(422);
    exit('A theme or language value is required.');
}
if ($hasTheme && !in_array($theme, ['light', 'dark'], true)) {
    http_response_code(422);
    exit('Invalid theme value.');
}
if ($hasLanguage && !in_array($language, ['en-US', 'en-GB', 'es-ES', 'fr-CA', 'de-DE', 'tl-PH'], true)) {
    http_response_code(422);
    exit('Invalid language value.');
}

if ($hasTheme && $hasLanguage) {
    db()->prepare(
        'INSERT INTO settings (user_id, theme, language)
         VALUES (:user_id, :theme, :language)
         ON DUPLICATE KEY UPDATE theme = VALUES(theme), language = VALUES(language)'
    )->execute(['user_id' => $userId, 'theme' => $theme, 'language' => $language]);
} elseif ($hasTheme) {
    db()->prepare(
        'INSERT INTO settings (user_id, theme)
         VALUES (:user_id, :theme)
         ON DUPLICATE KEY UPDATE theme = VALUES(theme)'
    )->execute(['user_id' => $userId, 'theme' => $theme]);
} else {
    db()->prepare(
        'INSERT INTO settings (user_id, language)
         VALUES (:user_id, :language)
         ON DUPLICATE KEY UPDATE language = VALUES(language)'
    )->execute(['user_id' => $userId, 'language' => $language]);
}
if ($hasTheme) {
    $_SESSION['theme'] = $theme;
}
if ($hasLanguage) {
    $_SESSION['language'] = $language;
}
http_response_code(204);
