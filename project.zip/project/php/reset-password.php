<?php

require_once __DIR__ . '/../config/auth.php';
startPetCareSession();
preventAuthPageCaching();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Method not allowed.');
}

verifyCsrfToken();
$token = (string) ($_POST['token'] ?? '');
$password = (string) ($_POST['password'] ?? '');
$confirmation = (string) ($_POST['confirm_password'] ?? '');
if (!preg_match('/^[a-f0-9]{64}$/', $token) || !isValidPasswordLength($password) || $password !== $confirmation) {
    header('Location: ' . appUrl('/html/reset-password.php?token=' . rawurlencode($token) . '&error=1'));
    exit;
}

$connection = db();
$connection->beginTransaction();
try {
    $query = $connection->prepare(
        'SELECT password_reset_id, user_id FROM password_resets
         WHERE token_hash = :token_hash AND used_at IS NULL AND expires_at > NOW()
         LIMIT 1 FOR UPDATE'
    );
    $query->execute(['token_hash' => hash('sha256', $token)]);
    $reset = $query->fetch();
    if (!$reset) {
        $connection->rollBack();
        header('Location: ' . appUrl('/html/reset-password.php?error=1'));
        exit;
    }

    $connection->prepare(
        'UPDATE users SET password = :password WHERE user_id = :user_id'
    )->execute([
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'user_id' => $reset['user_id'],
    ]);
    $connection->prepare('UPDATE password_resets SET used_at = NOW() WHERE password_reset_id = :id')
        ->execute(['id' => $reset['password_reset_id']]);
    $connection->commit();
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }
    throw $exception;
}

header('Location: ' . appUrl('/html/login.php?reset=1'));
exit;
