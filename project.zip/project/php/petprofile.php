<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/pet-photo-upload.php';
$userId = requireUserAccess();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $petId = filter_var($_POST['pet_id'] ?? null, FILTER_VALIDATE_INT);
    if ($petId === false || $petId === null || $petId < 1) {
        redirectAfterPost(appUrl('/php/petprofile.php?error=1'));
    }

    $pet = findOwnedPet($userId, (string) $petId);
    if ($pet === null) {
        http_response_code(404);
        exit('Pet not found.');
    }

    $action = (string) ($_POST['action'] ?? '');
    if ($action === 'delete_pet') {
        $connection = db();
        $connection->beginTransaction();
        try {
            $connection->prepare('DELETE FROM reminders WHERE pet_id = :pet_id AND user_id = :user_id')
                ->execute(['pet_id' => $petId, 'user_id' => $userId]);
            $connection->prepare('DELETE FROM vaccinations WHERE pet_id = :pet_id')
                ->execute(['pet_id' => $petId]);
            $connection->prepare('DELETE FROM pets WHERE pet_id = :pet_id AND user_id = :user_id')
                ->execute(['pet_id' => $petId, 'user_id' => $userId]);
            $connection->commit();
        } catch (Throwable $exception) {
            if ($connection->inTransaction()) {
                $connection->rollBack();
            }
            throw $exception;
        }
        deletePetPhoto($pet['photo'] ?? null);
        redirectAfterPost(appUrl('/php/petprofile.php?deleted=1'));
    }

    if ($action !== 'save_pet') {
        redirectAfterPost(appUrl('/php/petprofile.php?error=1'));
    }

    $name = trim((string) ($_POST['name'] ?? ''));
    $species = trim((string) ($_POST['species'] ?? ''));
    $breed = trim((string) ($_POST['breed'] ?? '')) ?: null;
    $birthDate = trim((string) ($_POST['birthdate'] ?? ''));
    if ($name === '' || strlen($name) > 100 || $species === '' || strlen($species) > 50
        || ($breed !== null && strlen($breed) > 100)
        || ($birthDate !== '' && !isDateOnOrBeforeToday($birthDate))) {
        redirectAfterPost(appUrl('/php/petprofile.php?error=1'));
    }

    try {
        $photo = receivePetPhoto();
    } catch (RuntimeException $exception) {
        redirectAfterPost(appUrl('/php/petprofile.php?error=photo'));
    }

    $photoSql = $photo !== null ? ', photo = :photo' : '';
    $parameters = [
        'name' => $name,
        'species' => $species,
        'breed' => $breed,
        'birth_date' => $birthDate !== '' ? $birthDate : null,
        'pet_id' => $petId,
        'user_id' => $userId,
    ];
    if ($photo !== null) {
        $parameters['photo'] = $photo;
    }

    try {
        db()->prepare(
            'UPDATE pets SET name = :name, species = :species, breed = :breed, birth_date = :birth_date'
            . $photoSql . ' WHERE pet_id = :pet_id AND user_id = :user_id'
        )->execute($parameters);
    } catch (Throwable $exception) {
        if ($photo !== null) {
            deletePetPhoto($photo);
        }
        throw $exception;
    }

    if ($photo !== null) {
        deletePetPhoto($pet['photo'] ?? null);
    }
    redirectAfterPost(appUrl('/php/petprofile.php?saved=1'));
}

$pets = ownedPets($userId);
$vaccinations = ownedVaccinations($userId);

include __DIR__ . '/../html/petprofile.php';
