<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/auth.php';
startPetCareSession();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . appUrl('/html/login.php'));
    exit;
}

verifyCsrfToken();
$email = strtolower(trim((string) ($_POST['email'] ?? '')));
$email = substr($email, 0, 190);
$password = (string) ($_POST['password'] ?? '');
$ipAddress = substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45) ?: null;

if (isLoginLockedOut($email, $ipAddress)) {
    header('Location: ' . appUrl('/html/login.php?error=1'));
    exit;
}

$userIdColumn = userIdentifierColumn();
$passwordColumn = userPasswordColumn();
$activeColumn = userActiveColumn();

$query = db()->prepare(
    "SELECT {$userIdColumn} AS user_id, name, email, {$passwordColumn} AS password_hash, role,
            {$activeColumn}
     FROM users WHERE email = :email LIMIT 1"
);
$query->execute(['email' => $email]);
$user = $query->fetch();
$authenticated = $user
    && (int) $user['is_active'] === 1
    && password_verify($password, (string) $user['password_hash']);

if (tableExists('login_attempts') && tableHasColumn('login_attempts', 'email')) {
    db()->prepare(
        'INSERT INTO login_attempts (email, ip_address, successful)
         VALUES (:email, :ip_address, :successful)'
    )->execute([
        'email' => substr($email, 0, 190),
        'ip_address' => $ipAddress,
        'successful' => $authenticated ? 1 : 0,
    ]);
}

if (!$authenticated) {
    header('Location: ' . appUrl('/html/login.php?error=1'));
    exit;
}

session_regenerate_id(true);
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$_SESSION['user_logged_in'] = true;
$_SESSION['user_id'] = (int) ($user['user_id'] ?? 0);
$_SESSION['username'] = (string) $user['name'];
$_SESSION['role'] = (string) $user['role'];

if ($user['role'] === 'admin') {
    header('Location: ' . appUrl('/admin/dashboard.php'));
} else {
    header('Location: ' . appUrl('/php/dashboard.php'));
}
exit;
