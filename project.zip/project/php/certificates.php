<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/pet-care.php';
$userId = requireUserAccess();

$pets = ownedPets($userId);
$rows = [];
foreach ($pets as $pet) {
    $petId = (int) $pet['pet_id'];
    $rows[] = [
        'pet' => $pet,
        'cycle' => vaccineCycleStatus($petId, (string) $pet['species']),
        'certificate' => activeCertificateForPet($petId),
    ];
}

$pageTitle = 'Certificates';
$activePage = 'certificates';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6">
  <p class="text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Vaccination records</p>
  <h1 class="mt-2 text-3xl font-bold">Certificates</h1>
  <p class="mt-2 text-on-surface-variant">A certificate is issued once all required vaccines for a pet are done.</p>
</header>

<?php if (!$rows): ?>
  <p class="text-on-surface-variant">You have no pets yet. <a class="font-semibold text-primary underline" href="<?php echo escapeHtml(appUrl('/php/addpet.php')); ?>">Add a pet</a>.</p>
<?php endif; ?>

<div class="grid gap-4 md:grid-cols-2">
  <?php foreach ($rows as $row): $pet = $row['pet']; $cycle = $row['cycle']; $certificate = $row['certificate']; ?>
    <article class="petcare-card rounded-2xl p-5">
      <h2 class="text-xl font-bold"><?php echo escapeHtml($pet['name']); ?></h2>
      <p class="text-sm text-on-surface-variant"><?php echo escapeHtml($pet['species'] . ($pet['breed'] ? ' · ' . $pet['breed'] : '')); ?></p>
      <p class="mt-3 text-sm">
        <?php if ($certificate): ?>
          <span class="font-semibold text-primary">Certificate issued</span>
        <?php elseif ($cycle['complete']): ?>
          <span class="font-semibold">Vaccines complete. Waiting for the clinic to issue the certificate.</span>
        <?php elseif ($cycle['required_total'] === 0): ?>
          <span class="text-on-surface-variant">No vaccine schedule for this species yet.</span>
        <?php else: ?>
          <span class="text-on-surface-variant"><?php echo (int) $cycle['required_done']; ?> of <?php echo (int) $cycle['required_total']; ?> required vaccines done</span>
        <?php endif; ?>
      </p>
      <div class="mt-4 flex flex-wrap gap-3">
        <a class="rounded-xl border px-4 py-2 text-sm font-semibold" style="border-color:var(--border)" href="<?php echo escapeHtml(appUrl('/php/pet-detail.php?id=' . (int) $pet['pet_id'])); ?>">Pet details</a>
        <?php if ($certificate): ?>
          <a class="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-white" href="<?php echo escapeHtml(appUrl('/php/certificate.php?code=' . $certificate['certificate_code'])); ?>">View certificate</a>
        <?php endif; ?>
      </div>
    </article>
  <?php endforeach; ?>
</div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
