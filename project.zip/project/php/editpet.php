<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/pet-photo-upload.php';
$userId = requireLogin();
requireUserAccess();

$petId = (string) ($_GET['id'] ?? $_POST['pet_id'] ?? '');
$pet = findOwnedPet($userId, $petId);
if (!$pet) {
    http_response_code(404);
    exit('Pet not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $name = trim((string) ($_POST['name'] ?? ''));
    $species = trim((string) ($_POST['species'] ?? ''));
    $breed = trim((string) ($_POST['breed'] ?? '')) ?: null;
    $birthdate = trim((string) ($_POST['birthdate'] ?? ''));
    $sex = trim((string) ($_POST['sex'] ?? '')) ?: null;
    $weight = trim((string) ($_POST['weight'] ?? ''));
    $weightUnit = trim((string) ($_POST['weight_unit'] ?? 'lbs'));
    $microchip = trim((string) ($_POST['microchip_number'] ?? '')) ?: null;
    $clinic = trim((string) ($_POST['clinic'] ?? '')) ?: null;

    if ($name === '' || strlen($name) > 100 || $species === '' || strlen($species) > 50
        || ($breed !== null && strlen($breed) > 100)
        || ($birthdate !== '' && !isDateOnOrBeforeToday($birthdate))
        || ($sex !== null && strlen($sex) > 30)
        || ($weight !== '' && (!is_numeric($weight) || (float) $weight <= 0 || (float) $weight > 9999))
        || !in_array($weightUnit, ['lbs', 'kg'], true)
        || ($microchip !== null && strlen($microchip) > 100)
        || ($clinic !== null && strlen($clinic) > 150)) {
        header('Location: ' . appUrl('/php/editpet.php?id=' . (int) $pet['pet_id'] . '&error=1'));
        exit;
    }

    try {
        $photo = receivePetPhoto();
    } catch (RuntimeException $exception) {
        header('Location: ' . appUrl('/php/editpet.php?id=' . (int) $pet['pet_id'] . '&error=photo'));
        exit;
    }

    $oldPhoto = $pet['photo'] ?? null;
    $photoSql = $photo !== null ? ', photo = :photo' : '';
    $params = [
        'name' => $name,
        'species' => $species,
        'breed' => $breed,
        'birthdate' => $birthdate ?: null,
        'sex' => $sex,
        'weight' => $weight !== '' ? (float) $weight : null,
        'weight_unit' => $weightUnit,
        'microchip_number' => $microchip,
        'clinic' => $clinic,
        'pet_id' => (int) $pet['pet_id'],
        'user_id' => $userId,
    ];
    if ($photo !== null) {
        $params['photo'] = $photo;
    }
    db()->prepare(
        'UPDATE pets SET name = :name, species = :species, breed = :breed, birth_date = :birthdate,
         sex = :sex, weight = :weight, weight_unit = :weight_unit,
         microchip_number = :microchip_number, clinic = :clinic' . $photoSql . '
         WHERE pet_id = :pet_id AND user_id = :user_id'
    )->execute($params);

    if ($photo !== null) {
        deletePetPhoto($oldPhoto);
    }
    header('Location: ' . appUrl('/php/dashboard.php?updated=1&pet_id=' . (int) $pet['pet_id'] . '#pet-' . (int) $pet['pet_id']));
    exit;
}

$activePage = 'pets';
$pageTitle = 'Edit Pet';
include __DIR__ . '/../html/live-editpet.php';
