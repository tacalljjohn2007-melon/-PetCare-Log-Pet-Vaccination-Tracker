<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/pet-care.php';
$userId = requireUserAccess();

$petId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$pet = $petId ? findOwnedPet($userId, (string) $petId) : null;
if ($pet === null) {
    http_response_code(404);
    exit('Pet not found.');
}

$cycle = vaccineCycleStatus((int) $pet['pet_id'], (string) $pet['species']);
$certificate = activeCertificateForPet((int) $pet['pet_id']);

$pageTitle = $pet['name'] . ' | Pet details';
$activePage = 'pets';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6">
  <a class="text-sm font-semibold text-primary underline" href="<?php echo escapeHtml(appUrl('/php/petprofile.php')); ?>">&larr; My Pets</a>
  <p class="mt-3 text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Pet details</p>
  <h1 class="mt-2 text-3xl font-bold"><?php echo escapeHtml($pet['name']); ?></h1>
</header>

<section class="petcare-card mb-6 grid gap-4 rounded-2xl p-5 sm:grid-cols-2 lg:grid-cols-4">
  <div><p class="text-sm text-on-surface-variant">Species</p><p class="font-semibold"><?php echo escapeHtml($pet['species']); ?></p></div>
  <div><p class="text-sm text-on-surface-variant">Breed</p><p class="font-semibold"><?php echo escapeHtml($pet['breed'] ?: 'Not set'); ?></p></div>
  <div><p class="text-sm text-on-surface-variant">Age</p><p class="font-semibold"><?php echo escapeHtml(petAgeLabel($pet['birth_date'] ?? null)); ?></p></div>
  <div><p class="text-sm text-on-surface-variant">Birth date</p><p class="font-semibold"><?php echo escapeHtml($pet['birth_date'] ?: 'Not set'); ?></p></div>
</section>

<section class="petcare-card mb-6 rounded-2xl p-5">
  <h2 class="text-xl font-bold">Vaccination progress</h2>
  <?php if ($cycle['required_total'] === 0): ?>
    <p class="mt-2 text-on-surface-variant">No vaccine schedule is set up for <?php echo escapeHtml($pet['species']); ?> yet. Ask the clinic admin to add one.</p>
  <?php elseif ($cycle['complete']): ?>
    <p class="mt-2 font-semibold text-primary">All required vaccines are done.</p>
    <?php if ($certificate): ?>
      <p class="mt-3"><a class="rounded-xl bg-primary px-4 py-2 font-semibold text-white" href="<?php echo escapeHtml(appUrl('/php/certificate.php?code=' . $certificate['certificate_code'])); ?>">View certificate</a></p>
    <?php else: ?>
      <p class="mt-2 text-on-surface-variant">Your certificate is waiting for the clinic admin to issue it.</p>
    <?php endif; ?>
  <?php else: ?>
    <p class="mt-2 text-on-surface-variant"><?php echo (int) $cycle['required_done']; ?> of <?php echo (int) $cycle['required_total']; ?> required vaccines done. A certificate is issued once all are done.</p>
  <?php endif; ?>
</section>

<section class="petcare-card rounded-2xl p-5">
  <h2 class="text-xl font-bold">Recommended vaccines for <?php echo escapeHtml($pet['species']); ?></h2>
  <?php if (!$cycle['recommended']): ?>
    <p class="mt-2 text-on-surface-variant">None listed yet.</p>
  <?php else: ?>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-left text-sm">
        <thead class="text-on-surface-variant">
          <tr><th class="px-3 py-2">Vaccine</th><th class="px-3 py-2">Type</th><th class="px-3 py-2">Repeat every</th><th class="px-3 py-2">Status</th><th class="px-3 py-2">About</th></tr>
        </thead>
        <tbody>
          <?php foreach ($cycle['recommended'] as $item): ?>
            <tr class="border-t" style="border-color:var(--border)">
              <td class="px-3 py-2 font-semibold"><?php echo escapeHtml($item['name']); ?></td>
              <td class="px-3 py-2"><?php echo $item['is_required'] ? 'Required' : 'Optional'; ?></td>
              <td class="px-3 py-2"><?php echo (int) $item['schedule_days']; ?> days</td>
              <td class="px-3 py-2"><?php echo $item['done'] ? '<span class="font-semibold text-primary">Done</span>' : '<span class="text-on-surface-variant">Not yet</span>'; ?></td>
              <td class="px-3 py-2 text-on-surface-variant"><?php echo escapeHtml($item['description']); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <p class="mt-4 text-sm text-on-surface-variant">This list is general guidance. Your vet decides the exact schedule for your pet.</p>
  <?php endif; ?>
</section>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
