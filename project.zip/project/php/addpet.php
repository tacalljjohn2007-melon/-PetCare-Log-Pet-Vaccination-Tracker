<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/pet-photo-upload.php';
$userId = requireUserAccess();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verifyCsrfToken();
    $name = trim((string) ($_POST['petName'] ?? ''));
    $species = trim((string) ($_POST['species'] ?? ''));
    $breed = trim((string) ($_POST['petBreed'] ?? '')) ?: null;
    $birthDate = trim((string) ($_POST['petBirthDate'] ?? ''));
    $sex = trim((string) ($_POST['gender'] ?? '')) ?: null;
    $weight = trim((string) ($_POST['petWeight'] ?? ''));
    $weightUnit = trim((string) ($_POST['weightUnit'] ?? 'lbs'));
    $microchip = trim((string) ($_POST['microchipId'] ?? '')) ?: null;
    if ($name === '' || strlen($name) > 100 || $species === '' || strlen($species) > 50
        || ($breed !== null && strlen($breed) > 100)
        || ($birthDate !== '' && !isDateOnOrBeforeToday($birthDate))
        || ($sex !== null && strlen($sex) > 30)
        || ($weight !== '' && (!is_numeric($weight) || (float) $weight <= 0 || (float) $weight > 9999))
        || !in_array($weightUnit, ['lbs', 'kg'], true)
        || ($microchip !== null && strlen($microchip) > 100)) {
        redirectAfterPost(appUrl('/php/addpet.php?error=1'));
    }
    try {
        $photo = receivePetPhoto();
    } catch (RuntimeException $exception) {
        redirectAfterPost(appUrl('/php/addpet.php?error=photo'));
    }

    $statement = db()->prepare(
        'INSERT INTO pets (user_id, name, species, breed, sex, birth_date, weight, weight_unit, microchip_number, photo)
         VALUES (:user_id, :name, :species, :breed, :sex, :birth_date, :weight, :weight_unit, :microchip_number, :photo)'
    );
    $statement->execute([
        'user_id' => $userId,
        'name' => $name,
        'species' => $species,
        'breed' => $breed,
        'sex' => $sex,
        'birth_date' => $birthDate ?: null,
        'weight' => $weight !== '' ? (float) $weight : null,
        'weight_unit' => $weightUnit,
        'microchip_number' => $microchip,
        'photo' => $photo,
    ]);

    redirectAfterPost(appUrl('/php/petprofile.php?saved=1'));
}

include __DIR__ . '/../html/addpet.php';
