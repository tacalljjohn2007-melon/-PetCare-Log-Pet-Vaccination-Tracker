<?php

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/mail.php';
startPetCareSession();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Method not allowed.');
}

verifyCsrfToken();
$email = strtolower(trim((string) ($_POST['email'] ?? '')));
if (filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($email) <= 190) {
    $userQuery = db()->prepare('SELECT user_id, email, name FROM users WHERE email = :email AND is_active = 1 LIMIT 1');
    $userQuery->execute(['email' => $email]);
    $user = $userQuery->fetch();
    if ($user) {
        $token = bin2hex(random_bytes(32));
        $connection = db();
        $connection->beginTransaction();
        try {
            $connection->prepare(
                'UPDATE password_resets SET used_at = NOW() WHERE user_id = :user_id AND used_at IS NULL'
            )->execute(['user_id' => $user['user_id']]);
            $connection->prepare(
                'INSERT INTO password_resets (user_id, token_hash, expires_at)
                 VALUES (:user_id, :token_hash, DATE_ADD(NOW(), INTERVAL 1 HOUR))'
            )->execute([
                'user_id' => $user['user_id'],
                'token_hash' => hash('sha256', $token),
            ]);
            $connection->commit();
        } catch (Throwable $exception) {
            if ($connection->inTransaction()) {
                $connection->rollBack();
            }
            throw $exception;
        }

        $resetUrl = petCarePublicBaseUrl() . appUrl('/html/reset-password.php?token=' . rawurlencode($token));
        sendPetCareMail(
            $user['email'],
            'Reset your PetCare Log password',
            "Hello {$user['name']},\n\nUse this link within one hour to choose a new password:\n{$resetUrl}\n\nIf you did not request this, you can ignore this email."
        );
    }
}

header('Location: ' . appUrl('/html/forgot-password.php?sent=1'));
exit;
