<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/pet-care.php';
$viewerId = requireLogin();
$isAdmin = currentUserRole() === 'admin';

$code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) ($_GET['code'] ?? '')));
$query = db()->prepare(
    'SELECT c.*, p.name AS pet_name, p.species, p.breed, p.birth_date, p.photo AS pet_photo, u.name AS owner_name
     FROM pet_certificates c
     INNER JOIN pets p ON p.pet_id = c.pet_id
     INNER JOIN users u ON u.user_id = c.user_id
     WHERE c.certificate_code = :code LIMIT 1'
);
$query->execute(['code' => $code]);
$certificate = $query->fetch();

if (!$certificate) {
    http_response_code(404);
    exit('Certificate not found.');
}
if ($certificate['revoked_at'] !== null) {
    http_response_code(410);
    exit('This certificate has been revoked. Contact the clinic for details.');
}

// Owners see only their own active certificates; admins can open any active certificate.
if (!$isAdmin && (int) $certificate['user_id'] !== $viewerId) {
    http_response_code(404);
    exit('Certificate not found.');
}

$issued = (new DateTimeImmutable((string) $certificate['issued_at']))->format('F j, Y');
$petPhoto = petPhotoUrl($certificate['pet_photo'] ?? null);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Vaccination Completion Certificate | PetCare Log</title>
  <style>
    body { margin: 0; font-family: Georgia, serif; background: #f4f6f5; color: #1d2a24; }
    .toolbar { text-align: center; padding: 16px; }
    .toolbar button { background: #006c49; color: #fff; border: 0; border-radius: 10px; padding: 10px 18px; font-size: 15px; cursor: pointer; }
    .certificate { max-width: 800px; margin: 0 auto 32px; background: #fff; border: 6px double #006c49; padding: 48px 56px; text-align: center; box-sizing: border-box; }
    .certificate h1 { font-size: 32px; margin: 0 0 8px; color: #006c49; letter-spacing: 1px; }
    .certificate .lead { font-size: 16px; margin: 24px 0 8px; }
    .certificate .pet-photo { display: block; width: 150px; height: 150px; margin: 18px auto 14px; border: 4px solid #006c49; border-radius: 50%; object-fit: cover; }
    .certificate .pet { font-size: 30px; font-weight: bold; margin: 8px 0; }
    .certificate .details { font-size: 16px; line-height: 1.7; margin-top: 16px; }
    .certificate .footer { margin-top: 40px; font-size: 13px; color: #55645c; }
    @media (max-width: 600px) { .certificate { padding: 28px 20px; } .certificate h1 { font-size: 24px; } }
    @media print { .toolbar { display: none; } body { background: #fff; } .certificate { margin: 0; border-width: 4px; } }
  </style>
</head>
<body>
  <div class="toolbar"><button type="button" onclick="window.print()">Print or save as PDF</button></div>
  <main class="certificate">
    <h1>Certificate of Vaccination Completion</h1>
    <p class="lead">This certifies that the required vaccinations for</p>
    <?php if ($petPhoto !== ''): ?><img class="pet-photo" src="<?php echo escapeHtml($petPhoto); ?>" alt="Photo of <?php echo escapeHtml($certificate['pet_name']); ?>" /><?php endif; ?>
    <p class="pet"><?php echo escapeHtml($certificate['pet_name']); ?></p>
    <p class="details">
      <?php echo escapeHtml($certificate['species']); ?>
      <?php if (!empty($certificate['breed'])): ?> · <?php echo escapeHtml($certificate['breed']); ?><?php endif; ?>
      <br />owned by <?php echo escapeHtml($certificate['owner_name']); ?>
      <br />have been completed.
    </p>
    <p class="footer">
      Issued <?php echo escapeHtml($issued); ?> by PetCare Log<br />
      Certificate code: <strong><?php echo escapeHtml($certificate['certificate_code']); ?></strong>
    </p>
  </main>
</body>
</html>
