<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/profile-photo-upload.php';
$userId = requireUserAccess();
$user = userProfile($userId);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verifyCsrfToken();
    $action = (string) ($_POST['action'] ?? 'save_profile');
    if ($action === 'save_preferences') {
        $enabled = isset($_POST['notifications_enabled']) ? 1 : 0;
        db()->prepare(
            'INSERT INTO settings (user_id, notifications_enabled)
             VALUES (:user_id, :enabled)
             ON DUPLICATE KEY UPDATE notifications_enabled = VALUES(notifications_enabled)'
        )->execute(['user_id' => $userId, 'enabled' => $enabled]);
        redirectAfterPost(appUrl('/php/setting.php?preferences_saved=1'));
    }
    if ($action === 'change_password') {
        $passwordColumn = userPasswordColumn();
        $query = db()->prepare("SELECT {$passwordColumn} FROM users WHERE " . userIdentifierColumn() . ' = :user_id');
        $query->execute(['user_id' => $userId]);
        $currentHash = (string) $query->fetchColumn();
        $newPassword = (string) ($_POST['new_password'] ?? '');
        if (!password_verify((string) ($_POST['current_password'] ?? ''), $currentHash)
            || !isValidPasswordLength($newPassword)) {
            redirectAfterPost(appUrl('/php/setting.php?password_error=1'));
        }
        db()->prepare(
            'UPDATE users SET ' . $passwordColumn . ' = :password WHERE ' . userIdentifierColumn() . ' = :user_id'
        )->execute(['password' => password_hash($newPassword, PASSWORD_DEFAULT), 'user_id' => $userId]);
        redirectAfterPost(appUrl('/php/setting.php?password_saved=1'));
    }
    $name = trim((string) ($_POST['fullName'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $phone = trim((string) ($_POST['phone'] ?? '')) ?: null;
    $clinic = trim((string) ($_POST['clinic'] ?? '')) ?: null;
    if ($name === '' || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || strlen($email) > 190 || ($phone !== null && strlen($phone) > 30)
        || ($clinic !== null && strlen($clinic) > 150)) {
        redirectAfterPost(appUrl('/php/setting.php?error=1'));
    }
    $userIdColumn = userIdentifierColumn();
    $duplicateEmail = db()->prepare(
        "SELECT {$userIdColumn} FROM users WHERE email = :email AND {$userIdColumn} <> :user_id LIMIT 1"
    );
    $duplicateEmail->execute(['email' => $email, 'user_id' => $userId]);
    if ($duplicateEmail->fetch()) {
        redirectAfterPost(appUrl('/php/setting.php?error=1'));
    }

    try {
        $newPhoto = receiveProfilePhoto();
    } catch (RuntimeException $exception) {
        redirectAfterPost(appUrl('/php/setting.php?upload_error=1'));
    }

    $photoSql = $newPhoto !== null ? ', profile_photo = :profile_photo' : '';
    $parameters = [
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'clinic' => $clinic,
        'user_id' => $userId,
    ];
    if ($newPhoto !== null) {
        $parameters['profile_photo'] = $newPhoto;
    }
    try {
        db()->prepare(
            "UPDATE users SET name = :name, email = :email, phone = :phone, preferred_clinic = :clinic{$photoSql}
             WHERE {$userIdColumn} = :user_id"
        )->execute($parameters);
    } catch (PDOException $exception) {
        if ($newPhoto !== null) {
            deleteProfilePhoto($newPhoto);
        }
        if ($exception->getCode() === '23000') {
            redirectAfterPost(appUrl('/php/setting.php?error=1'));
        }
        throw $exception;
    } catch (Throwable $exception) {
        if ($newPhoto !== null) {
            deleteProfilePhoto($newPhoto);
        }
        throw $exception;
    }

    if ($newPhoto !== null) {
        deleteProfilePhoto($user['profile_photo'] ?? null);
        $user['profile_photo'] = $newPhoto;
    }
    $_SESSION['username'] = $name;
    redirectAfterPost(appUrl('/php/setting.php?saved=1'));
}

$preferences = notificationPreferences($userId);

include __DIR__ . '/../html/setting.php';
