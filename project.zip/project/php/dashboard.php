<?php
require_once __DIR__ . '/../config/auth.php';
$userId = requireLogin();
$user = userProfile($userId);
$pets = ownedPets($userId);
$vaccinations = ownedVaccinations($userId);

$today = date('Y-m-d');
$dueThreshold = (new DateTimeImmutable('+30 days'))->format('Y-m-d');
$upcomingVaccines = array_values(array_filter(
    $vaccinations,
    static fn (array $item): bool => $item['computed_status'] !== 'done'
        && $item['next_due_date'] >= $today
        && $item['next_due_date'] <= $dueThreshold
));
$upcomingRemindersQuery = db()->prepare(
    "SELECT r.remind_date, r.message, p.name AS pet_name, v.vaccine_name
     FROM reminders r
     INNER JOIN pets p ON p.pet_id = r.pet_id
     LEFT JOIN vaccinations v ON v.vaccination_id = r.vaccine_id
     WHERE r.user_id = :user_id AND r.status = 'pending'
       AND r.remind_date <= :due_threshold
     ORDER BY r.remind_date LIMIT 6"
);
$upcomingRemindersQuery->execute(['user_id' => $userId, 'due_threshold' => $dueThreshold]);
$upcomingReminders = $upcomingRemindersQuery->fetchAll();
$counts = [
    'pets' => count($pets),
    'upcoming' => count($upcomingVaccines),
    'overdue' => count(array_filter(
        $vaccinations,
        static fn (array $item): bool => $item['computed_status'] === 'overdue'
    )),
    'pending_reminders' => 0,
];
$pendingReminders = db()->prepare(
    "SELECT COUNT(*) FROM reminders r
     INNER JOIN pets p ON p.pet_id = r.pet_id
     WHERE r.user_id = :user_id AND r.status = 'pending' AND r.is_done = 0"
);
$pendingReminders->execute(['user_id' => $userId]);
$counts['pending_reminders'] = (int) $pendingReminders->fetchColumn();

include __DIR__ . '/../html/dashboard.php';
