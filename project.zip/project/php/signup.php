<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/auth.php';
startPetCareSession();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . appUrl('/html/signup.php'));
    exit;
}

verifyCsrfToken();
$name = trim((string) ($_POST['full_name'] ?? ''));
$email = strtolower(trim((string) ($_POST['email'] ?? '')));
$password = (string) ($_POST['password'] ?? '');
$confirmation = (string) ($_POST['confirm_password'] ?? '');

if ($name === '' || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || strlen($email) > 190 || !isValidPasswordLength($password) || $password !== $confirmation) {
    header('Location: ' . appUrl('/html/signup.php?error=1'));
    exit;
}

$userIdColumn = userIdentifierColumn();
$passwordColumn = userPasswordColumn();

$query = db()->prepare("SELECT {$userIdColumn} FROM users WHERE email = :email LIMIT 1");
$query->execute(['email' => $email]);
if ($query->fetch()) {
    header('Location: ' . appUrl('/html/signup.php?error=2'));
    exit;
}

$connection = db();
$connection->beginTransaction();
try {
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $connection->prepare(
        "INSERT INTO users (name, email, {$passwordColumn}, role)
         VALUES (:name, :email, :password_value, 'user')"
    )->execute([
        'name' => $name,
        'email' => $email,
        'password_value' => $passwordHash,
    ]);
    $connection->prepare('INSERT INTO settings (user_id) VALUES (:user_id)')
        ->execute(['user_id' => (int) $connection->lastInsertId()]);
    $connection->commit();
} catch (PDOException $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }
    if ($exception->getCode() === '23000') {
        header('Location: ' . appUrl('/html/signup.php?error=2'));
        exit;
    }
    throw $exception;
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }
    throw $exception;
}

header('Location: ' . appUrl('/html/login.php?registered=1'));
exit;
