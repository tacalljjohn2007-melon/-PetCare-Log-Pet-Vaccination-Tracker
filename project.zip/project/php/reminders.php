<?php
require_once __DIR__ . '/../config/auth.php';
$userId = requireUserAccess();
$user = userProfile($userId);
$pets = ownedPets($userId);
$vaccinations = ownedVaccinations($userId);
$requestedStatus = (string) ($_GET['status'] ?? '');
$reminderStatusFilter = in_array($requestedStatus, ['pending', 'completed'], true)
    ? $requestedStatus
    : 'all';

$remindersQuery = db()->prepare(
    "SELECT r.*, p.name AS pet_name, v.vaccine_name
     FROM reminders r
     INNER JOIN pets p ON p.pet_id = r.pet_id
     LEFT JOIN vaccinations v ON v.vaccination_id = r.vaccine_id
     WHERE r.user_id = :user_id
       AND CASE :status_filter
           WHEN 'pending' THEN r.status = 'pending' AND r.is_done = 0
           WHEN 'completed' THEN (r.status = 'completed' OR r.is_done = 1)
           ELSE 1
       END
     ORDER BY r.remind_date, r.id"
);
$remindersQuery->execute(['user_id' => $userId, 'status_filter' => $reminderStatusFilter]);
$reminders = $remindersQuery->fetchAll();

include __DIR__ . '/../html/reminders.php';
