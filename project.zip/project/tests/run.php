<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/auth.php';

$assertions = 0;
$assert = static function (bool $condition, string $message) use (&$assertions): void {
    $assertions++;
    if (!$condition) {
        throw new RuntimeException($message);
    }
};

$today = date('Y-m-d');
$tomorrow = (new DateTimeImmutable('tomorrow'))->format('Y-m-d');
$yesterday = (new DateTimeImmutable('yesterday'))->format('Y-m-d');
$assert(isValidVaccineDateRange($today, $today), 'A same-day vaccine date range should be valid.');
$assert(isValidVaccineDateRange($today, $tomorrow), 'A future due date should be valid.');
$assert(isDateOnOrBeforeToday($today), 'Today should be accepted for a birthdate.');
$assert(!isDateOnOrBeforeToday($tomorrow), 'A future birthdate should be invalid.');
$assert(!isValidVaccineDateRange($tomorrow, $tomorrow), 'A future date given should be invalid.');
$assert(!isValidVaccineDateRange($today, $yesterday), 'A due date before the date given should be invalid.');
$assert(!isValidVaccineDateRange('not-a-date', $tomorrow), 'Malformed dates should be invalid.');
$assert(adminRoleChangeError('user', 'manager') === "This user's role cannot be changed", 'A User must not be promoted through the role endpoint.');
$assert(adminRoleChangeError('admin', 'user') === "This user's role cannot be changed", 'An Admin must not be changed through the role endpoint.');
$assert(adminRoleChangeError('manager', 'user') === null, 'A Manager should be allowed to become a User.');
$assert(adminRoleChangeError('manager', 'admin') === 'Admins can only assign the User or Manager role', 'A Manager must not be promoted to Admin.');
$assert(adminRoleChangeError('manager', 'user', true) === "The current admin's role cannot be changed", 'The current admin must not change their own role.');
$usersEndpointSource = file_get_contents(__DIR__ . '/../admin/users.php');
$assert(
    is_string($usersEndpointSource)
        && str_contains($usersEndpointSource, 'http_response_code(403);')
        && str_contains($usersEndpointSource, 'adminRoleChangeError('),
    'Rejected role changes must return HTTP 403 from the Users endpoint.'
);
$authSource = file_get_contents(__DIR__ . '/../config/auth.php');
$assert(
    is_string($authSource)
        && str_contains($authSource, "\$_SERVER['REQUEST_METHOD'] ?? 'GET'")
        && str_contains($authSource, "exit('Admin access is required.')"),
    'A non-admin calling an admin POST/API route must receive HTTP 403.'
);
$pageStartSource = file_get_contents(__DIR__ . '/../includes/page-start.php');
$loginSource = file_get_contents(__DIR__ . '/../html/login.php');
$assert(
        is_string($pageStartSource)
        && is_string($loginSource)
        && str_contains($pageStartSource, "theme-toggle.php")
        && str_contains($loginSource, "includes/theme-toggle.php"),
    'Both user and admin layouts must render the shared theme toggle.'
);
$themeSource = file_get_contents(__DIR__ . '/../js/theme.js');
$assert(
    is_string($themeSource)
        && str_contains($themeSource, 'theme === "dark" ? "light" : "dark"')
        && str_contains($themeSource, 'document.documentElement.dataset.theme = theme'),
    'The shared theme toggle must support both light and dark mode.'
);
$preferencesSource = file_get_contents(__DIR__ . '/../php/preferences.php');
$assert(
    is_string($preferencesSource)
        && str_contains($preferencesSource, "'es-ES'")
        && str_contains($preferencesSource, 'http_response_code(422)')
        && str_contains($preferencesSource, 'requireLogin()')
        && str_contains($preferencesSource, 'verifyCsrfToken()'),
    'Preferences must validate languages and require an authenticated CSRF-protected request.'
);
$userSettingsSource = file_get_contents(__DIR__ . '/../html/live-settings.php');
$adminSettingsSource = file_get_contents(__DIR__ . '/../admin/settings.php');
$assert(
    is_string($userSettingsSource)
        && str_contains($userSettingsSource, 'id="languageSelect"')
        && strpos($userSettingsSource, 'settings-password.php') < strpos($userSettingsSource, 'id="languageSelect"')
        && strpos($userSettingsSource, 'id="languageSelect"') < strpos($userSettingsSource, 'data-logout-form'),
    'The user Language card must be after password settings and before logout.'
);
$assert(
    is_string($adminSettingsSource)
        && str_contains($adminSettingsSource, 'id="languageSelect"')
        && strpos($adminSettingsSource, 'id="languageSelect"') < strpos($adminSettingsSource, 'data-logout-form'),
    'The admin Language card must be immediately before logout.'
);
$assert(
    is_string($userSettingsSource)
        && is_string($adminSettingsSource)
        && !str_contains($userSettingsSource, 'Save language')
        && !str_contains($adminSettingsSource, 'Save language'),
    'Neither settings page should render a Save language button.'
);
$assert(
    is_string($themeSource)
        && str_contains($themeSource, 'AbortController')
        && str_contains($themeSource, 'response.ok')
        && str_contains($themeSource, 'languageSelect.disabled = true'),
    'Language saves must be abortable, status-checked, and disable the select while pending.'
);

$originalScriptName = $_SERVER['SCRIPT_NAME'] ?? null;
$_SERVER['SCRIPT_NAME'] = '/logout.php';
$assert(appUrl('/html/login.php') === '/html/login.php', 'Root-level routes should generate valid URLs on Windows.');
if ($originalScriptName === null) {
    unset($_SERVER['SCRIPT_NAME']);
} else {
    $_SERVER['SCRIPT_NAME'] = $originalScriptName;
}

$connection = db();
$schemaColumns = [
    'users' => ['user_id', 'password', 'is_active', 'profile_photo'],
    'pets' => ['pet_id', 'user_id', 'birth_date'],
    'vaccinations' => ['vaccination_id', 'pet_id', 'administration_date', 'status'],
    'reminders' => ['id', 'user_id', 'pet_id', 'vaccine_id', 'remind_date', 'message', 'is_done', 'status', 'last_notified_at'],
    'settings' => ['user_id', 'theme', 'language', 'notifications_enabled'],
    'vaccine_types' => ['vaccine_type_id', 'name', 'schedule_days', 'description'],
];
foreach ($schemaColumns as $table => $columns) {
    foreach ($columns as $column) {
        $assert(tableHasColumn($table, $column), "The live {$table} table should contain {$column}.");
    }
}
$assert(!tableHasColumn('users', 'must_change_password'), 'The canonical schema must not require users.must_change_password.');
$assert(tableHasColumn('login_attempts', 'ip_address'), 'The login attempt table should support per-IP lockout.');

$seededAccounts = [
    'user@petcarelog.test' => ['password' => 'user123', 'role' => 'user'],
    'admin@petcarelog.test' => ['password' => 'Admin123!', 'role' => 'admin'],
];
$passwordColumn = userPasswordColumn();
$seededAccountQuery = $connection->prepare(
    "SELECT {$passwordColumn} AS password_hash, role FROM users WHERE email = :email LIMIT 1"
);
foreach ($seededAccounts as $email => $credentials) {
    $seededAccountQuery->execute(['email' => $email]);
    $account = $seededAccountQuery->fetch();
    if (!$account) {
        continue;
    }
    $assert(
        $account['role'] === $credentials['role']
            && password_verify($credentials['password'], (string) $account['password_hash']),
        "The seeded {$email} account should verify its documented password."
    );
}

$loginSource = file_get_contents(__DIR__ . '/../php/login.php');
$assert(is_string($loginSource) && str_contains($loginSource, "appUrl('/admin/dashboard.php')"), 'Successful admin login should redirect to the admin dashboard.');
$assert(is_string($loginSource) && str_contains($loginSource, "appUrl('/php/dashboard.php')"), 'Successful user login should redirect to the user dashboard.');

$sidebarSource = file_get_contents(__DIR__ . '/../includes/sidebar.php');
$assert(
    is_string($sidebarSource)
        && !str_contains($sidebarSource, "'vaccines' => ['Vaccines', 'vaccines', '/php/vaccine.php']")
        && str_contains($sidebarSource, "'vaccines' => ['All Vaccines', 'vaccines', '/admin/vaccines.php']")
        && str_contains($sidebarSource, "'vaccine-types' => ['Vaccine Types', 'category', '/admin/vaccine-types.php']"),
    'Vaccines should be managed from the admin sidebar only.'
);

$retiredVaccineSources = [
    file_get_contents(__DIR__ . '/../php/vaccine.php'),
    file_get_contents(__DIR__ . '/../php/addvaccine.php'),
    file_get_contents(__DIR__ . '/../php/export-vaccines.php'),
    file_get_contents(__DIR__ . '/../html/vaccine.php'),
    file_get_contents(__DIR__ . '/../html/live-vaccines.php'),
    file_get_contents(__DIR__ . '/../html/addvaccine.php'),
    file_get_contents(__DIR__ . '/../html/live-addvaccine.php'),
];
$assert(
    !in_array(false, $retiredVaccineSources, true)
        && count(array_filter($retiredVaccineSources, static fn ($source): bool => str_contains($source, 'redirectToUserDashboard()'))) === count($retiredVaccineSources),
    'Legacy user vaccine routes should redirect instead of rendering management pages.'
);

$adminVaccineSource = file_get_contents(__DIR__ . '/../admin/vaccines.php');
$adminVaccineTypesSource = file_get_contents(__DIR__ . '/../admin/vaccine-types.php');
$assert(
    is_string($adminVaccineSource)
        && str_contains($adminVaccineSource, 'requireAdmin()')
        && str_contains($adminVaccineSource, "action === 'mark_done'")
        && str_contains($adminVaccineSource, "SET status = 'done', administration_date"),
    'Admins should be able to mark a vaccination done with its administration date.'
);
$assert(
    is_string($adminVaccineTypesSource)
        && str_contains($adminVaccineTypesSource, 'requireAdmin()')
        && str_contains($adminVaccineTypesSource, 'is_required'),
    'Admins should control required vaccine types by species.'
);

$controllerViews = [
    'dashboard' => ['dashboard', 'dashboard'],
    'petprofile' => ['petprofile', 'pets'],
    'addpet' => ['addpet', 'addpet'],
    'reminders' => ['reminders', 'reminders'],
    'setting' => ['setting', 'settings'],
];
foreach ($controllerViews as $controller => [$view, $template]) {
    $controllerSource = file_get_contents(__DIR__ . "/../php/{$controller}.php");
    $viewSource = file_get_contents(__DIR__ . "/../html/{$view}.php");
    $assert(
        is_string($controllerSource) && str_contains($controllerSource, "/html/{$view}.php"),
        "The {$controller} controller should include its matching view."
    );
    $assert(
        is_string($viewSource) && str_contains($viewSource, "'/live-{$template}.php'"),
        "The {$view} view should include its data-backed template."
    );
    $assert(
        is_string($viewSource) && !str_contains($viewSource, "header('Location:"),
        "The {$view} view must not redirect."
    );
}

$petProfileController = file_get_contents(__DIR__ . '/../php/petprofile.php');
$petManagementView = file_get_contents(__DIR__ . '/../includes/pet-management.php');
$assert(
    is_string($petProfileController)
        && str_contains($petProfileController, "'save_pet'")
        && str_contains($petProfileController, 'UPDATE pets SET'),
    'Saving a pet from the pet list should update its stored profile.'
);
$assert(
    is_string($petProfileController)
        && str_contains($petProfileController, "if (\$action === 'delete_pet')")
        && str_contains($petProfileController, 'DELETE FROM pets'),
    'Deleting a pet from the pet list should remove its stored profile.'
);
$assert(
    is_string($petManagementView)
        && str_contains($petManagementView, 'name="csrf_token"')
        && str_contains($petManagementView, 'name="action" value="save_pet"'),
    'The pet management form should submit a protected save action.'
);

$adminPageFiles = ['dashboard.php', 'users.php', 'pets.php', 'vaccines.php', 'vaccine-types.php', 'reminders.php', 'settings.php'];
foreach ($adminPageFiles as $page) {
    $pageSource = file_get_contents(__DIR__ . '/../admin/' . $page);
    $assert(
        is_string($pageSource)
            && str_contains($pageSource, "includes/admin-page-start.php")
            && str_contains($pageSource, "includes/page-end.php"),
        "Admin page {$page} should use the shared page layout."
    );
}

$connection->beginTransaction();
try {
    $email = 'petcare-test-' . bin2hex(random_bytes(8)) . '@example.invalid';
    $passwordColumn = userPasswordColumn();
    $userIdColumn = userIdentifierColumn();
    $petIdColumn = petIdentifierColumn();
    $insertUser = $connection->prepare(
        "INSERT INTO users (name, email, {$passwordColumn}) VALUES (:name, :email, :password_hash)"
    );
    $insertUser->execute([
        'name' => 'PetCare test owner',
        'email' => $email,
        'password_hash' => password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT),
    ]);
    $ownerId = (int) $connection->lastInsertId();
    $insertPet = $connection->prepare(
        "INSERT INTO pets (user_id, name, species) VALUES (:user_id, :name, :species)"
    );
    $insertPet->execute(['user_id' => $ownerId, 'name' => 'Test pet', 'species' => 'Dog']);
    $petId = (int) $connection->lastInsertId();
    $insertPet->execute(['user_id' => $ownerId, 'name' => '0000000000', 'species' => 'Dog']);
    $numericNamePetId = (int) $connection->lastInsertId();

    $connection->prepare(
        'INSERT INTO settings (user_id, language) VALUES (:user_id, :language)
         ON DUPLICATE KEY UPDATE language = VALUES(language)'
    )->execute(['user_id' => $ownerId, 'language' => 'es-ES']);
    $assert(userLanguage($ownerId) === 'es-ES', 'Saving es-ES should persist the language preference.');
    $connection->prepare(
        'INSERT INTO settings (user_id, theme) VALUES (:user_id, :theme)
         ON DUPLICATE KEY UPDATE theme = VALUES(theme)'
    )->execute(['user_id' => $ownerId, 'theme' => 'dark']);
    $settingsQuery = $connection->prepare('SELECT theme, language FROM settings WHERE user_id = :user_id');
    $settingsQuery->execute(['user_id' => $ownerId]);
    $settings = $settingsQuery->fetch();
    $assert($settings['theme'] === 'dark' && $settings['language'] === 'es-ES', 'Saving a theme must not reset the language.');
    $connection->prepare(
        'INSERT INTO settings (user_id, language) VALUES (:user_id, :language)
         ON DUPLICATE KEY UPDATE language = VALUES(language)'
    )->execute(['user_id' => $ownerId, 'language' => 'fr-CA']);
    $settingsQuery->execute(['user_id' => $ownerId]);
    $settings = $settingsQuery->fetch();
    $assert($settings['theme'] === 'dark' && $settings['language'] === 'fr-CA', 'Saving a language must not reset the theme.');
    $storedLanguageBeforeInvalid = userLanguage($ownerId);
    $assert(!in_array('xx', ['en-US', 'en-GB', 'es-ES', 'fr-CA', 'de-DE', 'tl-PH'], true), 'An unsupported language code should be rejected with 422.');
    $assert(userLanguage($ownerId) === $storedLanguageBeforeInvalid, 'An invalid language must not change the stored language.');

    $attemptEmail = 'lockout-' . bin2hex(random_bytes(8)) . '@example.invalid';
    $attemptQuery = $connection->prepare(
        'INSERT INTO login_attempts (email, ip_address, successful) VALUES (:email, :ip_address, 0)'
    );
    for ($attempt = 0; $attempt < 5; $attempt++) {
        $attemptQuery->execute(['email' => $attemptEmail, 'ip_address' => '192.0.2.10']);
    }
    $assert(isLoginLockedOut($attemptEmail, '192.0.2.10'), 'Five recent failed logins should trigger a lockout.');
    $connection->prepare(
        'INSERT INTO login_attempts (email, ip_address, successful) VALUES (:email, :ip_address, 1)'
    )->execute(['email' => $attemptEmail, 'ip_address' => '192.0.2.10']);
    $assert(!isLoginLockedOut($attemptEmail, '192.0.2.10'), 'A successful login should clear prior consecutive failures.');

    $assert(findOwnedPet($ownerId, 'Test pet') !== null, 'A non-numeric pet identifier should resolve by name.');
    $connection->prepare(
        'INSERT INTO vaccinations (pet_id, vaccine_name, administration_date, next_due_date)
         VALUES (:pet_id, :vaccine_name, :administration_date, :next_due_date)'
    )->execute([
        'pet_id' => $petId,
        'vaccine_name' => 'Test vaccine',
        'administration_date' => $today,
        'next_due_date' => $tomorrow,
    ]);
    $assert(findOwnedPet($ownerId, (string) $petId) !== null, 'The owner should be able to find their pet.');
    $assert(findOwnedPet($ownerId, '0000000000') === null, 'A numeric identifier should never fall back to a pet name.');
    $assert(findOwnedPet($ownerId, (string) $numericNamePetId) !== null, 'A numeric pet ID should resolve by ID.');
    $assert(findOwnedPet($ownerId + 1000000000, (string) $petId) === null, 'Another user must not find the pet.');
    $vaccinationFields = ownedVaccinations($ownerId);
    $assert(array_key_exists('date_given', $vaccinationFields[0]), 'Owned vaccination records should provide the date_given field expected by the vaccine management view.');
    $assert($vaccinationFields[0]['date_given'] === $today, 'The date_given alias should contain the stored administration date.');

    $cronQuery = $connection->prepare(
        'SELECT r.id FROM reminders r
         INNER JOIN users u ON u.user_id = r.user_id
         INNER JOIN settings s ON s.user_id = u.user_id
         WHERE r.status = \'pending\' AND r.is_done = 0 AND r.last_notified_at IS NULL
           AND r.remind_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :days_ahead DAY)
           AND s.notifications_enabled = 1'
    );
    $cronQuery->bindValue(':days_ahead', 7, PDO::PARAM_INT);
    $cronQuery->execute();
    $cronQuery->fetchAll();
    $assert(true, 'The reminder cron query should run against the canonical reminders schema.');

    $search = '';
    $term = '%' . $search . '%';
    $statusFilter = 'all';
    $statusSql = vaccineStatusCaseSql('v');
    $adminQueries = [
        'dashboard user count' => 'SELECT COUNT(*) FROM users',
        'dashboard pet count' => 'SELECT COUNT(*) FROM pets',
        'dashboard vaccination count' => 'SELECT COUNT(*) FROM vaccinations',
        'dashboard overdue count' => "SELECT COUNT(*) FROM vaccinations v INNER JOIN pets p ON p.pet_id = v.pet_id WHERE v.status <> 'done' AND v.next_due_date < CURDATE()",
        'dashboard recent users' => 'SELECT user_id, name, email, role, is_active FROM users ORDER BY created_at DESC LIMIT 5',
        'dashboard recent reminders' => "SELECT r.remind_date AS next_due_date, p.name AS pet_name, u.name AS owner_name FROM reminders r INNER JOIN pets p ON p.pet_id = r.pet_id INNER JOIN users u ON u.user_id = r.user_id WHERE r.status = 'pending' ORDER BY r.remind_date ASC LIMIT 5",
        'admin users list' => 'SELECT u.user_id, u.name, u.email, u.role, u.is_active, COUNT(p.pet_id) AS pet_count FROM users u LEFT JOIN pets p ON p.user_id = u.user_id GROUP BY u.user_id, u.name, u.email, u.role, u.is_active ORDER BY u.name ASC',
        'admin pets list' => 'SELECT p.*, u.name AS owner_name FROM pets p INNER JOIN users u ON u.user_id = p.user_id ORDER BY u.name, p.name ASC',
        'admin vaccine list' => "SELECT v.vaccination_id AS id, v.vaccine_name, v.vaccine_type, v.administration_date AS date_given, v.next_due_date, v.notes, p.name AS pet_name, p.species, u.name AS owner_name, u.email AS owner_email, {$statusSql} AS computed_status FROM vaccinations v INNER JOIN pets p ON p.pet_id = v.pet_id INNER JOIN users u ON u.user_id = p.user_id WHERE (:search = '' OR v.vaccine_name LIKE :vaccine OR p.name LIKE :pet OR u.name LIKE :owner) AND (:status_filter = 'all' OR ({$statusSql}) = :computed_status) ORDER BY v.next_due_date, p.name",
        'admin reminders list' => "SELECT r.id, r.remind_date, r.message, r.status AS reminder_status, p.name AS pet_name, u.name AS owner_name, u.email, v.vaccine_name, CASE WHEN r.status = 'completed' OR r.is_done = 1 THEN 'Completed' WHEN r.remind_date < CURDATE() THEN 'Overdue' ELSE 'Upcoming' END AS status FROM reminders r INNER JOIN pets p ON p.pet_id = r.pet_id INNER JOIN users u ON u.user_id = r.user_id LEFT JOIN vaccinations v ON v.vaccination_id = r.vaccine_id WHERE (:search = '' OR p.name LIKE :pet OR u.name LIKE :owner OR v.vaccine_name LIKE :vaccine OR r.message LIKE :message) ORDER BY r.remind_date ASC",
        'admin settings profile' => 'SELECT user_id, name, email, phone, preferred_clinic, role FROM users WHERE user_id = 1 LIMIT 1',
        'admin vaccine types list' => 'SELECT * FROM vaccine_types ORDER BY name ASC',
    ];
    foreach ($adminQueries as $label => $sql) {
        $statement = $connection->prepare($sql);
        if ($label === 'admin vaccine list') {
            $statement->execute([
                'search' => $search,
                'vaccine' => $term,
                'pet' => $term,
                'owner' => $term,
                'status_filter' => $statusFilter,
                'computed_status' => $statusFilter,
            ]);
        } elseif ($label === 'admin reminders list') {
            $statement->execute([
                'search' => $search,
                'pet' => $term,
                'owner' => $term,
                'vaccine' => $term,
                'message' => $term,
            ]);
        } else {
            $statement->execute();
        }
        $statement->fetchAll();
        $assert(true, "{$label} query should run against the live schema.");
    }

    $connection->prepare('UPDATE users SET role = :role WHERE user_id = :user_id')
        ->execute(['role' => 'user', 'user_id' => 0]);
    $connection->prepare('UPDATE users SET is_active = :is_active WHERE user_id = :user_id')
        ->execute(['is_active' => 1, 'user_id' => 0]);
    $connection->prepare('DELETE FROM users WHERE user_id = :user_id')
        ->execute(['user_id' => 0]);
    $connection->prepare('UPDATE users SET name = :name, email = :email, phone = :phone, preferred_clinic = :clinic WHERE user_id = :user_id')
        ->execute(['name' => 'No user', 'email' => 'nobody@example.invalid', 'phone' => null, 'clinic' => null, 'user_id' => 0]);
    $connection->prepare('UPDATE vaccine_types SET name = :name, schedule_days = :schedule_days, description = :description WHERE vaccine_type_id = :id')
        ->execute(['name' => 'No vaccine type', 'schedule_days' => 365, 'description' => null, 'id' => 0]);
    $connection->prepare('DELETE FROM vaccine_types WHERE vaccine_type_id = :id')->execute(['id' => 0]);

    $statusQuery = $connection->prepare(
        "SELECT {$statusSql} AS computed_status
         FROM (
             SELECT :done_status AS status, :done_due AS next_due_date
             UNION ALL SELECT NULL, :overdue_due
             UNION ALL SELECT NULL, CURDATE()
             UNION ALL SELECT NULL, DATE_ADD(CURDATE(), INTERVAL 31 DAY)
         ) v"
    );
    $statusQuery->execute([
        'done_status' => 'done',
        'done_due' => $yesterday,
        'overdue_due' => $yesterday,
    ]);
    $statuses = $statusQuery->fetchAll(PDO::FETCH_COLUMN);
    $assert($statuses === ['done', 'overdue', 'due_soon', 'upcoming'], 'Computed vaccine statuses should cover all states.');
} finally {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }
}

echo "Passed {$assertions} PetCare Log checks.\n";
