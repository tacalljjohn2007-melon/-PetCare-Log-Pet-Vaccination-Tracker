<button class="petcare-theme-toggle" id="petcareThemeToggle" type="button" aria-label="Switch to light mode" title="Switch to light mode">
  <span class="material-symbols-outlined" id="petcareThemeIcon" aria-hidden="true">light_mode</span>
</button>
