<?php
require_once __DIR__ . '/../config/auth.php';
?>
<script>
  window.PETCARE_CSRF_TOKEN = <?php echo json_encode(csrfToken(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
  window.PETCARE_PREFERENCES_URL = <?php echo json_encode(appUrl('/php/preferences.php'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
  window.PETCARE_IS_AUTHENTICATED = <?php echo currentUserId() > 0 ? 'true' : 'false'; ?>;
  document.querySelectorAll('form[method="post" i]').forEach((form) => {
    if (!form.querySelector('input[name="csrf_token"]')) {
      const token = document.createElement("input");
      token.type = "hidden";
      token.name = "csrf_token";
      token.value = window.PETCARE_CSRF_TOKEN;
      form.append(token);
    }
  });
</script>
<script src="<?php echo escapeHtml(appUrl('/js/theme.js')); ?>" defer></script>
