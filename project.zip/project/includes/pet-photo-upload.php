<?php
function receivePetPhoto(): ?string
{
    if (!isset($_FILES['photo']) || $_FILES['photo']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES['photo'];
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024
        || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Choose an image smaller than 5 MB.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $imageInfo = @getimagesize($file['tmp_name']);
    if (!isset($extensions[$mime]) || $imageInfo === false || $imageInfo['mime'] !== $mime) {
        throw new RuntimeException('Pet photos must be JPG, PNG, or WebP images.');
    }
    $directory = __DIR__ . '/../uploads/pets';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('The photo upload directory could not be created.');
    }
    $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
        throw new RuntimeException('The pet photo could not be saved.');
    }
    return 'uploads/pets/' . $filename;
}

function deletePetPhoto(?string $photo): void
{
    if ($photo === null || !preg_match('/^uploads\/pets\/[a-f0-9]{32}\.(?:jpg|png|webp)$/', $photo)) {
        return;
    }

    $path = __DIR__ . '/../' . $photo;
    if (is_file($path) && !unlink($path)) {
        throw new RuntimeException('The previous pet photo could not be removed.');
    }
}
