<?php
require_once __DIR__ . '/../config/auth.php';
startPetCareSession();
$isAdmin = currentUserRole() === 'admin';
$sidebarUser = userProfile(currentUserId());
$activePage = $activePage ?? '';
$links = $isAdmin
    ? [
        'dashboard' => ['Admin Dashboard', 'dashboard', '/admin/dashboard.php'],
        'users' => ['Manage Users', 'group', '/admin/users.php'],
        'pets' => ['All Pets', 'pets', '/admin/pets.php'],
        'vaccines' => ['All Vaccines', 'vaccines', '/admin/vaccines.php'],
        'vaccine-types' => ['Vaccine Types', 'category', '/admin/vaccine-types.php'],
        'certificates' => ['Certificates', 'workspace_premium', '/admin/certificates.php'],
        'reminders' => ['Reminders Overview', 'notifications_active', '/admin/reminders.php'],
        'settings' => ['Settings', 'settings', '/admin/settings.php'],
    ]
    : [
        'dashboard' => ['Dashboard', 'dashboard', '/php/dashboard.php'],
        'pets' => ['My Pets', 'pets', '/php/petprofile.php'],
        'certificates' => ['Certificates', 'workspace_premium', '/php/certificates.php'],
        'reminders' => ['Reminders', 'notifications_active', '/php/reminders.php'],
        'settings' => ['Settings', 'settings', '/php/setting.php'],
    ];
?>
<button class="petcare-menu-toggle" id="petcareMenuToggle" type="button" aria-label="Open navigation menu" aria-controls="sidebar" aria-expanded="false">
  <span class="material-symbols-outlined" aria-hidden="true">menu</span>
</button>
<aside id="sidebar" class="fixed left-4 top-4 bottom-4 z-40 w-64 rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-[0_10px_28px_rgba(30,41,59,0.06)] -translate-x-[110%] md:translate-x-0">
  <div class="flex h-full flex-col p-4">
    <div class="flex items-center gap-3 pb-5 pl-1">
      <div class="flex h-8 w-8 items-center justify-center rounded-xl bg-[#dff7ef] text-[#0e9f73]"><span class="material-symbols-outlined text-[22px]" aria-hidden="true"><?php echo escapeHtml($isAdmin ? 'shield' : 'health_and_safety'); ?></span></div>
      <div class="flex flex-col leading-none">
        <span class="font-bold text-primary">PetCare Log</span>
        <span class="mt-1 text-[11px] text-on-surface-variant"><?php echo escapeHtml($isAdmin ? 'Admin Console' : 'Pet Vaccination Tracker'); ?></span>
      </div>
    </div>
    <nav class="mt-4 space-y-2">
      <?php foreach ($links as $key => [$label, $icon, $path]): ?>
        <a class="sidebar-link flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-medium transition <?php echo escapeHtml($activePage === $key ? 'active font-semibold' : 'text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'); ?>" href="<?php echo escapeHtml(appUrl($path)); ?>"<?php echo escapeHtml($activePage === $key ? ' aria-current="page"' : ''); ?>>
          <span class="material-symbols-outlined sidebar-icon text-[20px]" aria-hidden="true"><?php echo escapeHtml($icon); ?></span><span><?php echo escapeHtml($label); ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="mt-auto border-t border-[#dfe7f2] pt-4">
      <div class="flex items-center gap-3 px-2 py-2">
        <img class="h-9 w-9 rounded-full object-cover" src="<?php echo escapeHtml(profilePhotoUrl($sidebarUser['profile_photo'] ?? null)); ?>" alt="<?php echo escapeHtml(($sidebarUser['name'] ?? 'User') . ' profile photo'); ?>" />
        <div class="flex flex-col leading-tight">
          <span class="text-[13px] font-semibold text-on-surface"><?php echo escapeHtml($sidebarUser['name'] ?? 'User'); ?></span>
          <span class="text-[11px] text-on-surface-variant"><?php echo escapeHtml($isAdmin ? 'Administrator' : 'Pet Owner'); ?></span>
        </div>
      </div>
      <form class="mt-3" method="post" action="<?php echo escapeHtml(appUrl('/logout.php')); ?>" data-logout-form>
        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
        <button class="flex w-full items-center gap-2 rounded-xl px-3 py-3 text-left text-[13px] font-medium text-on-surface-variant transition hover:bg-surface-container-low hover:text-on-surface" type="submit"><span class="material-symbols-outlined sidebar-icon text-[20px]" aria-hidden="true">logout</span><span>Log Out</span></button>
      </form>
    </div>
  </div>
</aside>
