<?php
require_once __DIR__ . '/../config/auth.php';
$themeFallback = currentUserId() > 0 ? userTheme(currentUserId()) : 'system';
$languageFallback = currentUserId() > 0 ? userLanguage(currentUserId()) : 'en-US';
?>
<script>
  window.PETCARE_LANGUAGE = <?php echo json_encode($languageFallback); ?>;
  document.documentElement.lang = window.PETCARE_LANGUAGE;
  try {
    const saved = localStorage.getItem("petcare-theme");
    const serverTheme = <?php echo json_encode($themeFallback); ?>;
    document.documentElement.dataset.theme = saved === "dark" || saved === "light"
      ? saved
      : serverTheme === "dark" || serverTheme === "light"
        ? serverTheme
        : matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  } catch (error) {
    document.documentElement.dataset.theme =
      matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
</script>
<link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/css/theme.css')); ?>" />
