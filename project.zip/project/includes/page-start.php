<?php
require_once __DIR__ . '/../config/auth.php';
$pageTitle = $pageTitle ?? 'PetCare Log';
$activePage = $activePage ?? '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <?php include __DIR__ . '/header.php'; ?>
  <title><?php echo escapeHtml($pageTitle); ?> | PetCare Log</title>
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/fonts.css')); ?>" />
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/material-symbols.css')); ?>" />
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/tailwind.css')); ?>" />
  <style>
    body{font-family:Inter,sans-serif}
    .petcare-card{background:var(--bg-card);border:1px solid var(--border);color:var(--text-primary)}
    .petcare-field{background:var(--bg-input);border:1px solid var(--border);color:var(--text-primary)}
  </style>
</head>
<body class="min-h-screen antialiased">
  <?php require_once __DIR__ . '/sidebar.php'; ?>
  <main class="ml-0 min-h-screen w-full px-4 pb-8 pt-5 md:ml-72 md:w-[calc(100%-18rem)] md:px-8">
  <div class="petcare-page-toolbar">
    <?php include __DIR__ . '/theme-toggle.php'; ?>
  </div>
