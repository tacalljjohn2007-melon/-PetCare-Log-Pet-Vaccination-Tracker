<?php

require_once __DIR__ . '/../config/auth.php';

function petCarePublicBaseUrl(): string
{
    $configuredUrl = trim((string) getenv('PETCARE_BASE_URL'));
    if ($configuredUrl === '') {
        if (getenv('PETCARE_DEBUG') !== '1') {
            error_log('PetCare Log configuration error: PETCARE_BASE_URL is required outside debug mode.');
            throw new RuntimeException('Password reset email is not configured.');
        }
        $configuredUrl = 'http://localhost' . appBasePath();
    }
    return rtrim($configuredUrl, '/');
}

function sendPetCareMail(string $recipient, string $subject, string $message): bool
{
    $from = trim((string) (getenv('PETCARE_MAIL_FROM') ?: 'no-reply@petcare.local'));
    $fromName = trim((string) (getenv('PETCARE_MAIL_FROM_NAME') ?: 'PetCare Log'));
    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL) || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('A valid mail recipient and sender address are required.');
    }
    $fromName = str_replace(["\r", "\n"], '', $fromName);
    $subject = str_replace(["\r", "\n"], '', $subject);
    $headers = [
        'From: ' . (function_exists('mb_encode_mimeheader') ? mb_encode_mimeheader($fromName, 'UTF-8') : $fromName) . ' <' . $from . '>',
        'Content-Type: text/plain; charset=UTF-8',
        'X-Mailer: PetCare Log',
    ];
    $sent = mail($recipient, $subject, $message, implode("\r\n", $headers));
    if (!$sent) {
        error_log('PetCare Log mail delivery failed.');
    }
    return $sent;
}
