<?php
$pageTitle = $pageTitle ?? 'Admin';
include __DIR__ . '/page-start.php';
