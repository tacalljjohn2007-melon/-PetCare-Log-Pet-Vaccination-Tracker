<?php

function receiveProfilePhoto(): ?string
{
    if (!isset($_FILES['profile_photo']) || $_FILES['profile_photo']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $file = $_FILES['profile_photo'];
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024
        || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Choose a profile photo no larger than 5 MB.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $imageInfo = @getimagesize($file['tmp_name']);
    if (!isset($extensions[$mime]) || $imageInfo === false || $imageInfo['mime'] !== $mime) {
        throw new RuntimeException('Profile photos must be valid JPG, PNG, or WebP images.');
    }

    $directory = __DIR__ . '/../uploads/profiles';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('The profile photo upload directory could not be created.');
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
        throw new RuntimeException('The profile photo could not be saved.');
    }

    return 'uploads/profiles/' . $filename;
}

function deleteProfilePhoto(?string $photo): void
{
    if ($photo === null || !preg_match('/^uploads\/profiles\/[a-f0-9]{32}\.(?:jpg|png|webp)$/', $photo)) {
        return;
    }

    $path = __DIR__ . '/../' . $photo;
    if (is_file($path) && !unlink($path)) {
        throw new RuntimeException('The previous profile photo could not be removed.');
    }
}
