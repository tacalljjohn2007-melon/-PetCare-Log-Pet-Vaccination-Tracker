<section class="mb-6 rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
  <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <h2 class="text-xl font-bold text-on-surface">Manage your pets</h2>
  </div>
  <?php if (!$pets): ?>
    <p class="text-on-surface-variant">You have not added any pets yet.</p>
  <?php else: ?>
    <div class="space-y-4">
      <?php foreach ($pets as $pet): ?>
        <form method="post" enctype="multipart/form-data" class="grid gap-3 rounded-xl border border-[#dfe7f2] bg-white p-4 md:grid-cols-4">
          <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
          <input type="hidden" name="pet_id" value="<?php echo (int) $pet['id']; ?>" />
          <?php if (!empty($pet['photo'])): ?><img class="h-20 w-20 rounded-xl object-cover" src="<?php echo escapeHtml(appUrl('/' . ltrim($pet['photo'], '/'))); ?>" alt="<?php echo escapeHtml($pet['name']); ?>" /><?php endif; ?>
          <a class="self-center text-sm font-semibold text-primary underline md:col-span-4" href="<?php echo escapeHtml(appUrl('/php/pet-detail.php?id=' . (int) $pet['id'])); ?>">View breed, age and recommended vaccines</a>
          <label class="text-sm font-medium text-on-surface-variant">Name
            <input class="mt-1 w-full rounded-lg border px-3 py-2" name="name" maxlength="100" required value="<?php echo escapeHtml($pet['name']); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Species
            <input class="mt-1 w-full rounded-lg border px-3 py-2" name="species" maxlength="50" required value="<?php echo escapeHtml($pet['species']); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Breed
            <input class="mt-1 w-full rounded-lg border px-3 py-2" name="breed" maxlength="100" value="<?php echo escapeHtml($pet['breed'] ?? ''); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Birthdate
            <input class="mt-1 w-full rounded-lg border px-3 py-2" type="date" name="birthdate" value="<?php echo escapeHtml($pet['birth_date'] ?? ''); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Photo (JPG, PNG, WebP; max 5 MB)
            <input class="mt-1 block w-full text-sm" type="file" name="photo" accept="image/jpeg,image/png,image/webp" />
          </label>
          <div class="flex flex-wrap gap-2 md:col-span-4">
            <button class="rounded-lg bg-primary px-3 py-2 text-sm font-medium text-white" type="submit" name="action" value="save_pet">Save pet</button>
            <button class="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white" type="submit" name="action" value="delete_pet" onclick="return confirm('Delete this pet and its records?')">Delete pet</button>
          </div>
        </form>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
