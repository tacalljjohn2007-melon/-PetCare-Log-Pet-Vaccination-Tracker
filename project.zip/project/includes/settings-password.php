<section class="mt-6 rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
  <h2 class="mb-4 text-xl font-bold text-on-surface">Change password</h2>
  <form method="post" action="<?php echo escapeHtml(appUrl('/php/setting.php')); ?>" class="grid gap-4 md:grid-cols-2">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <input type="hidden" name="action" value="change_password" />
    <label class="text-sm font-medium text-on-surface-variant">Current password
      <input class="mt-1 w-full rounded-xl border px-3 py-2" type="password" name="current_password" autocomplete="current-password" required />
    </label>
    <label class="text-sm font-medium text-on-surface-variant">New password (at least 8 characters)
      <input class="mt-1 w-full rounded-xl border px-3 py-2" type="password" name="new_password" minlength="8" autocomplete="new-password" required />
    </label>
    <button class="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-white md:col-span-2 md:justify-self-start" type="submit">Update password</button>
  </form>
</section>
