<section class="mb-6 rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
  <h2 class="mb-4 text-xl font-bold text-on-surface">Manage reminders</h2>
  <?php if (!$pets): ?>
    <p class="mb-5 rounded-xl p-4 text-on-surface-variant" style="background:var(--bg-card-hover)">Add a pet before creating reminders.</p>
  <?php else: ?>
  <form method="post" class="mb-5 grid gap-3 rounded-xl border border-[#dfe7f2] bg-white p-4 md:grid-cols-4">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <input type="hidden" name="action" value="save_reminder" />
    <label class="text-sm font-medium text-on-surface-variant">Pet
      <select class="mt-1 w-full rounded-lg border px-3 py-2" name="pet_id" required>
        <?php foreach ($pets as $pet): ?><option value="<?php echo (int) $pet['id']; ?>"><?php echo escapeHtml($pet['name']); ?></option><?php endforeach; ?>
      </select>
    </label>
    <label class="text-sm font-medium text-on-surface-variant">Vaccine (optional)
      <select class="mt-1 w-full rounded-lg border px-3 py-2" name="vaccine_id">
        <option value="0">General reminder</option>
        <?php foreach ($vaccinations as $item): ?><option value="<?php echo (int) $item['id']; ?>" data-pet-id="<?php echo (int) $item['pet_id']; ?>"><?php echo escapeHtml($item['pet_name'] . ' — ' . $item['vaccine_name']); ?></option><?php endforeach; ?>
      </select>
    </label>
    <label class="text-sm font-medium text-on-surface-variant">Reminder date
      <input class="mt-1 w-full rounded-lg border px-3 py-2" type="date" name="remind_date" required />
    </label>
    <label class="text-sm font-medium text-on-surface-variant">Status
      <select class="mt-1 w-full rounded-lg border px-3 py-2" name="status"><option value="pending">Pending</option><option value="completed">Completed</option></select>
    </label>
    <button class="rounded-lg bg-primary px-3 py-2 text-sm font-medium text-white md:col-span-4 md:justify-self-start" type="submit">Add reminder</button>
  </form>
  <?php endif; ?>
  <?php if (!empty($_GET['saved'])): ?><p class="mb-3 font-medium text-primary">Reminder saved.</p><?php endif; ?>
  <?php if (!empty($_GET['error'])): ?><p class="mb-3 font-medium text-red-700">Please select your own pet and a valid date.</p><?php endif; ?>
  <?php if (!$reminders): ?>
    <p class="text-on-surface-variant">No reminders have been created yet. Adding a vaccine with a due date creates one automatically.</p>
  <?php else: ?>
    <div class="space-y-3">
      <?php foreach ($reminders as $reminder): ?>
        <div class="rounded-xl border border-[#dfe7f2] bg-white p-4">
          <div class="mb-3 font-semibold text-on-surface"><?php echo escapeHtml(($reminder['pet_name'] ?? '') . ' — ' . ($reminder['vaccine_name'] ?? 'General reminder')); ?></div>
          <div class="flex flex-wrap items-end justify-between gap-3">
            <form method="post" class="flex flex-wrap items-end gap-3">
              <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
              <input type="hidden" name="action" value="save_reminder" />
              <input type="hidden" name="reminder_id" value="<?php echo (int) $reminder['id']; ?>" />
              <input type="hidden" name="pet_id" value="<?php echo (int) $reminder['pet_id']; ?>" />
              <input type="hidden" name="vaccine_id" value="<?php echo (int) $reminder['vaccine_id']; ?>" />
              <label class="text-sm font-medium text-on-surface-variant">Message
                <input class="mt-1 rounded-lg border px-3 py-2" type="text" value="<?php echo escapeHtml($reminder['message'] ?? 'Pet care reminder'); ?>" readonly />
              </label>
              <label class="text-sm font-medium text-on-surface-variant">Reminder date
                <input class="mt-1 rounded-lg border px-3 py-2" type="date" name="remind_date" required value="<?php echo escapeHtml($reminder['remind_date']); ?>" />
              </label>
              <label class="text-sm font-medium text-on-surface-variant">Status
                <select class="mt-1 rounded-lg border px-3 py-2" name="status">
                  <option value="pending"<?php echo $reminder['status'] === 'pending' ? ' selected' : ''; ?>>Pending</option>
                  <option value="completed"<?php echo $reminder['status'] === 'completed' ? ' selected' : ''; ?>>Completed</option>
                </select>
              </label>
              <button class="rounded-lg bg-primary px-3 py-2 text-sm font-medium text-white" type="submit">Save</button>
            </form>
            <form method="post" onsubmit="return confirm('Delete this reminder?')">
              <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
              <input type="hidden" name="reminder_id" value="<?php echo (int) $reminder['id']; ?>" />
              <button class="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white" name="action" value="delete_reminder">Delete</button>
            </form>
            <?php if ($reminder['status'] === 'pending'): ?>
              <form method="post">
                <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                <input type="hidden" name="reminder_id" value="<?php echo (int) $reminder['id']; ?>" />
                <button class="rounded-lg bg-primary px-3 py-2 text-sm font-medium text-white" name="action" value="complete_reminder">Complete</button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
