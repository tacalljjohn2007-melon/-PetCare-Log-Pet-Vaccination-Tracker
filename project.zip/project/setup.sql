CREATE DATABASE IF NOT EXISTS petcare_log
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE petcare_log;

CREATE TABLE IF NOT EXISTS users (
  user_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('user', 'manager', 'admin') NOT NULL DEFAULT 'user',
  phone VARCHAR(30) DEFAULT NULL,
  preferred_clinic VARCHAR(150) DEFAULT NULL,
  profile_photo VARCHAR(255) DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pets (
  pet_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  species VARCHAR(50) NOT NULL,
  breed VARCHAR(100) DEFAULT NULL,
  birth_date DATE DEFAULT NULL,
  photo VARCHAR(255) DEFAULT NULL,
  sex VARCHAR(30) DEFAULT NULL,
  weight DECIMAL(6,2) DEFAULT NULL,
  weight_unit VARCHAR(10) NOT NULL DEFAULT 'lbs',
  microchip_number VARCHAR(100) DEFAULT NULL,
  clinic VARCHAR(150) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (pet_id),
  KEY idx_pets_user_id (user_id),
  CONSTRAINT fk_pets_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vaccinations (
  vaccination_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  pet_id INT UNSIGNED NOT NULL,
  vaccine_name VARCHAR(150) NOT NULL,
  vaccine_type VARCHAR(100) DEFAULT NULL,
  administration_date DATE NOT NULL,
  next_due_date DATE NOT NULL,
  vet_name VARCHAR(150) DEFAULT NULL,
  veterinarian VARCHAR(150) DEFAULT NULL,
  clinic VARCHAR(150) DEFAULT NULL,
  lot_number VARCHAR(100) DEFAULT NULL,
  notes TEXT DEFAULT NULL,
  status ENUM('upcoming', 'due_soon', 'overdue', 'done') NOT NULL DEFAULT 'upcoming',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (vaccination_id),
  KEY idx_vaccinations_pet_id (pet_id),
  KEY idx_vaccinations_next_due_date (next_due_date),
  CONSTRAINT fk_vaccinations_pet FOREIGN KEY (pet_id) REFERENCES pets (pet_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reminders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  pet_id INT UNSIGNED NOT NULL,
  vaccine_id INT UNSIGNED DEFAULT NULL,
  remind_date DATE NOT NULL,
  message VARCHAR(255) NOT NULL DEFAULT 'Vaccination due',
  is_done TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('pending', 'completed', 'dismissed') NOT NULL DEFAULT 'pending',
  last_notified_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_reminders_user_date (user_id, remind_date),
  KEY idx_reminders_pet_date (pet_id, remind_date),
  KEY idx_reminders_vaccine (vaccine_id),
  CONSTRAINT fk_reminders_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_reminders_pet FOREIGN KEY (pet_id) REFERENCES pets (pet_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_reminders_vaccination FOREIGN KEY (vaccine_id) REFERENCES vaccinations (vaccination_id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  user_id INT UNSIGNED NOT NULL,
  theme ENUM('light', 'dark') DEFAULT NULL,
  language VARCHAR(10) NOT NULL DEFAULT 'en-US',
  notifications_enabled TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_settings_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notification_preferences (
  preference_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  email_enabled TINYINT(1) NOT NULL DEFAULT 1,
  sms_enabled TINYINT(1) NOT NULL DEFAULT 0,
  reminder_enabled TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (preference_id),
  UNIQUE KEY uq_notification_preferences_user_id (user_id),
  CONSTRAINT fk_notification_preferences_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
  password_reset_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (password_reset_id),
  UNIQUE KEY uq_password_resets_token_hash (token_hash),
  KEY idx_password_resets_user_id (user_id),
  CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(190) NOT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  successful TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_login_attempts_email_time (email, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vaccine_types (
  vaccine_type_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  schedule_days INT UNSIGNED NOT NULL DEFAULT 365,
  description TEXT DEFAULT NULL,
  PRIMARY KEY (vaccine_type_id),
  UNIQUE KEY uq_vaccine_types_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS petcare_log_migrate_missing_columns;
DELIMITER $$
CREATE PROCEDURE petcare_log_migrate_missing_columns()
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'settings'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'settings'
      AND column_name = 'language'
  ) THEN
    ALTER TABLE settings ADD COLUMN language VARCHAR(10) NOT NULL DEFAULT 'en-US' AFTER theme;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'users'
  ) THEN
    ALTER TABLE users MODIFY role ENUM('user', 'manager', 'admin') NOT NULL DEFAULT 'user';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'users'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'users'
      AND column_name = 'profile_photo'
  ) THEN
    ALTER TABLE users ADD COLUMN profile_photo VARCHAR(255) DEFAULT NULL AFTER preferred_clinic;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'users'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'users'
      AND column_name = 'is_active'
  ) THEN
    ALTER TABLE users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'reminders'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'reminders'
      AND column_name = 'last_notified_at'
  ) THEN
    ALTER TABLE reminders ADD COLUMN last_notified_at DATETIME DEFAULT NULL AFTER status;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'vaccinations'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'vaccinations'
      AND column_name = 'vaccine_type'
  ) THEN
    ALTER TABLE vaccinations ADD COLUMN vaccine_type VARCHAR(100) DEFAULT NULL AFTER vaccine_name;
  END IF;
END$$
DELIMITER ;
CALL petcare_log_migrate_missing_columns();
DROP PROCEDURE petcare_log_migrate_missing_columns;

-- Existing user rows are intentionally left unchanged during setup.
-- Seed accounts are added safely by setup-sample-data.sql when absent.

INSERT IGNORE INTO vaccine_types (name, schedule_days, description)
VALUES ('Rabies', 1095, 'Rabies vaccination schedule.'),
       ('DHPP', 365, 'Core canine vaccination.'),
       ('FVRCP', 365, 'Core feline vaccination.');

CREATE TABLE IF NOT EXISTS pet_certificates (
  certificate_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  pet_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  certificate_code CHAR(12) NOT NULL,
  issued_by INT UNSIGNED DEFAULT NULL,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at DATETIME DEFAULT NULL,
  PRIMARY KEY (certificate_id),
  UNIQUE KEY uq_pet_certificates_code (certificate_code),
  KEY idx_pet_certificates_pet (pet_id),
  KEY idx_pet_certificates_user (user_id),
  CONSTRAINT fk_pet_certificates_pet FOREIGN KEY (pet_id) REFERENCES pets (pet_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_pet_certificates_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS petcare_log_migrate_vaccine_species;
DELIMITER $$
CREATE PROCEDURE petcare_log_migrate_vaccine_species()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'vaccine_types' AND column_name = 'species'
  ) THEN
    ALTER TABLE vaccine_types ADD COLUMN species VARCHAR(50) DEFAULT NULL AFTER description;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'vaccine_types' AND column_name = 'is_required'
  ) THEN
    ALTER TABLE vaccine_types ADD COLUMN is_required TINYINT(1) NOT NULL DEFAULT 0 AFTER species;
  END IF;
END$$
DELIMITER ;
CALL petcare_log_migrate_vaccine_species();
DROP PROCEDURE petcare_log_migrate_vaccine_species;

-- Default species and required vaccines. Only fills rows that have no species yet,
-- so choices the admin makes later are not overwritten when setup is re-run.
UPDATE vaccine_types SET species = 'Dog', is_required = 1 WHERE name IN ('DHPP', 'Rabies') AND species IS NULL;
UPDATE vaccine_types SET species = 'Cat', is_required = 1 WHERE name = 'FVRCP' AND species IS NULL;
INSERT IGNORE INTO vaccine_types (name, schedule_days, description, species, is_required)
VALUES ('Bordetella', 365, 'Optional kennel cough vaccine for dogs.', 'Dog', 0);
