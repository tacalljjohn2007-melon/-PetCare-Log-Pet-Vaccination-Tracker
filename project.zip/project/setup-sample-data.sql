USE petcare_log;

INSERT IGNORE INTO users (name, email, password, role, preferred_clinic) VALUES
  ('PetCare Admin', 'admin@petcarelog.test', '$2y$10$Ogt9laVxzmB7IWA1NQFN8.tj2a3IVOnepb7kbDdx1y365UwGQeZzK', 'admin', 'Cedar Grove Animal Hospital'),
  ('PetCare User', 'user@petcarelog.test', '$2y$10$xgfeqvB3f2KPKOV2YqQqbukyJ7wvWKMMwo1GdOLgtf.JkLMQuGBmm', 'user', 'Oak Valley Vet Clinic');

-- Repair only the old broken seed hash; customized passwords are never replaced.
UPDATE users
SET password = '$2y$10$xgfeqvB3f2KPKOV2YqQqbukyJ7wvWKMMwo1GdOLgtf.JkLMQuGBmm'
WHERE email = 'user@petcarelog.test'
  AND password = '$2y$10$x0HMDq2RDg6vNthYAKXXyudDPctyJwwCSw8nFQyw.N2BnpJYmELA6';

UPDATE users
SET password = '$2y$10$Ogt9laVxzmB7IWA1NQFN8.tj2a3IVOnepb7kbDdx1y365UwGQeZzK'
WHERE email = 'admin@petcarelog.test'
  AND password = '$2y$10$X49SlggCluzPGafLSBKJtejmBWhGs7Cq9qztwqzIukESDMc9/XyuW';

INSERT IGNORE INTO users (name, email, password, role, preferred_clinic) VALUES
  ('PetCare Admin', 'admin@gmail.com', '$2y$10$Ogt9laVxzmB7IWA1NQFN8.tj2a3IVOnepb7kbDdx1y365UwGQeZzK', 'admin', 'Cedar Grove Animal Hospital'),
  ('PetCare User', 'user@gmail.com', '$2y$10$xgfeqvB3f2KPKOV2YqQqbukyJ7wvWKMMwo1GdOLgtf.JkLMQuGBmm', 'user', 'Oak Valley Vet Clinic');

INSERT IGNORE INTO settings (user_id)
  SELECT user_id FROM users
  WHERE email IN ('admin@gmail.com', 'user@gmail.com', 'admin@petcarelog.test', 'user@petcarelog.test');

-- Isolated ownership demo for the test user. These inserts never replace existing rows.
INSERT INTO pets (user_id, name, species, breed, birth_date)
  SELECT user_id, 'Portal Demo', 'Cat', 'Domestic Shorthair', '2021-01-01'
  FROM users u
  WHERE u.email = 'user@petcarelog.test'
    AND NOT EXISTS (
      SELECT 1 FROM pets p
      WHERE p.user_id = u.user_id AND p.name = 'Portal Demo'
    );

INSERT INTO vaccinations (pet_id, vaccine_name, vaccine_type, administration_date, next_due_date, status, notes)
  SELECT p.pet_id, 'FVRCP', 'FVRCP', CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 365 DAY), 'done', 'Ownership demo vaccine.'
  FROM pets p
  INNER JOIN users u ON u.user_id = p.user_id
  WHERE u.email = 'user@petcarelog.test' AND p.name = 'Portal Demo'
    AND NOT EXISTS (
      SELECT 1 FROM vaccinations v
      WHERE v.pet_id = p.pet_id AND v.vaccine_type = 'FVRCP'
    );

INSERT INTO pets (user_id, name, species, breed, birth_date)
  SELECT user_id, 'Buddy', 'Dog', 'Golden Retriever', '2022-03-15'
  FROM users u
  WHERE u.email = 'user@gmail.com'
    AND NOT EXISTS (
      SELECT 1 FROM pets p
      WHERE p.user_id = u.user_id AND p.name = 'Buddy' AND p.species = 'Dog'
    );

INSERT INTO vaccinations (pet_id, vaccine_name, vaccine_type, administration_date, next_due_date, notes)
  SELECT p.pet_id, 'Rabies', 'Core', CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY), 'Sample upcoming vaccine.'
  FROM pets p
  INNER JOIN users u ON u.user_id = p.user_id
  WHERE u.email = 'user@gmail.com' AND p.name = 'Buddy'
    AND NOT EXISTS (
      SELECT 1 FROM vaccinations v
      WHERE v.pet_id = p.pet_id AND v.vaccine_name = 'Rabies'
    );

INSERT INTO reminders (user_id, pet_id, vaccine_id, remind_date, status)
  SELECT u.user_id, p.pet_id, v.vaccination_id, v.next_due_date, 'pending'
  FROM users u
  INNER JOIN pets p ON p.user_id = u.user_id AND p.name = 'Buddy'
  INNER JOIN vaccinations v ON v.pet_id = p.pet_id AND v.vaccine_name = 'Rabies'
  WHERE u.email = 'user@gmail.com'
    AND NOT EXISTS (
      SELECT 1 FROM reminders r
      WHERE r.user_id = u.user_id AND r.pet_id = p.pet_id AND r.vaccine_id = v.vaccination_id
    );

-- Demo dog Buddy has every required dog vaccine done, so the certificate flow can be tried.
INSERT INTO vaccinations (pet_id, vaccine_name, vaccine_type, administration_date, next_due_date, status, notes)
  SELECT p.pet_id, 'DHPP', 'DHPP', CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 365 DAY), 'done', 'Sample completed vaccine.'
  FROM pets p INNER JOIN users u ON u.user_id = p.user_id
  WHERE u.email = 'user@gmail.com' AND p.name = 'Buddy'
    AND NOT EXISTS (SELECT 1 FROM vaccinations v WHERE v.pet_id = p.pet_id AND v.vaccine_name = 'DHPP');

INSERT INTO vaccinations (pet_id, vaccine_name, vaccine_type, administration_date, next_due_date, status, notes)
  SELECT p.pet_id, 'Rabies (sample)', 'Rabies', CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 1095 DAY), 'done', 'Sample completed vaccine.'
  FROM pets p INNER JOIN users u ON u.user_id = p.user_id
  WHERE u.email = 'user@gmail.com' AND p.name = 'Buddy'
    AND NOT EXISTS (SELECT 1 FROM vaccinations v WHERE v.pet_id = p.pet_id AND v.vaccine_type = 'Rabies');
