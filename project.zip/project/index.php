<?php
require_once __DIR__ . '/config/auth.php';
if (currentUserId() > 0) {
    if (currentUserRole() === 'admin') {
        redirectToAdminDashboard();
    }
    redirectToUserDashboard();
}
header('Location: ' . appUrl('/html/login.php'));
exit;
