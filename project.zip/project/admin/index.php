<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();
header('Location: ' . appUrl('/admin/dashboard.php'));
exit;
