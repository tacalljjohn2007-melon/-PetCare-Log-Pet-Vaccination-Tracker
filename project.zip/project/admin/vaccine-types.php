<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int) ($_POST['vaccine_type_id'] ?? 0);
        $name = trim((string) ($_POST['name'] ?? ''));
        $scheduleDays = (int) ($_POST['schedule_days'] ?? 365);
        $description = trim((string) ($_POST['description'] ?? ''));
        $species = trim((string) ($_POST['species'] ?? '')) ?: null;
        $isRequired = !empty($_POST['is_required']) ? 1 : 0;
        if ($name !== '' && strlen($name) <= 150 && $scheduleDays >= 1 && $scheduleDays <= 36500
            && strlen($description) <= 5000) {
            if ($id > 0) {
                db()->prepare('UPDATE vaccine_types SET name = :name, schedule_days = :schedule_days, description = :description, species = :species, is_required = :is_required WHERE vaccine_type_id = :id')->execute([
                    'name' => $name,
                    'schedule_days' => $scheduleDays,
                    'description' => $description,
                    'species' => $species,
                    'is_required' => $isRequired,
                    'id' => $id,
                ]);
            } else {
                db()->prepare('INSERT INTO vaccine_types (name, schedule_days, description, species, is_required) VALUES (:name, :schedule_days, :description, :species, :is_required)')->execute([
                    'name' => $name,
                    'schedule_days' => $scheduleDays,
                    'description' => $description,
                    'species' => $species,
                    'is_required' => $isRequired,
                ]);
            }
        }
    }
    if ($action === 'delete') {
        $id = (int) ($_POST['vaccine_type_id'] ?? 0);
        if ($id > 0) {
            db()->prepare('DELETE FROM vaccine_types WHERE vaccine_type_id = :id')->execute(['id' => $id]);
        }
    }
    header('Location: ' . appUrl('/admin/vaccine-types.php'));
    exit;
}

$selected = null;
if (!empty($_GET['edit'])) {
    $selected = db()->prepare('SELECT * FROM vaccine_types WHERE vaccine_type_id = :id LIMIT 1');
    $selected->execute(['id' => (int) $_GET['edit']]);
    $selected = $selected->fetch();
}

$vaccineTypesQuery = db()->prepare('SELECT * FROM vaccine_types ORDER BY name ASC');
$vaccineTypesQuery->execute();
$vaccineTypes = $vaccineTypesQuery->fetchAll();
?>
<?php $activePage = 'vaccine-types'; $pageTitle = 'Vaccine Types'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <div class="flex items-center justify-between pb-6">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">Schedule catalog</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">Vaccine Types</h1>
        </div>
      </div>

      <div class="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <section class="rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
          <h2 class="text-xl font-bold text-on-surface"><?php echo escapeHtml($selected ? 'Edit vaccine type' : 'Add vaccine type'); ?></h2>
          <form method="post" class="mt-4 space-y-4">
            <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
            <input type="hidden" name="action" value="save" />
            <?php if ($selected): ?><input type="hidden" name="vaccine_type_id" value="<?php echo (int) $selected['vaccine_type_id']; ?>" /><?php endif; ?>
            <div>
              <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="vaccineTypeName">Vaccine name</label>
              <input id="vaccineTypeName" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="text" name="name" value="<?php echo escapeHtml($selected['name'] ?? ''); ?>" required />
            </div>
            <div>
              <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="scheduleDays">Schedule days</label>
              <input id="scheduleDays" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="number" name="schedule_days" min="1" value="<?php echo (int) ($selected['schedule_days'] ?? 365); ?>" required />
            </div>
            <div>
              <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="vaccineTypeSpecies">Compatible species</label>
              <input id="vaccineTypeSpecies" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="text" name="species" maxlength="50" placeholder="e.g. Dog" value="<?php echo escapeHtml($selected['species'] ?? ''); ?>" />
            </div>
            <label class="flex items-center gap-2 text-sm font-medium text-on-surface-variant">
              <input type="checkbox" name="is_required" value="1"<?php echo !empty($selected['is_required']) ? ' checked' : ''; ?> /> Recommendation: required for a completed vaccination cycle (certificate)
            </label>
            <div>
              <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="vaccineTypeDescription">Recommendation / notes</label>
              <textarea id="vaccineTypeDescription" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="description" rows="4"><?php echo escapeHtml($selected['description'] ?? ''); ?></textarea>
            </div>
            <div class="flex gap-3">
              <button type="submit" class="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-white"><?php echo escapeHtml($selected ? 'Update' : 'Create'); ?></button>
              <?php if ($selected): ?><a class="rounded-xl border border-[#dfe7f2] bg-white px-4 py-2 text-sm font-medium text-on-surface" href="<?php echo escapeHtml(appUrl('/admin/vaccine-types.php')); ?>">Cancel</a><?php endif; ?>
            </div>
          </form>
        </section>

        <section class="rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
          <h2 class="text-xl font-bold text-on-surface">Current catalog</h2>
          <div class="mt-4 space-y-3">
            <?php foreach ($vaccineTypes as $type): ?>
              <div class="flex items-center justify-between gap-3 rounded-xl bg-white p-3">
                <div>
                  <div class="font-semibold text-on-surface">Vaccine name: <?php echo escapeHtml($type['name']); ?></div>
                  <div class="text-sm text-on-surface-variant">Compatible species: <?php echo escapeHtml($type['species'] ?: 'All species'); ?> | <?php echo (int) $type['schedule_days']; ?> day schedule</div>
                  <div class="text-sm text-on-surface-variant">Recommendation: <?php echo !empty($type['is_required']) ? 'Required for a completed vaccination cycle' : 'Optional'; ?></div>
                  <?php if (trim((string) ($type['description'] ?? '')) !== ''): ?>
                    <div class="mt-1 text-sm text-on-surface-variant">Notes: <?php echo escapeHtml($type['description']); ?></div>
                  <?php endif; ?>
                </div>
                <div class="flex gap-2">
                  <a class="rounded-lg bg-[#dff7ef] px-2 py-1 text-xs font-medium text-primary" href="<?php echo escapeHtml(appUrl('/admin/vaccine-types.php?edit=' . (int) $type['vaccine_type_id'])); ?>">Edit</a>
                  <form method="post" onsubmit="return confirm('Delete this vaccine type?');">
                    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                    <input type="hidden" name="action" value="delete" />
                    <input type="hidden" name="vaccine_type_id" value="<?php echo (int) $type['vaccine_type_id']; ?>" />
                    <button type="submit" class="rounded-lg bg-red-600 px-2 py-1 text-xs font-medium text-white">Delete</button>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </section>
      </div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
