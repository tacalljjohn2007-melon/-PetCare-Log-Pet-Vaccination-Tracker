<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = (string) ($_POST['action'] ?? '');
    $vaccineId = filter_var($_POST['vaccine_id'] ?? null, FILTER_VALIDATE_INT);
    $vaccineId = $vaccineId === false ? 0 : (int) $vaccineId;

    if ($action === 'mark_done') {
        $dateGiven = trim((string) ($_POST['administration_date'] ?? ''));
        if ($vaccineId < 1 || !isDateOnOrBeforeToday($dateGiven)) {
            redirectAfterPost(appUrl('/admin/vaccines.php?error=1'));
        }

        db()->prepare(
            "UPDATE vaccinations
             SET status = 'done', administration_date = :administration_date
             WHERE vaccination_id = :vaccine_id"
        )->execute([
            'administration_date' => $dateGiven,
            'vaccine_id' => $vaccineId,
        ]);
        redirectAfterPost(appUrl('/admin/vaccines.php?done=1'));
    }

    if ($action === 'save_vaccine') {
        $petId = filter_var($_POST['pet_id'] ?? null, FILTER_VALIDATE_INT);
        $petId = $petId === false ? 0 : (int) $petId;
        $vaccineName = trim((string) ($_POST['vaccine_name'] ?? ''));
        $vaccineType = trim((string) ($_POST['vaccine_type'] ?? ''));
        $dateGiven = trim((string) ($_POST['administration_date'] ?? ''));
        $nextDueDate = trim((string) ($_POST['next_due_date'] ?? ''));
        $clinic = trim((string) ($_POST['clinic'] ?? ''));
        $lotNumber = trim((string) ($_POST['lot_number'] ?? ''));
        $notes = trim((string) ($_POST['notes'] ?? ''));

        $petQuery = db()->prepare('SELECT pet_id FROM pets WHERE pet_id = :pet_id LIMIT 1');
        $petQuery->execute(['pet_id' => $petId]);
        $petExists = $petId > 0 && $petQuery->fetch() !== false;
        if (!$petExists || $vaccineName === '' || strlen($vaccineName) > 150
            || strlen($vaccineType) > 100 || strlen($clinic) > 150 || strlen($lotNumber) > 100
            || strlen($notes) > 5000 || !isValidVaccineDateRange($dateGiven, $nextDueDate)) {
            redirectAfterPost(appUrl('/admin/vaccines.php?error=1'));
        }

        $parameters = [
            'pet_id' => $petId,
            'vaccine_name' => $vaccineName,
            'vaccine_type' => $vaccineType !== '' ? $vaccineType : null,
            'administration_date' => $dateGiven,
            'next_due_date' => $nextDueDate,
            'clinic' => $clinic !== '' ? $clinic : null,
            'lot_number' => $lotNumber !== '' ? $lotNumber : null,
            'notes' => $notes !== '' ? $notes : null,
        ];

        if ($vaccineId > 0) {
            $existingQuery = db()->prepare('SELECT vaccination_id FROM vaccinations WHERE vaccination_id = :vaccine_id LIMIT 1');
            $existingQuery->execute(['vaccine_id' => $vaccineId]);
            if (!$existingQuery->fetch()) {
                redirectAfterPost(appUrl('/admin/vaccines.php?error=1'));
            }

            db()->prepare(
                'UPDATE vaccinations
                 SET pet_id = :pet_id, vaccine_name = :vaccine_name, vaccine_type = :vaccine_type,
                     administration_date = :administration_date, next_due_date = :next_due_date,
                     clinic = :clinic, lot_number = :lot_number, notes = :notes
                 WHERE vaccination_id = :vaccine_id'
            )->execute($parameters + ['vaccine_id' => $vaccineId]);
        } else {
            db()->prepare(
                'INSERT INTO vaccinations
                    (pet_id, vaccine_name, vaccine_type, administration_date, next_due_date, clinic, lot_number, notes)
                 VALUES
                    (:pet_id, :vaccine_name, :vaccine_type, :administration_date, :next_due_date, :clinic, :lot_number, :notes)'
            )->execute($parameters);
        }
        redirectAfterPost(appUrl('/admin/vaccines.php?saved=1'));
    }

    redirectAfterPost(appUrl('/admin/vaccines.php?error=1'));
}

$search = trim((string) ($_GET['q'] ?? ''));
$statusFilter = (string) ($_GET['status'] ?? 'all');
$statusFilter = in_array($statusFilter, ['all', 'upcoming', 'due_soon', 'overdue', 'done'], true)
    ? $statusFilter
    : 'all';
$petFilter = max(0, (int) ($_GET['pet_id'] ?? 0));
$term = '%' . $search . '%';
$computedStatusSql = vaccineStatusCaseSql('v');

$statement = db()->prepare(
    "SELECT v.vaccination_id AS id, v.pet_id, v.vaccine_name, v.vaccine_type,
            v.administration_date AS date_given, v.next_due_date, v.clinic, v.lot_number,
            v.notes, p.name AS pet_name, p.species, u.name AS owner_name, u.email AS owner_email,
            {$computedStatusSql} AS computed_status
     FROM vaccinations v
     INNER JOIN pets p ON p.pet_id = v.pet_id
     INNER JOIN users u ON u.user_id = p.user_id
     WHERE (:search = '' OR v.vaccine_name LIKE :vaccine OR v.vaccine_type LIKE :vaccine_type
            OR p.name LIKE :pet OR u.name LIKE :owner OR u.email LIKE :owner_email)
       AND (:status_filter = 'all' OR ({$computedStatusSql}) = :computed_status)
       AND (:pet_filter_check = 0 OR p.pet_id = :pet_filter_value)
     ORDER BY v.next_due_date, p.name, v.administration_date DESC"
);
$statement->execute([
    'search' => $search,
    'vaccine' => $term,
    'vaccine_type' => $term,
    'pet' => $term,
    'owner' => $term,
    'owner_email' => $term,
    'status_filter' => $statusFilter,
    'computed_status' => $statusFilter,
    'pet_filter_check' => $petFilter,
    'pet_filter_value' => $petFilter,
]);
$vaccines = $statement->fetchAll();

$petsQuery = db()->prepare(
    'SELECT p.pet_id AS id, p.name, p.species, u.name AS owner_name
     FROM pets p INNER JOIN users u ON u.user_id = p.user_id
     ORDER BY u.name, p.name'
);
$petsQuery->execute();
$pets = $petsQuery->fetchAll();
$vaccineTypeOptions = vaccineTypeOptions();

$selected = null;
$editId = filter_var($_GET['edit'] ?? null, FILTER_VALIDATE_INT);
if ($editId !== false && $editId !== null && $editId > 0) {
    $selectedQuery = db()->prepare('SELECT * FROM vaccinations WHERE vaccination_id = :vaccine_id LIMIT 1');
    $selectedQuery->execute(['vaccine_id' => $editId]);
    $selected = $selectedQuery->fetch() ?: null;
}
$selectedVaccineType = trim((string) ($selected['vaccine_type'] ?? ''));
if ($selectedVaccineType !== '' && !in_array($selectedVaccineType, $vaccineTypeOptions, true)) {
    $vaccineTypeOptions[] = $selectedVaccineType;
}
?>
<?php $activePage = 'vaccines'; $pageTitle = 'All Vaccines'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <header class="mb-6">
        <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">System-wide registry</p>
        <h1 class="mt-2 text-3xl font-bold text-on-surface">All Vaccines</h1>
        <p class="mt-2 text-on-surface-variant">Add and update vaccination records for any pet. Marking a record done requires the administration date.</p>
      </header>

      <?php if (!empty($_GET['saved'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Vaccine record saved.</p><?php endif; ?>
      <?php if (!empty($_GET['done'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Vaccine marked done.</p><?php endif; ?>
      <?php if (!empty($_GET['error'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)">Enter a valid pet, vaccine name, and date range.</p><?php endif; ?>

      <section class="mb-6 rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
        <h2 class="text-xl font-bold text-on-surface"><?php echo escapeHtml($selected ? 'Edit vaccine record' : 'Add vaccine record'); ?></h2>
        <form method="post" class="mt-4 grid gap-4 md:grid-cols-2">
          <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
          <input type="hidden" name="action" value="save_vaccine" />
          <?php if ($selected): ?><input type="hidden" name="vaccine_id" value="<?php echo (int) $selected['vaccination_id']; ?>" /><?php endif; ?>
          <label class="text-sm font-medium text-on-surface-variant md:col-span-2">Pet
            <select class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="pet_id" required>
              <option value="">Select a pet</option>
              <?php foreach ($pets as $pet): ?><option value="<?php echo (int) $pet['id']; ?>"<?php echo (int) ($selected['pet_id'] ?? 0) === (int) $pet['id'] ? ' selected' : ''; ?>><?php echo escapeHtml($pet['name'] . ' (' . $pet['species'] . ') · ' . $pet['owner_name']); ?></option><?php endforeach; ?>
            </select>
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Vaccine name
            <input class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="vaccine_name" maxlength="150" required value="<?php echo escapeHtml($selected['vaccine_name'] ?? ''); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Vaccine type
            <select class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="vaccine_type">
              <option value="">Not specified</option>
              <?php foreach ($vaccineTypeOptions as $type): ?><option value="<?php echo escapeHtml($type); ?>"<?php echo $selectedVaccineType === $type ? ' selected' : ''; ?>><?php echo escapeHtml($type); ?></option><?php endforeach; ?>
            </select>
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Date given
            <input class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="date" name="administration_date" required value="<?php echo escapeHtml($selected['administration_date'] ?? date('Y-m-d')); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Next due date
            <input class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="date" name="next_due_date" required value="<?php echo escapeHtml($selected['next_due_date'] ?? date('Y-m-d', strtotime('+365 days'))); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Clinic / veterinarian
            <input class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="clinic" maxlength="150" value="<?php echo escapeHtml($selected['clinic'] ?? ''); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant">Lot number
            <input class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="lot_number" maxlength="100" value="<?php echo escapeHtml($selected['lot_number'] ?? ''); ?>" />
          </label>
          <label class="text-sm font-medium text-on-surface-variant md:col-span-2">Notes
            <textarea class="mt-1 w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" name="notes" rows="3" maxlength="5000"><?php echo escapeHtml($selected['notes'] ?? ''); ?></textarea>
          </label>
          <div class="flex gap-3 md:col-span-2">
            <button class="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-white" type="submit"><?php echo escapeHtml($selected ? 'Update vaccine' : 'Add vaccine'); ?></button>
            <?php if ($selected): ?><a class="rounded-xl border border-[#dfe7f2] bg-white px-4 py-2 text-sm font-medium text-on-surface" href="<?php echo escapeHtml(appUrl('/admin/vaccines.php')); ?>">Cancel</a><?php endif; ?>
          </div>
        </form>
      </section>

      <form method="get" class="mb-4 flex flex-wrap gap-2">
        <input class="rounded-xl border bg-white px-3 py-2" type="search" name="q" aria-label="Search vaccines, pets, and owners" value="<?php echo escapeHtml($search); ?>" placeholder="Search vaccine, pet, owner" />
        <select class="rounded-xl border bg-white px-3 py-2" name="pet_id" aria-label="Filter vaccines by pet">
          <option value="0">All pets</option>
          <?php foreach ($pets as $pet): ?><option value="<?php echo (int) $pet['id']; ?>"<?php echo $petFilter === (int) $pet['id'] ? ' selected' : ''; ?>><?php echo escapeHtml($pet['name'] . ' (' . $pet['species'] . ')'); ?></option><?php endforeach; ?>
        </select>
        <select class="rounded-xl border bg-white px-3 py-2" name="status" aria-label="Filter vaccines by status">
          <?php foreach (['all' => 'All statuses', 'upcoming' => 'Upcoming', 'due_soon' => 'Due soon', 'overdue' => 'Overdue', 'done' => 'Done'] as $value => $label): ?><option value="<?php echo escapeHtml($value); ?>"<?php echo $statusFilter === $value ? ' selected' : ''; ?>><?php echo escapeHtml($label); ?></option><?php endforeach; ?>
        </select>
        <button class="rounded-xl bg-primary px-3 py-2 font-medium text-white" type="submit">Apply filters</button>
      </form>

      <div class="overflow-x-auto rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-sm">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-white text-on-surface-variant">
            <tr><th class="px-4 py-3">Vaccine</th><th class="px-4 py-3">Type</th><th class="px-4 py-3">Pet</th><th class="px-4 py-3">Owner</th><th class="px-4 py-3">Given</th><th class="px-4 py-3">Next due</th><th class="px-4 py-3">Status</th><th class="px-4 py-3">Action</th></tr>
          </thead>
          <tbody class="divide-y divide-[#dfe7f2]">
            <?php foreach ($vaccines as $vaccine): ?>
              <tr>
                <td class="px-4 py-3 font-medium text-on-surface"><?php echo escapeHtml($vaccine['vaccine_name']); ?></td>
                <td class="px-4 py-3 text-on-surface"><?php echo escapeHtml($vaccine['vaccine_type'] ?? 'Not specified'); ?></td>
                <td class="px-4 py-3 text-on-surface"><?php echo escapeHtml($vaccine['pet_name'] . ' (' . $vaccine['species'] . ')'); ?></td>
                <td class="px-4 py-3 text-on-surface"><?php echo escapeHtml($vaccine['owner_name'] . ' · ' . $vaccine['owner_email']); ?></td>
                <td class="px-4 py-3 text-on-surface"><?php echo escapeHtml($vaccine['date_given']); ?></td>
                <td class="px-4 py-3 text-on-surface"><?php echo escapeHtml($vaccine['next_due_date']); ?></td>
                <td class="px-4 py-3 text-on-surface"><?php echo escapeHtml(ucwords(str_replace('_', ' ', $vaccine['computed_status']))); ?></td>
                <td class="px-4 py-3">
                  <div class="flex min-w-[13rem] flex-wrap items-center gap-2">
                    <a class="rounded-lg border border-[#dfe7f2] bg-white px-3 py-2 text-sm font-medium" href="<?php echo escapeHtml(appUrl('/admin/vaccines.php?edit=' . (int) $vaccine['id'])); ?>">Edit</a>
                    <?php if ($vaccine['computed_status'] !== 'done'): ?>
                      <form method="post" class="flex flex-wrap items-center gap-2">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                        <input type="hidden" name="action" value="mark_done" />
                        <input type="hidden" name="vaccine_id" value="<?php echo (int) $vaccine['id']; ?>" />
                        <label class="sr-only" for="doneDate<?php echo (int) $vaccine['id']; ?>">Date done</label>
                        <input id="doneDate<?php echo (int) $vaccine['id']; ?>" class="rounded-lg border px-2 py-2" type="date" name="administration_date" required value="<?php echo escapeHtml($vaccine['date_given']); ?>" />
                        <button class="rounded-lg bg-primary px-3 py-2 text-sm font-medium text-white" type="submit">Mark done</button>
                      </form>
                    <?php else: ?>
                      <span class="font-medium text-primary">Done</span>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$vaccines): ?><tr><td class="px-4 py-5 text-on-surface-variant" colspan="8">No vaccine records found.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
