<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();

$search = trim((string) ($_GET['q'] ?? ''));
$petsQuery = db()->prepare(
    'SELECT p.*, u.name AS owner_name FROM pets p
     INNER JOIN users u ON u.user_id = p.user_id
     WHERE (:search_name = \'\' OR p.name LIKE :pet_name OR p.species LIKE :species OR u.name LIKE :owner_name OR u.email LIKE :owner_email)
     ORDER BY u.name, p.name ASC'
);
$term = '%' . $search . '%';
$petsQuery->execute(['search_name' => $search, 'pet_name' => $term, 'species' => $term, 'owner_name' => $term, 'owner_email' => $term]);
$pets = $petsQuery->fetchAll();
?>
<?php $activePage = 'pets'; $pageTitle = 'All Pets'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <div class="flex items-center justify-between pb-6">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">System-wide registry</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">All Pets</h1>
        </div>
        <form method="get" class="flex gap-2"><input class="rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="search" name="q" aria-label="Search pets or owners" value="<?php echo escapeHtml($search); ?>" placeholder="Search pets or owners" /><button class="rounded-xl bg-primary px-3 py-2 font-medium text-white" type="submit">Search</button></form>
      </div>

      <div class="overflow-hidden rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-sm">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-white text-on-surface-variant">
            <tr>
              <th class="px-4 py-3">Pet</th>
              <th class="px-4 py-3">Owner</th>
              <th class="px-4 py-3">Species</th>
              <th class="px-4 py-3">Breed</th>
              <th class="px-4 py-3">Clinic</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($pets as $pet): ?>
              <tr class="border-t border-[#e5ebf7]">
                <td class="px-4 py-3 font-medium text-on-surface"><?php echo escapeHtml($pet['name']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($pet['owner_name']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($pet['species']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($pet['breed'] ?? '—'); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($pet['clinic'] ?? '—'); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
