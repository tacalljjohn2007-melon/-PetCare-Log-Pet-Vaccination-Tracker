<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/profile-photo-upload.php';

$userId = currentUserId();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $name = trim((string) ($_POST['fullName'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $phone = trim((string) ($_POST['phone'] ?? '')) ?: null;
    $clinic = trim((string) ($_POST['clinic'] ?? '')) ?: null;
    if ($name === '' || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || strlen($email) > 190 || ($phone !== null && strlen($phone) > 30)
        || ($clinic !== null && strlen($clinic) > 150)) {
        header('Location: ' . appUrl('/admin/settings.php?error=1'));
        exit;
    }
    $duplicateEmail = db()->prepare('SELECT user_id FROM users WHERE email = :email AND user_id <> :user_id LIMIT 1');
    $duplicateEmail->execute(['email' => $email, 'user_id' => $userId]);
    if ($duplicateEmail->fetch()) {
        header('Location: ' . appUrl('/admin/settings.php?error=1'));
        exit;
    }

    try {
        $newPhoto = receiveProfilePhoto();
    } catch (RuntimeException $exception) {
        header('Location: ' . appUrl('/admin/settings.php?upload_error=1'));
        exit;
    }
    $user = userProfile($userId);
    $photoSql = $newPhoto !== null ? ', profile_photo = :profile_photo' : '';
    $parameters = [
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'clinic' => $clinic,
        'user_id' => $userId,
    ];
    if ($newPhoto !== null) {
        $parameters['profile_photo'] = $newPhoto;
    }
    try {
        db()->prepare(
            "UPDATE users SET name = :name, email = :email, phone = :phone, preferred_clinic = :clinic{$photoSql}
             WHERE user_id = :user_id"
        )->execute($parameters);
    } catch (PDOException $exception) {
        if ($newPhoto !== null) {
            deleteProfilePhoto($newPhoto);
        }
        if ($exception->getCode() === '23000') {
            header('Location: ' . appUrl('/admin/settings.php?error=1'));
            exit;
        }
        throw $exception;
    } catch (Throwable $exception) {
        if ($newPhoto !== null) {
            deleteProfilePhoto($newPhoto);
        }
        throw $exception;
    }
    if ($newPhoto !== null) {
        deleteProfilePhoto($user['profile_photo'] ?? null);
    }
    $_SESSION['username'] = $name;
    header('Location: ' . appUrl('/admin/settings.php?saved=1'));
    exit;
}

$user = userProfile($userId);
?>
<?php $activePage = 'settings'; $pageTitle = 'Admin Settings'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <div class="flex items-center justify-between pb-6">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">Account</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">Administrative Settings</h1>
        </div>
      </div>

      <div class="rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
        <?php if (!empty($_GET['saved'])): ?><div class="mb-4 rounded-xl bg-[#dff7ef] px-3 py-2 text-sm font-medium text-primary">Profile saved successfully.</div><?php endif; ?>
        <?php if (!empty($_GET['error'])): ?><div class="mb-4 rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-red-700">Enter a valid name and email address not used by another account.</div><?php endif; ?>
        <?php if (!empty($_GET['upload_error'])): ?><div class="mb-4 rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-red-700">Profile photo upload failed. Use a valid JPG, PNG, or WebP image no larger than 5 MB.</div><?php endif; ?>
        <form method="post" enctype="multipart/form-data" class="grid gap-4 md:grid-cols-2">
          <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
          <div class="flex items-center gap-4 md:col-span-2">
            <img class="h-20 w-20 rounded-full object-cover" src="<?php echo escapeHtml(profilePhotoUrl($user['profile_photo'] ?? null)); ?>" alt="<?php echo escapeHtml(($user['name'] ?? 'User') . ' profile photo'); ?>" />
            <label class="text-sm font-medium text-on-surface-variant">Profile photo (JPG, PNG, WebP; max 5 MB)
              <input class="mt-1 block w-full text-sm" type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp" />
            </label>
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="fullName">Full name</label>
            <input id="fullName" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="text" name="fullName" value="<?php echo escapeHtml($user['name'] ?? ''); ?>" required />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="email">Email</label>
            <input id="email" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="email" name="email" value="<?php echo escapeHtml($user['email'] ?? ''); ?>" required />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="phone">Phone</label>
            <input id="phone" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="text" name="phone" value="<?php echo escapeHtml($user['phone'] ?? ''); ?>" />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-on-surface-variant" for="clinic">Preferred clinic</label>
            <input id="clinic" class="w-full rounded-xl border border-[#dfe7f2] bg-white px-3 py-2" type="text" name="clinic" value="<?php echo escapeHtml($user['preferred_clinic'] ?? ''); ?>" />
          </div>
          <div class="md:col-span-2 flex gap-3">
            <button class="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-white" type="submit">Save profile</button>
          </div>
        </form>
      </div>
      <section class="mt-6 rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
        <h2 class="mb-2 text-xl font-bold text-on-surface">Language</h2>
        <p class="mb-4 text-sm text-on-surface-variant">Choose the language used across your account</p>
        <div class="flex flex-col items-start gap-2">
          <label class="text-sm font-medium text-on-surface-variant" for="languageSelect">Language</label>
          <select id="languageSelect" class="rounded-xl border border-[#dfe7f2] bg-white px-3 py-2 text-on-surface">
            <option value="en-US">English (US)</option>
            <option value="en-GB">English (UK)</option>
            <option value="es-ES">Español</option>
            <option value="fr-CA">Français (Canada)</option>
            <option value="de-DE">Deutsch</option>
            <option value="tl-PH">Tagalog</option>
          </select>
          <span id="languageSavedMessage" class="text-sm font-medium text-primary" aria-live="polite" hidden>Language saved</span>
        </div>
      </section>
      <form class="mt-4" method="post" action="<?php echo escapeHtml(appUrl('/logout.php')); ?>" data-logout-form>
        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
        <button class="rounded-xl border border-[#dfe7f2] bg-white px-4 py-2 text-sm font-medium text-on-surface" type="submit">Logout</button>
      </form>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
