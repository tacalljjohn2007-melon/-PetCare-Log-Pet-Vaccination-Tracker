<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();

$usersCountQuery = db()->prepare('SELECT COUNT(*) AS total FROM users');
$usersCountQuery->execute();
$usersCount = (int) $usersCountQuery->fetch()['total'];
$petsCountQuery = db()->prepare('SELECT COUNT(*) AS total FROM pets');
$petsCountQuery->execute();
$petsCount = (int) $petsCountQuery->fetch()['total'];
$vaccinationsCountQuery = db()->prepare('SELECT COUNT(*) AS total FROM vaccinations');
$vaccinationsCountQuery->execute();
$vaccinationsCount = (int) $vaccinationsCountQuery->fetch()['total'];
$overdueQuery = db()->prepare(
    "SELECT COUNT(*) AS total FROM vaccinations v INNER JOIN pets p ON p.pet_id = v.pet_id
     WHERE v.status <> 'done' AND v.next_due_date < CURDATE()"
);
$overdueQuery->execute();
$overdueCount = (int) $overdueQuery->fetch()['total'];

$recentUsersQuery = db()->prepare(
    'SELECT user_id, name, email, role, is_active FROM users ORDER BY created_at DESC LIMIT 5'
);
$recentUsersQuery->execute();
$recentUsers = $recentUsersQuery->fetchAll();

$recentRemindersQuery = db()->prepare(
    "SELECT r.remind_date AS next_due_date, p.name AS pet_name, u.name AS owner_name
     FROM reminders r
     INNER JOIN pets p ON p.pet_id = r.pet_id
     INNER JOIN users u ON u.user_id = r.user_id
     WHERE r.status = 'pending'
     ORDER BY r.remind_date ASC LIMIT 5"
);
$recentRemindersQuery->execute();
$recentReminders = $recentRemindersQuery->fetchAll();
?>
<?php $activePage = 'dashboard'; $pageTitle = 'Admin Dashboard'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <div class="flex items-center justify-between gap-4 pb-6">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">Operations overview</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">Admin Dashboard</h1>
        </div>
      </div>

      <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <a href="<?php echo escapeHtml(appUrl('/admin/users.php')); ?>" class="petcare-card petcare-summary-link block rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between"><span class="text-sm text-on-surface-variant">Total users</span><span class="material-symbols-outlined text-primary">group</span></div>
          <div class="mt-4 text-3xl font-bold text-on-surface"><?php echo (int) $usersCount; ?></div>
        </a>
        <a href="<?php echo escapeHtml(appUrl('/admin/pets.php')); ?>" class="petcare-card petcare-summary-link block rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between"><span class="text-sm text-on-surface-variant">Total pets</span><span class="material-symbols-outlined text-primary">pets</span></div>
          <div class="mt-4 text-3xl font-bold text-on-surface"><?php echo (int) $petsCount; ?></div>
        </a>
        <a href="<?php echo escapeHtml(appUrl('/admin/vaccines.php')); ?>" class="petcare-card petcare-summary-link block rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between"><span class="text-sm text-on-surface-variant">Total vaccinations</span><span class="material-symbols-outlined text-primary">vaccines</span></div>
          <div class="mt-4 text-3xl font-bold text-on-surface"><?php echo (int) $vaccinationsCount; ?></div>
        </a>
        <a href="<?php echo escapeHtml(appUrl('/admin/vaccines.php?status=overdue')); ?>" class="petcare-card petcare-summary-link block rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between"><span class="text-sm text-on-surface-variant">Overdue count</span><span class="material-symbols-outlined text-primary">warning</span></div>
          <div class="mt-4 text-3xl font-bold text-on-surface"><?php echo (int) $overdueCount; ?></div>
        </a>
      </div>

      <div class="mt-8 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <section class="rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
          <div class="mb-4 flex items-center justify-between">
            <h2 class="text-xl font-bold text-on-surface">Recent users</h2>
            <a href="<?php echo escapeHtml(appUrl('/admin/users.php')); ?>" class="text-sm font-semibold text-primary">View all</a>
          </div>
          <div class="space-y-3">
            <?php foreach ($recentUsers as $user): ?>
              <div class="flex items-center justify-between rounded-xl bg-white p-3">
                <div>
                  <div class="font-semibold text-on-surface"><?php echo escapeHtml($user['name']); ?></div>
                  <div class="text-sm text-on-surface-variant"><?php echo escapeHtml($user['email']); ?></div>
                </div>
                <div class="text-right text-sm">
                  <div class="rounded-full bg-[#dff7ef] px-2 py-1 text-xs font-medium text-primary"><?php echo escapeHtml(strtoupper($user['role'])); ?></div>
                  <div class="mt-1 text-on-surface-variant"><?php echo (int) $user['is_active'] === 1 ? 'Active' : 'Inactive'; ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </section>

        <section class="rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] p-5 shadow-sm">
          <div class="flex items-center justify-between gap-3">
            <h2 class="text-xl font-bold text-on-surface">Upcoming reminders</h2>
            <a href="<?php echo escapeHtml(appUrl('/admin/reminders.php')); ?>" class="font-semibold text-primary hover:underline">View all</a>
          </div>
          <div class="mt-4 space-y-3">
            <?php foreach ($recentReminders as $reminder): ?>
              <div class="rounded-xl bg-white p-3">
                <div class="font-semibold text-on-surface"><?php echo escapeHtml($reminder['pet_name']); ?></div>
                <div class="text-sm text-on-surface-variant"><?php echo escapeHtml($reminder['owner_name']); ?></div>
                <div class="mt-1 text-sm font-medium text-primary"><?php echo escapeHtml($reminder['next_due_date']); ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        </section>
      </div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
