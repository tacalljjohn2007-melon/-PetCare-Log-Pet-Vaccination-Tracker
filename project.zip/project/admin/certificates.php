<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/pet-care.php';
$adminId = requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = (string) ($_POST['action'] ?? '');
    $petId = filter_var($_POST['pet_id'] ?? null, FILTER_VALIDATE_INT);

    if ($petId && $action === 'issue') {
        $petQuery = db()->prepare('SELECT pet_id, user_id, species FROM pets WHERE pet_id = :pet_id LIMIT 1');
        $petQuery->execute(['pet_id' => $petId]);
        $pet = $petQuery->fetch();
        if ($pet && activeCertificateForPet((int) $pet['pet_id']) === null
            && vaccineCycleStatus((int) $pet['pet_id'], (string) $pet['species'])['complete']) {
            db()->prepare(
                'INSERT INTO pet_certificates (pet_id, user_id, certificate_code, issued_by)
                 VALUES (:pet_id, :user_id, :code, :issued_by)'
            )->execute([
                'pet_id' => $pet['pet_id'],
                'user_id' => $pet['user_id'],
                'code' => newCertificateCode(),
                'issued_by' => $adminId,
            ]);
        }
        redirectAfterPost(appUrl('/admin/certificates.php?done=issued'));
    }

    if ($petId && $action === 'revoke') {
        db()->prepare('UPDATE pet_certificates SET revoked_at = NOW() WHERE pet_id = :pet_id AND revoked_at IS NULL')
            ->execute(['pet_id' => $petId]);
        redirectAfterPost(appUrl('/admin/certificates.php?done=revoked'));
    }

    redirectAfterPost(appUrl('/admin/certificates.php'));
}

$petsQuery = db()->prepare(
    'SELECT p.pet_id, p.user_id, p.name, p.species, p.breed, u.name AS owner_name, u.email
     FROM pets p INNER JOIN users u ON u.user_id = p.user_id
     ORDER BY u.name, p.name'
);
$petsQuery->execute();
$pets = $petsQuery->fetchAll();

$rows = [];
foreach ($pets as $pet) {
    $petId = (int) $pet['pet_id'];
    $cycle = vaccineCycleStatus($petId, (string) $pet['species']);
    $certificate = activeCertificateForPet($petId);
    if ($certificate) {
        $state = 'Issued';
    } elseif ($cycle['complete']) {
        $state = 'Ready';
    } else {
        $state = 'In progress';
    }
    $rows[] = ['pet' => $pet, 'cycle' => $cycle, 'certificate' => $certificate, 'state' => $state];
}

$activePage = 'certificates';
$pageTitle = 'Certificates';
include __DIR__ . '/../includes/admin-page-start.php';
?>
      <div class="flex items-center justify-between pb-6">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">Completion</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">Certificates</h1>
        </div>
      </div>
      <?php if (($_GET['done'] ?? '') === 'issued'): ?><p class="mb-4 font-medium text-primary">Certificate issued. The owner can now see it under Certificates.</p><?php endif; ?>
      <?php if (($_GET['done'] ?? '') === 'revoked'): ?><p class="mb-4 font-medium text-red-700">Certificate revoked. The owner can no longer see it.</p><?php endif; ?>
      <p class="mb-4 text-sm text-on-surface-variant">A pet is ready once every required vaccine for its species is marked done. You decide when to issue the certificate, and you can revoke it later.</p>

      <div class="overflow-hidden rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-sm">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-white text-on-surface-variant">
            <tr>
              <th class="px-4 py-3">Owner</th>
              <th class="px-4 py-3">Pet</th>
              <th class="px-4 py-3">Breed</th>
              <th class="px-4 py-3">Progress</th>
              <th class="px-4 py-3">State</th>
              <th class="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $row): $pet = $row['pet']; $cycle = $row['cycle']; ?>
              <tr class="border-t border-[#e5ebf7]">
                <td class="px-4 py-3 font-medium text-on-surface"><?php echo escapeHtml($pet['owner_name']); ?><div class="text-xs text-on-surface-variant"><?php echo escapeHtml($pet['email']); ?></div></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($pet['name'] . ' (' . $pet['species'] . ')'); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($pet['breed'] ?: '—'); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo (int) $cycle['required_done']; ?> / <?php echo (int) $cycle['required_total']; ?> required</td>
                <td class="px-4 py-3"><span class="rounded-full px-2 py-1 text-xs font-medium <?php echo $row['state'] === 'In progress' ? 'bg-[#eef2f7] text-on-surface-variant' : 'bg-[#dff7ef] text-primary'; ?>"><?php echo escapeHtml($row['state']); ?></span></td>
                <td class="px-4 py-3">
                  <div class="flex flex-wrap gap-2">
                    <?php if ($row['certificate']): ?>
                      <a class="rounded-lg border px-3 py-2 text-sm font-medium" href="<?php echo escapeHtml(appUrl('/php/certificate.php?code=' . $row['certificate']['certificate_code'])); ?>">View</a>
                      <form method="post" onsubmit="return confirm('Revoke this certificate?')">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                        <input type="hidden" name="pet_id" value="<?php echo (int) $pet['pet_id']; ?>" />
                        <button class="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white" name="action" value="revoke" type="submit">Revoke</button>
                      </form>
                    <?php elseif ($row['state'] === 'Ready'): ?>
                      <form method="post">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                        <input type="hidden" name="pet_id" value="<?php echo (int) $pet['pet_id']; ?>" />
                        <button class="rounded-lg bg-primary px-3 py-2 text-sm font-medium text-white" name="action" value="issue" type="submit">Issue</button>
                      </form>
                    <?php else: ?>
                      <span class="text-on-surface-variant">—</span>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php if (!$rows): ?><p class="mt-4 text-on-surface-variant">No pets registered yet.</p><?php endif; ?>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
