<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();

$search = trim((string) ($_GET['q'] ?? ''));
$searchClause = '';
$params = [];
if ($search !== '') {
    $searchClause = ' WHERE u.name LIKE :name_term OR u.email LIKE :email_term';
    $params['name_term'] = '%' . $search . '%';
    $params['email_term'] = '%' . $search . '%';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = $_POST['action'] ?? '';
    $userId = (int) ($_POST['user_id'] ?? 0);
    if ($action === 'update_role' && $userId > 0) {
        $role = (string) ($_POST['role'] ?? '');
        $targetQuery = db()->prepare('SELECT role FROM users WHERE user_id = :user_id LIMIT 1');
        $targetQuery->execute(['user_id' => $userId]);
        $currentRole = (string) ($targetQuery->fetchColumn() ?: '');
        $roleError = adminRoleChangeError(
            $currentRole,
            $role,
            $userId === (int) $_SESSION['user_id']
        );
        if ($roleError !== null) {
            http_response_code(403);
            exit($roleError);
        }
        db()->prepare('UPDATE users SET role = :role WHERE user_id = :user_id')->execute(['role' => $role, 'user_id' => $userId]);
    }
    if ($action === 'toggle_status' && $userId > 0) {
        if ($userId !== (int) $_SESSION['user_id']) {
            $newStatus = (int) ($_POST['is_active'] ?? 0) === 1 ? 1 : 0;
            db()->prepare('UPDATE users SET is_active = :is_active WHERE user_id = :user_id')->execute(['is_active' => $newStatus, 'user_id' => $userId]);
        }
    }
    if ($action === 'delete_user' && $userId > 0 && $userId !== (int) $_SESSION['user_id']) {
        $targetQuery = db()->prepare('SELECT role FROM users WHERE user_id = :user_id LIMIT 1');
        $targetQuery->execute(['user_id' => $userId]);
        if (in_array((string) $targetQuery->fetchColumn(), ['user', 'manager'], true)) {
            db()->prepare('DELETE FROM users WHERE user_id = :user_id')->execute(['user_id' => $userId]);
        }
    }
    header('Location: ' . appUrl('/admin/users.php') . ($search !== '' ? '?q=' . urlencode($search) : ''));
    exit;
}

$statement = db()->prepare(
    'SELECT u.user_id, u.name, u.email, u.role, u.is_active, COUNT(p.pet_id) AS pet_count
     FROM users u
     LEFT JOIN pets p ON p.user_id = u.user_id
     ' . $searchClause . '
     GROUP BY u.user_id, u.name, u.email, u.role, u.is_active
     ORDER BY u.name ASC'
);
$statement->execute($params);
$users = $statement->fetchAll();
?>
<?php $activePage = 'users'; $pageTitle = 'Manage Users'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <div class="flex flex-col gap-4 pb-6 md:flex-row md:items-center md:justify-between">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">User roster</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">Manage Users</h1>
        </div>
        <div class="flex items-center gap-3">
          <form method="get" class="flex items-center gap-2">
            <input class="rounded-xl border border-[#dfe7f2] bg-white px-3 py-2 text-sm" type="text" name="q" aria-label="Search users" value="<?php echo escapeHtml($search); ?>" placeholder="Search users" />
            <button class="rounded-xl bg-primary px-3 py-2 text-sm font-medium text-white" type="submit">Search</button>
          </form>
        </div>
      </div>

      <div class="overflow-hidden rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-sm">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-white text-on-surface-variant">
            <tr>
              <th class="px-4 py-3">Name</th>
              <th class="px-4 py-3">Email</th>
              <th class="px-4 py-3">Role</th>
              <th class="px-4 py-3">Pets</th>
              <th class="px-4 py-3">Status</th>
              <th class="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $user): ?>
              <tr class="border-t border-[#e5ebf7]">
                <td class="px-4 py-3 font-medium text-on-surface"><?php echo escapeHtml($user['name']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($user['email']); ?></td>
                <td class="px-4 py-3">
                  <?php if ($user['role'] === 'manager'): ?>
                    <form method="post" class="flex items-center gap-2">
                      <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                      <input type="hidden" name="action" value="update_role" />
                      <input type="hidden" name="user_id" value="<?php echo (int) $user['user_id']; ?>" />
                      <select name="role" aria-label="<?php echo escapeHtml('Role for ' . $user['name']); ?>" class="rounded-xl border border-[#dfe7f2] bg-white px-2 py-1 text-sm">
                        <option value="user">User</option>
                        <option value="manager" selected>Manager</option>
                      </select>
                      <button class="rounded-lg bg-primary px-2 py-1 text-xs font-medium text-white" type="submit">Save</button>
                    </form>
                  <?php else: ?>
                    <span class="inline-flex items-center gap-1 text-on-surface-variant" title="This role cannot be changed">
                      <span class="material-symbols-outlined text-base" aria-hidden="true">lock</span>
                      <?php echo $user['role'] === 'admin' ? 'Admin' : 'User'; ?>
                    </span>
                  <?php endif; ?>
                </td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo (int) $user['pet_count']; ?></td>
                <td class="px-4 py-3">
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                    <input type="hidden" name="action" value="toggle_status" />
                    <input type="hidden" name="user_id" value="<?php echo (int) $user['user_id']; ?>" />
                    <input type="hidden" name="is_active" value="<?php echo (int) $user['is_active'] === 1 ? 0 : 1; ?>" />
                    <?php if ((int) $user['user_id'] !== (int) $_SESSION['user_id']): ?>
                      <button type="submit" class="rounded-full px-2 py-1 text-xs font-medium <?php echo (int) $user['is_active'] === 1 ? 'bg-[#dff7ef] text-primary' : 'bg-[#fee2e2] text-red-700'; ?>"><?php echo (int) $user['is_active'] === 1 ? 'Active' : 'Inactive'; ?></button>
                    <?php else: ?>
                      <span class="rounded-full bg-[#dff7ef] px-2 py-1 text-xs font-medium text-primary">Active</span>
                    <?php endif; ?>
                  </form>
                </td>
                <td class="px-4 py-3">
                  <?php if ((int) $user['user_id'] !== (int) $_SESSION['user_id'] && $user['role'] !== 'admin'): ?>
                    <form method="post" onsubmit="return confirm('Delete this user?');">
                      <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
                      <input type="hidden" name="action" value="delete_user" />
                      <input type="hidden" name="user_id" value="<?php echo (int) $user['user_id']; ?>" />
                      <button type="submit" class="rounded-lg bg-red-600 px-2 py-1 text-xs font-medium text-white">Delete</button>
                    </form>
                  <?php else: ?>
                    <span class="text-xs text-on-surface-variant">Current admin</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
