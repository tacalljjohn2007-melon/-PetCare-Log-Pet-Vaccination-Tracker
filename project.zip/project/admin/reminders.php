<?php
require_once __DIR__ . '/../config/auth.php';
requireAdmin();

$search = trim((string) ($_GET['q'] ?? ''));
$term = '%' . $search . '%';
$reminderQuery = db()->prepare(
    'SELECT r.id, r.remind_date, r.message, r.status AS reminder_status,
            p.name AS pet_name, u.name AS owner_name, u.email, v.vaccine_name,
            CASE WHEN r.status = \'completed\' OR r.is_done = 1 THEN \'Completed\'
                 WHEN r.remind_date < CURDATE() THEN \'Overdue\' ELSE \'Upcoming\' END AS status
     FROM reminders r
     INNER JOIN pets p ON p.pet_id = r.pet_id
     INNER JOIN users u ON u.user_id = r.user_id
     LEFT JOIN vaccinations v ON v.vaccination_id = r.vaccine_id
     WHERE (:search = \'\' OR p.name LIKE :pet OR u.name LIKE :owner OR v.vaccine_name LIKE :vaccine OR r.message LIKE :message)
     ORDER BY r.remind_date ASC'
);
$reminderQuery->execute(['search' => $search, 'pet' => $term, 'owner' => $term, 'vaccine' => $term, 'message' => $term]);
$reminders = $reminderQuery->fetchAll();
?>
<?php $activePage = 'reminders'; $pageTitle = 'Reminders Overview'; include __DIR__ . '/../includes/admin-page-start.php'; ?>
      <div class="flex items-center justify-between pb-6">
        <div>
          <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">Alert center</p>
          <h1 class="mt-2 text-3xl font-bold text-on-surface">Reminders Overview</h1>
        </div>
        <form method="get" class="mb-4 flex gap-2"><input class="rounded-xl border bg-white px-3 py-2" name="q" type="search" aria-label="Search reminders" value="<?php echo escapeHtml($search); ?>" placeholder="Search reminders" /><button class="rounded-xl bg-primary px-3 py-2 font-medium text-white">Search</button></form>
      </div>

      <div class="overflow-hidden rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-sm">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-white text-on-surface-variant">
            <tr>
              <th class="px-4 py-3">Owner</th>
              <th class="px-4 py-3">Pet</th>
              <th class="px-4 py-3">Vaccine</th>
              <th class="px-4 py-3">Due date</th>
              <th class="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($reminders as $reminder): ?>
              <tr class="border-t border-[#e5ebf7]">
                <td class="px-4 py-3 font-medium text-on-surface"><?php echo escapeHtml($reminder['owner_name']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($reminder['pet_name']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($reminder['vaccine_name']); ?></td>
                <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($reminder['remind_date']); ?></td>
                <td class="px-4 py-3"><span class="rounded-full px-2 py-1 text-xs font-medium <?php echo $reminder['status'] === 'Overdue' ? 'bg-[#fee2e2] text-red-700' : 'bg-[#dff7ef] text-primary'; ?>"><?php echo escapeHtml($reminder['status']); ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
