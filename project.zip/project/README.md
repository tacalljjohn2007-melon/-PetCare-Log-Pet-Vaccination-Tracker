# PetCare Log

## Local setup

1. Start WAMP MySQL.
2. In phpMyAdmin (`http://localhost/phpmyadmin`), import `setup.sql`. It creates/uses `petcare_log`, preserves existing user/pet/vaccination records, and applies missing schema columns safely. Optionally import `setup-sample-data.sql` for local demo accounts and example pet records.
3. In VS Code, run the **Run PetCare Log (PHP)** task.
4. Open [http://127.0.0.1:8091/](http://127.0.0.1:8091/) or [the login page](http://127.0.0.1:8091/html/login.php).

The VS Code task serves this workspace on port `8091`. If you use Apache instead, this workspace folder is named `project`, so its URL is `http://localhost/project/` when Apache's web root is `C:\wamp\www`. The old `/PetCareLog/` URL only works if the project is copied to a folder named `PetCareLog`.

The application uses the `petcare_log` schema with `users.user_id` / `users.password`, `pets.pet_id`, and `vaccinations.vaccination_id`. The compatibility `must_change_password` feature was removed because that column does not exist in the live schema. Account activation remains enabled through `users.is_active`; setup adds that column if an older install is missing it. Import the updated `setup.sql` once to safely add missing columns and create the password-reset table; the update is safe to re-run and does not drop existing data.

For local PHP troubleshooting, set `PETCARE_DEBUG=1` before starting Apache/PHP. This enables detailed PHP errors; unset it or set it to `0` outside local debugging. Production keeps error details in the server log and returns a generic error page. Login failures use the same generic response for unknown accounts and incorrect passwords.

## Project layout

```text
admin/       Admin dashboard, user/pet/vaccine/reminder views, settings
config/      Shared PDO connection and session/auth/CSRF helpers
css/         Shared theme variables and styles
html/        Login, sign-up, and user-facing PHP views
includes/    Shared header, sidebar, footer, and data-backed UI partials
js/          Theme toggle and page interactions
php/         User routes, CRUD handlers, and authentication handlers
setup.sql    MySQL schema and safe schema migrations
setup-sample-data.sql  Optional local sample accounts and records
```

## Publishing

- Configure `PETCARE_DB_HOST`, `PETCARE_DB_PORT`, `PETCARE_DB_NAME`, `PETCARE_DB_USER`, and `PETCARE_DB_PASSWORD` for the production database. Do not use the local root account in production.
- Set `PETCARE_BASE_URL` to the public HTTPS origin and application base path (for example, `https://example.com/petcare`). It is required outside debug mode so password-reset emails never contain localhost URLs.
- Set `PETCARE_MAIL_FROM` and optionally `PETCARE_MAIL_FROM_NAME`. PHP's `mail()` uses the mail transport configured for the host; on Windows/WAMP configure `SMTP`, `smtp_port`, and `sendmail_from` in the active `php.ini`, or configure the server's sendmail-compatible relay. Verify outbound delivery before enabling password resets.
- Set `PETCARE_REMINDER_DAYS` if the reminder window needs to differ from its default. Configure the host scheduler to run `cron/send-reminders.php` at the desired interval using the same environment variables and PHP installation as the web app.
- Enable PDO MySQL and Fileinfo. Set both `upload_max_filesize` and `post_max_size` in the active `php.ini` above 5 MB (for example, 8M) so the application can accept its 5 MB profile and pet photo limit; restart PHP/Apache after changing the settings.
- Keep `PETCARE_DEBUG` unset or set to `0`, enable HTTPS, and ensure Apache honors the root and upload `.htaccess` rules. The web server must deny direct access to application internals and executable files under uploads.
