(function () {
  const storageKey = "petcare-theme";

  const updateThemeToggle = (theme) => {
    const button = document.getElementById("petcareThemeToggle");
    const icon = document.getElementById("petcareThemeIcon");
    if (!button || !icon) return;
    const nextTheme = theme === "dark" ? "light" : "dark";
    icon.textContent = theme === "dark" ? "light_mode" : "dark_mode";
    button.setAttribute("aria-label", `Switch to ${nextTheme} mode`);
    button.title = `Switch to ${nextTheme} mode`;
  };

  window.applyPetCareTheme = function (mode) {
    const theme = mode === "dark" ? "dark" : "light";
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem(storageKey, theme);
    } catch {}
    updateThemeToggle(theme);
    if (window.PETCARE_IS_AUTHENTICATED && window.PETCARE_PREFERENCES_URL && window.PETCARE_CSRF_TOKEN) {
      fetch(window.PETCARE_PREFERENCES_URL, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
        body: new URLSearchParams({ theme, csrf_token: window.PETCARE_CSRF_TOKEN }),
      }).catch(() => {});
    }
    window.dispatchEvent(new CustomEvent("petcare-theme-change", { detail: theme }));
  };

  let savedTheme = null;
  try {
    savedTheme = localStorage.getItem(storageKey);
  } catch {
    savedTheme = null;
  }
  const serverTheme = document.documentElement.dataset.theme;
  const initialTheme = ["dark", "light"].includes(savedTheme)
    ? savedTheme
    : ["dark", "light"].includes(serverTheme)
      ? serverTheme
      : "light";
  document.documentElement.dataset.theme = initialTheme;
  updateThemeToggle(initialTheme);
  document.getElementById("petcareThemeToggle")?.addEventListener("click", () => {
    window.applyPetCareTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
  });
  const menuToggle = document.getElementById("petcareMenuToggle");
  const sidebar = document.getElementById("sidebar");
  const menuIcon = menuToggle?.querySelector(".material-symbols-outlined");
  menuToggle?.addEventListener("click", () => {
    sidebar?.classList.add("mobile-transition");
    const isOpen = sidebar?.classList.toggle("open") ?? false;
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
    if (menuIcon) menuIcon.textContent = isOpen ? "close" : "menu";
  });
  sidebar?.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      sidebar.classList.remove("open");
      menuToggle?.setAttribute("aria-expanded", "false");
      menuToggle?.setAttribute("aria-label", "Open navigation menu");
      if (menuIcon) menuIcon.textContent = "menu";
    });
  });

  window.dispatchEvent(
    new CustomEvent("petcare-theme-change", { detail: document.documentElement.dataset.theme }),
  );

  const languageKey = "petcare-language";
  const supportedLanguages = ["en-US", "en-GB", "es-ES", "fr-CA", "de-DE", "tl-PH"];
  const localeNames = {
    "en-GB": "English (UK)",
    "es-ES": "Espa\u00f1ol",
    "fr-CA": "Fran\u00e7ais (Canada)",
    "de-DE": "Deutsch",
    "tl-PH": "Tagalog",
  };
  const legacyLocaleNames = {
    "en-GB": "English (UK)",
    "es-ES": "Espa\u00c3\u00b1ol",
    "fr-CA": "Fran\u00c3\u00a7ais (Canada)",
    "de-DE": "Deutsch",
    "tl-PH": "Tagalog",
  };
  const originalText = new WeakMap();
  const translations = {
    "English (US)": { "English (UK)": "English (UK)", "Español": "Español", "Français (Canada)": "Français (Canada)", "Deutsch": "Deutsch", "Tagalog": "Tagalog" },
    "Dashboard": { "English (UK)": "Dashboard", "Español": "Panel", "Français (Canada)": "Tableau de bord", "Deutsch": "Dashboard", "Tagalog": "Dashboard" },
    "My Pets": { "English (UK)": "My Pets", "Español": "Mis mascotas", "Français (Canada)": "Mes animaux", "Deutsch": "Meine Haustiere", "Tagalog": "Aking mga Alaga" },
    "Vaccines": { "English (UK)": "Vaccines", "Español": "Vacunas", "Français (Canada)": "Vaccins", "Deutsch": "Impfungen", "Tagalog": "Mga Bakuna" },
    "Reminders": { "English (UK)": "Reminders", "Español": "Recordatorios", "Français (Canada)": "Rappels", "Deutsch": "Erinnerungen", "Tagalog": "Mga Paalala" },
    "Settings": { "English (UK)": "Settings", "Español": "Configuración", "Français (Canada)": "Paramètres", "Deutsch": "Einstellungen", "Tagalog": "Mga Setting" },
    "Log Out": { "English (UK)": "Log Out", "Español": "Cerrar sesión", "Français (Canada)": "Se déconnecter", "Deutsch": "Abmelden", "Tagalog": "Mag Log Out" },
    "Sign Out / Logout": { "English (UK)": "Sign Out / Logout", "Español": "Cerrar sesión", "Français (Canada)": "Déconnexion", "Deutsch": "Abmelden", "Tagalog": "Lumabas / Mag Log Out" },
    "Application Language": { "English (UK)": "Application Language", "Español": "Idioma de la aplicación", "Français (Canada)": "Langue de l'application", "Deutsch": "Anwendungssprache", "Tagalog": "Wika ng Application" },
    "Interface Theme": { "English (UK)": "Interface Theme", "Español": "Tema de la interfaz", "Français (Canada)": "Thème de l'interface", "Deutsch": "Oberflächenthema", "Tagalog": "Tema ng Interface" },
    "Light": { "English (UK)": "Light", "Español": "Claro", "Français (Canada)": "Clair", "Deutsch": "Hell", "Tagalog": "Maliwanag" },
    "Dark": { "English (UK)": "Dark", "Español": "Oscuro", "Français (Canada)": "Sombre", "Deutsch": "Dunkel", "Tagalog": "Madilim" },
    "Pet Weight Metric Unit": { "English (UK)": "Pet Weight Metric Unit", "Español": "Unidad de peso de la mascota", "Français (Canada)": "Unité de poids de l'animal", "Deutsch": "Gewichtseinheit des Haustiers", "Tagalog": "Yunit ng Timbang ng Alaga" },
    "Pounds (lbs)": { "English (UK)": "Pounds (lbs)", "Español": "Libras (lbs)", "Français (Canada)": "Livres (lb)", "Deutsch": "Pfund (lbs)", "Tagalog": "Pounds (lbs)" },
    "Kilograms (kg)": { "English (UK)": "Kilograms (kg)", "Español": "Kilogramos (kg)", "Français (Canada)": "Kilogrammes (kg)", "Deutsch": "Kilogramm (kg)", "Tagalog": "Kilograms (kg)" },
    "Are you sure you want to log out?": { "English (UK)": "Are you sure you want to log out?", "Español": "¿Seguro que quieres cerrar sesión?", "Français (Canada)": "Voulez-vous vraiment vous déconnecter?", "Deutsch": "Möchten Sie sich wirklich abmelden?", "Tagalog": "Sigurado ka bang gusto mong mag-log out?" },
    "Cancel": { "English (UK)": "Cancel", "Español": "Cancelar", "Français (Canada)": "Annuler", "Deutsch": "Abbrechen", "Tagalog": "Kanselahin" },
    "Sign up for free": { "English (UK)": "Sign up for free", "Español": "Regístrate gratis", "Français (Canada)": "Inscrivez-vous gratuitement", "Deutsch": "Kostenlos registrieren", "Tagalog": "Mag-sign up nang libre" },
    "Email Address": { "English (UK)": "Email Address", "Español": "Correo electrónico", "Français (Canada)": "Adresse courriel", "Deutsch": "E-Mail-Adresse", "Tagalog": "Email Address" },
    "Password": { "English (UK)": "Password", "Español": "Contraseña", "Français (Canada)": "Mot de passe", "Deutsch": "Passwort", "Tagalog": "Password" },
    "Log In to PetCare Log": { "English (UK)": "Log in to PetCare Log", "Español": "Iniciar sesión en PetCare Log", "Français (Canada)": "Se connecter à PetCare Log", "Deutsch": "Bei PetCare Log anmelden", "Tagalog": "Mag-log in sa PetCare Log" },
    "Vaccine & Wellness Records": { "English (UK)": "Vaccine & Wellness Records", "Español": "Registros de vacunas y bienestar", "Français (Canada)": "Dossiers de vaccins et de bien-être", "Deutsch": "Impf- und Gesundheitsaufzeichnungen", "Tagalog": "Mga Tala ng Bakuna at Kalusugan" },
    "New to tracking pet immunizations?": { "English (UK)": "New to tracking pet immunisations?", "Español": "¿Es nuevo en el seguimiento de vacunas?", "Français (Canada)": "Vous commencez à suivre les vaccins?", "Deutsch": "Neu bei der Impfverwaltung?", "Tagalog": "Bago sa pagsubaybay ng mga bakuna ng alaga?" },
    "Account": { "English (UK)": "Account", "Español": "Cuenta", "Français (Canada)": "Compte", "Deutsch": "Konto", "Tagalog": "Account" },
    "Language": { "English (UK)": "Language", "Español": "Idioma", "Français (Canada)": "Langue", "Deutsch": "Sprache", "Tagalog": "Wika" },
    "Choose the language used across your account": { "English (UK)": "Choose the language used across your account", "Español": "Elige el idioma que se usará en tu cuenta", "Français (Canada)": "Choisissez la langue utilisée dans votre compte", "Deutsch": "Wählen Sie die Sprache für Ihr Konto", "Tagalog": "Piliin ang wikang gagamitin sa iyong account" },
    "Language saved": { "English (UK)": "Language saved", "Español": "Idioma guardado", "Français (Canada)": "Langue enregistrée", "Deutsch": "Sprache gespeichert", "Tagalog": "Nai-save ang wika" },
    "Couldn't save language. Try again.": { "English (UK)": "Couldn't save language. Try again.", "Español": "No se pudo guardar el idioma. Inténtalo de nuevo.", "Français (Canada)": "Impossible d'enregistrer la langue. Réessayez.", "Deutsch": "Die Sprache konnte nicht gespeichert werden. Versuchen Sie es erneut.", "Tagalog": "Hindi na-save ang wika. Subukan muli." },
    "Profile": { "English (UK)": "Profile", "Español": "Perfil", "Français (Canada)": "Profil", "Deutsch": "Profil", "Tagalog": "Profile" },
    "Name": { "English (UK)": "Name", "Español": "Nombre", "Français (Canada)": "Nom", "Deutsch": "Name", "Tagalog": "Pangalan" },
    "Email": { "English (UK)": "Email", "Español": "Correo electrónico", "Français (Canada)": "Courriel", "Deutsch": "E-Mail", "Tagalog": "Email" },
    "Phone": { "English (UK)": "Phone", "Español": "Teléfono", "Français (Canada)": "Téléphone", "Deutsch": "Telefon", "Tagalog": "Telepono" },
    "Preferred clinic": { "English (UK)": "Preferred clinic", "Español": "Clínica preferida", "Français (Canada)": "Clinique préférée", "Deutsch": "Bevorzugte Klinik", "Tagalog": "Pinipiling klinika" },
    "Save profile": { "English (UK)": "Save profile", "Español": "Guardar perfil", "Français (Canada)": "Enregistrer le profil", "Deutsch": "Profil speichern", "Tagalog": "I-save ang profile" },
    "Notifications": { "English (UK)": "Notifications", "Español": "Notificaciones", "Français (Canada)": "Notifications", "Deutsch": "Benachrichtigungen", "Tagalog": "Mga Notification" },
    "Enable reminders": { "English (UK)": "Enable reminders", "Español": "Activar recordatorios", "Français (Canada)": "Activer les rappels", "Deutsch": "Erinnerungen aktivieren", "Tagalog": "I-enable ang mga paalala" },
    "Administrative Settings": { "English (UK)": "Administrative Settings", "Español": "Configuración administrativa", "Français (Canada)": "Paramètres administratifs", "Deutsch": "Administrative Einstellungen", "Tagalog": "Mga Setting ng Administrator" },
    "Admin Dashboard": { "English (UK)": "Admin Dashboard", "Español": "Panel de administración", "Français (Canada)": "Tableau de bord administrateur", "Deutsch": "Admin-Dashboard", "Tagalog": "Dashboard ng Admin" },
    "Manage Users": { "English (UK)": "Manage Users", "Español": "Gestionar usuarios", "Français (Canada)": "Gérer les utilisateurs", "Deutsch": "Benutzer verwalten", "Tagalog": "Pamahalaan ang mga User" },
    "All Pets": { "English (UK)": "All Pets", "Español": "Todas las mascotas", "Français (Canada)": "Tous les animaux", "Deutsch": "Alle Haustiere", "Tagalog": "Lahat ng Alaga" },
    "All Vaccines": { "English (UK)": "All Vaccines", "Español": "Todas las vacunas", "Français (Canada)": "Tous les vaccins", "Deutsch": "Alle Impfungen", "Tagalog": "Lahat ng Bakuna" },
    "Vaccine Types": { "English (UK)": "Vaccine Types", "Español": "Tipos de vacunas", "Français (Canada)": "Types de vaccins", "Deutsch": "Impfstofftypen", "Tagalog": "Mga Uri ng Bakuna" },
    "Reminders Overview": { "English (UK)": "Reminders Overview", "Español": "Resumen de recordatorios", "Français (Canada)": "Aperçu des rappels", "Deutsch": "Erinnerungsübersicht", "Tagalog": "Pangkalahatang-ideya ng mga Paalala" },
    "Administrator": { "English (UK)": "Administrator", "Español": "Administrador", "Français (Canada)": "Administrateur", "Deutsch": "Administrator", "Tagalog": "Administrator" },
    "Pet Owner": { "English (UK)": "Pet Owner", "Español": "Dueño de mascota", "Français (Canada)": "Propriétaire d'animal", "Deutsch": "Tierhalter", "Tagalog": "May-ari ng Alaga" },
    "Admin Console": { "English (UK)": "Admin Console", "Español": "Consola de administración", "Français (Canada)": "Console d'administration", "Deutsch": "Admin-Konsole", "Tagalog": "Admin Console" },
    "Pet Vaccination Tracker": { "English (UK)": "Pet Vaccination Tracker", "Español": "Registro de vacunas de mascotas", "Français (Canada)": "Suivi des vaccins des animaux", "Deutsch": "Impftracker für Haustiere", "Tagalog": "Tagasubaybay ng Bakuna ng Alaga" },
    "Logout": { "English (UK)": "Logout", "Español": "Cerrar sesión", "Français (Canada)": "Déconnexion", "Deutsch": "Abmelden", "Tagalog": "Mag-log out" },
  };

  const translateText = (language) => {
    const locale = language === "en-US" ? "en-US" : language;
    const localeName = localeNames[locale];
    const legacyLocaleName = legacyLocaleNames[locale];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (!originalText.has(node)) originalText.set(node, node.nodeValue);
      const source = originalText.get(node).trim();
      if (!source) continue;
      const entry = translations[source];
      if (!entry) continue;
      const replacement = locale === "en-US" ? source : (entry[localeName] || entry[legacyLocaleName] || source);
      node.nodeValue = node.nodeValue.replace(source, replacement);
    }
    document.querySelectorAll("[placeholder], [title], [aria-label]").forEach((element) => {
      ["placeholder", "title", "aria-label"].forEach((attribute) => {
        const source = element.getAttribute(attribute);
        const entry = source && translations[source];
        if (entry) element.setAttribute(attribute, locale === "en-US" ? source : (entry[localeName] || entry[legacyLocaleName] || source));
      });
    });
  };

  const languageSelect = document.getElementById("languageSelect");
  const languageSavedMessage = document.getElementById("languageSavedMessage");
  let storedLanguage = null;
  try {
    storedLanguage = localStorage.getItem(languageKey);
  } catch {}
  const serverLanguage = supportedLanguages.includes(window.PETCARE_LANGUAGE) ? window.PETCARE_LANGUAGE : "en-US";
  const savedLanguage = window.PETCARE_IS_AUTHENTICATED
    ? serverLanguage
    : (supportedLanguages.includes(storedLanguage) ? storedLanguage : "en-US");
  if (languageSelect) languageSelect.value = savedLanguage;
  window.applyPetCareLanguage = (language) => {
    const selected = supportedLanguages.includes(language) ? language : "en-US";
    try {
      localStorage.setItem(languageKey, selected);
    } catch {}
    translateText(selected);
    document.documentElement.lang = selected;
    if (languageSelect) languageSelect.value = selected;
  };
  let persistedLanguage = savedLanguage;
  let languageRequestController = null;
  let languageRequestId = 0;
  let languageMessageTimer = null;
  const setLanguageMessage = (message, isError, language) => {
    if (!languageSavedMessage) return;
    languageSavedMessage.classList.toggle("text-red-700", isError);
    languageSavedMessage.classList.toggle("text-primary", !isError);
    languageSavedMessage.textContent = message;
    languageSavedMessage.hidden = false;
    translateText(language);
    if (languageMessageTimer) window.clearTimeout(languageMessageTimer);
    languageMessageTimer = window.setTimeout(() => { languageSavedMessage.hidden = true; }, 2000);
  };
  const saveLanguagePreference = (language) => {
    if (language === persistedLanguage) return;
    if (!window.PETCARE_IS_AUTHENTICATED || !window.PETCARE_PREFERENCES_URL || !window.PETCARE_CSRF_TOKEN) {
      persistedLanguage = language;
      return;
    }
    languageRequestController?.abort();
    const controller = new AbortController();
    languageRequestController = controller;
    const requestId = ++languageRequestId;
    const previousLanguage = persistedLanguage;
    languageSelect.disabled = true;
    fetch(window.PETCARE_PREFERENCES_URL, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
      body: new URLSearchParams({ language, csrf_token: window.PETCARE_CSRF_TOKEN }),
      signal: controller.signal,
    }).then((response) => {
      if (!response.ok) throw new Error("Language preference was not saved");
      if (requestId !== languageRequestId) return;
      persistedLanguage = language;
      setLanguageMessage("Language saved", false, language);
    }).catch((error) => {
      if (requestId !== languageRequestId || error.name === "AbortError") return;
      window.applyPetCareLanguage(previousLanguage);
      setLanguageMessage("Couldn't save language. Try again.", true, previousLanguage);
    }).finally(() => {
      if (requestId !== languageRequestId) return;
      languageRequestController = null;
      languageSelect.disabled = false;
    });
  };
  if (languageSelect) languageSelect.addEventListener("change", () => {
    const selectedLanguage = languageSelect.value;
    if (selectedLanguage === persistedLanguage) {
      if (languageRequestController) {
        languageRequestController.abort();
        languageRequestController = null;
        languageRequestId++;
        languageSelect.disabled = false;
      }
      return;
    }
    window.applyPetCareLanguage(selectedLanguage);
    saveLanguagePreference(selectedLanguage);
  });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => window.applyPetCareLanguage(savedLanguage), { once: true });
  else window.applyPetCareLanguage(savedLanguage);

  const logoutStyle = document.createElement("style");
  logoutStyle.textContent = `
    .petcare-logout-backdrop {
      position: fixed;
      inset: 0;
      z-index: 1000;
      display: grid;
      place-items: center;
      padding: 1rem;
      background: rgba(19, 27, 46, 0.28);
    }
    .petcare-logout-dialog {
      width: min(100%, 22rem);
      padding: 1.25rem;
      border: 1px solid #bbcabf;
      border-radius: 0.75rem;
      background: #ffffff;
      color: #131b2e;
      box-shadow: 0 12px 32px rgba(19, 27, 46, 0.2);
      font-family: Inter, sans-serif;
    }
    .petcare-logout-dialog p {
      margin: 0 0 1rem;
      font-size: 0.875rem;
      line-height: 1.25rem;
    }
    .petcare-logout-actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.5rem;
    }
    .petcare-logout-actions button {
      border: 0;
      border-radius: 0.5rem;
      padding: 0.5rem 0.75rem;
      font: inherit;
      font-size: 0.8125rem;
      cursor: pointer;
    }
    .petcare-logout-cancel {
      background: #eaedff;
      color: #131b2e;
    }
    .petcare-logout-confirm {
      background: #ba1a1a;
      color: #ffffff;
    }
    [data-theme="dark"] .petcare-logout-dialog {
      border-color: #4b5563;
      background: #1f2937;
      color: #f3f4f6;
    }
    [data-theme="dark"] .petcare-logout-cancel {
      background: #374151;
      color: #f3f4f6;
    }
  `;
  (document.head || document.documentElement).appendChild(logoutStyle);

  const showLogoutConfirmation = (form) => {
    const backdrop = document.createElement("div");
    backdrop.className = "petcare-logout-backdrop";
    backdrop.innerHTML = `
      <div class="petcare-logout-dialog" role="dialog" aria-modal="true" aria-labelledby="petcare-logout-message">
        <p id="petcare-logout-message">Are you sure you want to log out?</p>
        <div class="petcare-logout-actions">
          <button type="button" class="petcare-logout-cancel">Cancel</button>
          <button type="button" class="petcare-logout-confirm">Log Out</button>
        </div>
      </div>
    `;

    const close = () => backdrop.remove();
    backdrop.querySelector(".petcare-logout-cancel").addEventListener("click", close);
    backdrop.querySelector(".petcare-logout-confirm").addEventListener("click", () => {
      form.submit();
    });
    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) close();
    });
    document.body.appendChild(backdrop);
    backdrop.querySelector(".petcare-logout-cancel").focus();
  };

  const bindLogoutForms = () => {
    document.querySelectorAll("form[data-logout-form]").forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        showLogoutConfirmation(form);
      });
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindLogoutForms, { once: true });
  } else {
    bindLogoutForms();
  }

})();
