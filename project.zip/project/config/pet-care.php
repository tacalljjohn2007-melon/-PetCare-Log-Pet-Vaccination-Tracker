<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

/**
 * Age as a short label, e.g. "2 yrs 3 mo", "4 mo", "12 d". Returns "Unknown" without a valid birth date.
 */
function petAgeLabel(?string $birthDate): string
{
    if ($birthDate === null || $birthDate === '') {
        return 'Unknown';
    }

    try {
        $born = new DateTimeImmutable($birthDate);
    } catch (Exception $exception) {
        return 'Unknown';
    }

    $today = new DateTimeImmutable('today');
    if ($born > $today) {
        return 'Unknown';
    }

    $diff = $born->diff($today);
    if ($diff->y >= 1) {
        $label = $diff->y . ($diff->y === 1 ? ' yr' : ' yrs');
        return $diff->m > 0 ? $label . ' ' . $diff->m . ' mo' : $label;
    }
    if ($diff->m >= 1) {
        return $diff->m . ' mo';
    }

    return $diff->d . ' d';
}

/**
 * Vaccines that apply to a species, with whether this pet has a completed dose of each.
 * A pet's cycle is complete when every required vaccine for its species is done.
 */
function vaccineCycleStatus(int $petId, string $species): array
{
    $typesQuery = db()->prepare(
        'SELECT name, schedule_days, description, is_required FROM vaccine_types
         WHERE LOWER(TRIM(species)) = LOWER(TRIM(:species))
         ORDER BY is_required DESC, name ASC'
    );
    $typesQuery->execute(['species' => $species]);
    $types = $typesQuery->fetchAll();

    $doneQuery = db()->prepare(
        "SELECT vaccine_type, vaccine_name FROM vaccinations
         WHERE pet_id = :pet_id
           AND LOWER(TRIM(CAST(status AS CHAR))) IN ('done', '1', 'true')"
    );
    $doneQuery->execute(['pet_id' => $petId]);
    $doneNames = [];
    foreach ($doneQuery->fetchAll() as $vaccination) {
        foreach (['vaccine_type', 'vaccine_name'] as $nameColumn) {
            $name = strtolower(trim((string) ($vaccination[$nameColumn] ?? '')));
            if ($name !== '') {
                $doneNames[$name] = true;
            }
        }
    }

    $recommended = [];
    $requiredTotal = 0;
    $requiredDone = 0;
    foreach ($types as $type) {
        $isRequired = (int) $type['is_required'] === 1;
        $typeName = strtolower(trim((string) $type['name']));
        $done = isset($doneNames[$typeName]);
        if ($isRequired) {
            $requiredTotal++;
            if ($done) {
                $requiredDone++;
            }
        }
        $recommended[] = [
            'name' => (string) $type['name'],
            'description' => (string) ($type['description'] ?? ''),
            'schedule_days' => (int) $type['schedule_days'],
            'is_required' => $isRequired,
            'done' => $done,
        ];
    }

    return [
        'recommended' => $recommended,
        'required_total' => $requiredTotal,
        'required_done' => $requiredDone,
        'complete' => $requiredTotal > 0 && $requiredDone === $requiredTotal,
    ];
}

function activeCertificateForPet(int $petId): ?array
{
    $query = db()->prepare(
        'SELECT * FROM pet_certificates
         WHERE pet_id = :pet_id AND revoked_at IS NULL
         ORDER BY issued_at DESC, certificate_id DESC LIMIT 1'
    );
    $query->execute(['pet_id' => $petId]);
    return $query->fetch() ?: null;
}

function newCertificateCode(): string
{
    return strtoupper(bin2hex(random_bytes(6)));
}
