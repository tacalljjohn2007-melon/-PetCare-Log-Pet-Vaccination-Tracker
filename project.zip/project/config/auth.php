<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';

date_default_timezone_set((string) (getenv('PETCARE_TIMEZONE') ?: 'Asia/Manila'));

function configurePetCareRuntime(): void
{
    static $configured = false;
    if ($configured || PHP_SAPI === 'cli') {
        return;
    }
    $configured = true;

    $debugEnabled = getenv('PETCARE_DEBUG') === '1';
    error_reporting(E_ALL);
    ini_set('display_errors', $debugEnabled ? '1' : '0');
    ini_set('log_errors', '1');

    if ($debugEnabled) {
        return;
    }

    set_exception_handler(static function (Throwable $exception): void {
        error_log('PetCare Log unhandled exception: ' . $exception);
        if (!headers_sent()) {
            http_response_code(500);
        }
        require __DIR__ . '/../html/500.php';
    });
    register_shutdown_function(static function (): void {
        $error = error_get_last();
        if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
            error_log('PetCare Log fatal error: ' . $error['message'] . ' in ' . $error['file'] . ':' . $error['line']);
            if (!headers_sent()) {
                http_response_code(500);
            }
            require __DIR__ . '/../html/500.php';
        }
    });
}

function startPetCareSession(): void
{
    static $authenticationChecked = false;
    if (session_status() !== PHP_SESSION_ACTIVE) {
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        $https = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off';
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => appBasePath() ?: '/',
            'secure' => $https,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    if ($authenticationChecked) {
        return;
    }
    $authenticationChecked = true;

    if (!empty($_SESSION['user_logged_in'])) {
        $userId = (int) ($_SESSION['user_id'] ?? 0);
        $idColumn = userIdentifierColumn();
        $activeColumn = userActiveColumn();
        $query = db()->prepare(
            "SELECT {$idColumn} AS user_id, name, role, {$activeColumn}
             FROM users WHERE {$idColumn} = :user_id LIMIT 1"
        );
        $query->execute(['user_id' => $userId]);
        $user = $query->fetch();
        if (!$user || (int) $user['is_active'] !== 1) {
            unset($_SESSION['user_logged_in'], $_SESSION['user_id'], $_SESSION['username'], $_SESSION['role']);
            session_regenerate_id(true);
            return;
        }

        $_SESSION['user_id'] = (int) $user['user_id'];
        $_SESSION['username'] = (string) $user['name'];
        $_SESSION['role'] = (string) $user['role'];
    }
}

function appBasePath(): string
{
    $scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    foreach (['/admin/', '/php/', '/html/', '/cron/'] as $routeDirectory) {
        $position = strpos($scriptName, $routeDirectory);
        if ($position !== false) {
            return rtrim(substr($scriptName, 0, $position), '/');
        }
    }

    $directory = str_replace('\\', '/', dirname($scriptName));
    return $directory === '.' || $directory === '/' ? '' : rtrim($directory, '/');
}

function appUrl(string $path): string
{
    $path = '/' . ltrim($path, '/');
    return appBasePath() . $path;
}

function profilePhotoUrl(?string $photo): string
{
    if ($photo !== null && preg_match('/^uploads\/profiles\/[a-f0-9]{32}\.(?:jpg|png|webp)$/', $photo)) {
        return appUrl('/' . $photo);
    }

    return "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128'%3E%3Crect width='128' height='128' rx='64' fill='%23dff7ef'/%3E%3Ccircle cx='64' cy='48' r='24' fill='%23006c49'/%3E%3Cpath d='M20 116c4-27 20-42 44-42s40 15 44 42' fill='%23006c49'/%3E%3C/svg%3E";
}

function petPhotoUrl(?string $photo): string
{
    if ($photo !== null && preg_match('/^uploads\/pets\/[a-f0-9]{32}\.(?:jpg|png|webp)$/', $photo)) {
        return appUrl('/' . $photo);
    }

    return '';
}

function escapeHtml(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrfToken(): string
{
    startPetCareSession();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION['csrf_token'];
}

function verifyCsrfToken(): void
{
    $submittedToken = (string) ($_POST['csrf_token'] ?? '');
    if ($submittedToken === '' || !hash_equals(csrfToken(), $submittedToken)) {
        http_response_code(403);
        exit('The form expired or its security token was invalid. Go back and try again.');
    }
}

function preventAuthPageCaching(): void
{
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

function currentUserId(): int
{
    startPetCareSession();
    return !empty($_SESSION['user_logged_in']) ? (int) ($_SESSION['user_id'] ?? 0) : 0;
}

function currentUserRole(): string
{
    startPetCareSession();
    return currentUserId() > 0 ? (string) ($_SESSION['role'] ?? 'user') : '';
}

function requireLogin(): int
{
    startPetCareSession();
    $userId = currentUserId();
    if ($userId < 1) {
        header('Location: ' . appUrl('/html/login.php'));
        exit;
    }

    return $userId;
}

function requireUserAccess(): int
{
    $userId = requireLogin();
    if (currentUserRole() === 'admin') {
        header('Location: ' . appUrl('/admin/dashboard.php'));
        exit;
    }

    return $userId;
}

function requireAdmin(): int
{
    $userId = requireLogin();
    if (currentUserRole() !== 'admin') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            http_response_code(403);
            exit('Admin access is required.');
        }
        header('Location: ' . appUrl('/php/dashboard.php'));
        exit;
    }

    return $userId;
}

/**
 * Return an error message when an admin role change is not permitted.
 */
function adminRoleChangeError(string $currentRole, string $requestedRole, bool $isSelfChange = false): ?string
{
    if ($isSelfChange) {
        return "The current admin's role cannot be changed";
    }

    if (!in_array($requestedRole, ['user', 'manager'], true)) {
        return 'Admins can only assign the User or Manager role';
    }

    if ($currentRole !== 'manager') {
        return 'This user\'s role cannot be changed';
    }

    return null;
}

function redirectToAdminDashboard(): never
{
    header('Location: ' . appUrl('/admin/dashboard.php'));
    exit;
}

function redirectToUserDashboard(): never
{
    header('Location: ' . appUrl('/php/dashboard.php'));
    exit;
}

function redirectAfterPost(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function isValidPasswordLength(string $password): bool
{
    return strlen($password) >= 8 && strlen($password) <= 72;
}

function isLoginLockedOut(string $email, ?string $ipAddress): bool
{
    $query = db()->prepare(
        'SELECT COUNT(*) FROM login_attempts attempt
         WHERE attempt.email = :email AND attempt.ip_address <=> :ip_address
           AND attempt.successful = 0
           AND attempt.attempted_at >= NOW() - INTERVAL 15 MINUTE
           AND attempt.attempted_at > COALESCE(
             (SELECT MAX(successful_attempt.attempted_at) FROM login_attempts successful_attempt
              WHERE successful_attempt.email = :email_after_success
                AND successful_attempt.ip_address <=> :ip_after_success
                AND successful_attempt.successful = 1),
             FROM_UNIXTIME(0)
           )'
    );
    $query->execute([
        'email' => $email,
        'ip_address' => $ipAddress,
        'email_after_success' => $email,
        'ip_after_success' => $ipAddress,
    ]);

    return (int) $query->fetchColumn() >= 5;
}

function isDateOnOrBeforeToday(string $date): bool
{
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    return $parsed !== false
        && $parsed->format('Y-m-d') === $date
        && $date <= date('Y-m-d');
}

function isValidVaccineDateRange(string $dateGiven, string $nextDueDate): bool
{
    $given = DateTimeImmutable::createFromFormat('!Y-m-d', $dateGiven);
    $due = DateTimeImmutable::createFromFormat('!Y-m-d', $nextDueDate);

    return $given !== false
        && $due !== false
        && $given->format('Y-m-d') === $dateGiven
        && $due->format('Y-m-d') === $nextDueDate
        && $dateGiven <= date('Y-m-d')
        && $nextDueDate >= $dateGiven;
}

function vaccineStatusCaseSql(string $alias, ?string $tableName = null): string
{
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $alias)) {
        throw new InvalidArgumentException('Invalid SQL table alias.');
    }

    if ($tableName !== null && !in_array($tableName, ['vaccinations', 'vaccines'], true)) {
        throw new InvalidArgumentException('Invalid vaccination table.');
    }

    return "CASE WHEN LOWER(TRIM(CAST({$alias}.status AS CHAR))) IN ('done', '1', 'true') THEN 'done'
        WHEN {$alias}.next_due_date < CURDATE() THEN 'overdue'
        WHEN {$alias}.next_due_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'due_soon'
        ELSE 'upcoming' END";
}

function findOwnedPet(int $userId, string $identifier): ?array
{
    $identifier = trim($identifier);
    if ($identifier === '') {
        return null;
    }

    if (ctype_digit($identifier)) {
        $query = db()->prepare(
            'SELECT pets.*, pet_id AS id, birth_date AS birthdate FROM pets
             WHERE user_id = :user_id AND pet_id = :pet_id LIMIT 1'
        );
        $query->execute(['user_id' => $userId, 'pet_id' => (int) $identifier]);
    } else {
        $query = db()->prepare(
            'SELECT pets.*, pet_id AS id, birth_date AS birthdate FROM pets
             WHERE user_id = :user_id AND LOWER(name) = LOWER(:name) LIMIT 1'
        );
        $query->execute(['user_id' => $userId, 'name' => $identifier]);
    }

    return $query->fetch() ?: null;
}

function ownedPets(int $userId): array
{
    $query = db()->prepare('SELECT pets.*, pet_id AS id FROM pets WHERE user_id = :user_id ORDER BY name');
    $query->execute(['user_id' => $userId]);
    return $query->fetchAll();
}

function ownedVaccinations(int $userId): array
{
    $query = db()->prepare(
        "SELECT v.*, v.vaccination_id AS id, v.administration_date AS date_given,
                p.name AS pet_name, p.species, p.breed,
                " . vaccineStatusCaseSql('v') . " AS computed_status
         FROM vaccinations v
         INNER JOIN pets p ON p.pet_id = v.pet_id
         WHERE p.user_id = :user_id
         ORDER BY v.next_due_date ASC, v.administration_date DESC"
    );
    $query->execute(['user_id' => $userId]);
    return $query->fetchAll();
}

function vaccineTypeOptions(): array
{
    $options = ['Core', 'Non-core', 'Booster', 'Other'];
    if (!tableExists('vaccine_types')) {
        return $options;
    }

    $query = db()->prepare(
        "SELECT name FROM vaccine_types
         WHERE name <> '' AND CHAR_LENGTH(name) <= 100
         ORDER BY name ASC"
    );
    $query->execute();
    $catalogOptions = array_map('strval', $query->fetchAll(PDO::FETCH_COLUMN));

    return array_values(array_unique(array_merge($options, $catalogOptions)));
}

function userProfile(int $userId): array
{
    $query = db()->prepare(
        'SELECT user_id, name, email, phone, preferred_clinic, profile_photo, role
         FROM users WHERE user_id = :user_id LIMIT 1'
    );
    $query->execute(['user_id' => $userId]);
    return $query->fetch() ?: [];
}

function notificationPreferences(int $userId): array
{
    $query = db()->prepare(
        'SELECT notifications_enabled FROM settings WHERE user_id = :user_id LIMIT 1'
    );
    $query->execute(['user_id' => $userId]);
    return $query->fetch() ?: ['notifications_enabled' => 1];
}

function userTheme(int $userId): string
{
    $query = db()->prepare('SELECT theme FROM settings WHERE user_id = :user_id LIMIT 1');
    $query->execute(['user_id' => $userId]);
    return (string) ($query->fetchColumn() ?: 'system');
}

function userLanguage(int $userId): string
{
    $query = db()->prepare('SELECT language FROM settings WHERE user_id = :user_id LIMIT 1');
    $query->execute(['user_id' => $userId]);
    return (string) ($query->fetchColumn() ?: 'en-US');
}

configurePetCareRuntime();
