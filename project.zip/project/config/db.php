<?php

declare(strict_types=1);

function db(): PDO
{
    static $connection = null;
    if ($connection instanceof PDO) {
        return $connection;
    }

    $host = getenv('PETCARE_DB_HOST') ?: '127.0.0.1';
    $port = getenv('PETCARE_DB_PORT') ?: '3306';
    $preferredDatabase = getenv('PETCARE_DB_NAME') ?: 'petcare_log';
    $username = getenv('PETCARE_DB_USER') ?: 'root';
    $password = getenv('PETCARE_DB_PASSWORD') ?: '';
    $databaseNames = array_values(array_unique(array_filter([
        $preferredDatabase,
        'petcare_log',
        'petcarelog',
        'petcare_log_app',
    ], fn ($name) => $name !== '')));

    $errors = [];
    foreach ($databaseNames as $database) {
        try {
            $connection = new PDO(
                "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );

            return $connection;
        } catch (PDOException $exception) {
            $errors[] = "{$database}: {$exception->getMessage()}";
        }
    }

    throw new RuntimeException(
        'Unable to connect to a PetCare Log database. Databases tried: '
        . implode('; ', $databaseNames)
        . '. Errors: '
        . implode(' | ', $errors)
    );
}

function tableExists(string $table): bool
{
    static $cache = [];
    if (!array_key_exists($table, $cache)) {
        $statement = db()->prepare(
            'SELECT 1 FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name = :table_name LIMIT 1'
        );
        $statement->execute(['table_name' => $table]);
        $cache[$table] = $statement->fetchColumn() !== false;
    }

    return $cache[$table];
}

function tableHasColumn(string $table, string $column): bool
{
    static $cache = [];
    $key = $table . "\0" . $column;
    if (!array_key_exists($key, $cache)) {
        $statement = db()->prepare(
            'SELECT 1 FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = :table_name
               AND column_name = :column_name LIMIT 1'
        );
        $statement->execute(['table_name' => $table, 'column_name' => $column]);
        $cache[$key] = $statement->fetchColumn() !== false;
    }

    return $cache[$key];
}

function userIdentifierColumn(): string
{
    return tableHasColumn('users', 'id') ? 'id' : 'user_id';
}

function petIdentifierColumn(): string
{
    return tableHasColumn('pets', 'id') ? 'id' : 'pet_id';
}

function vaccinationTableName(): string
{
    return tableExists('vaccinations') ? 'vaccinations' : 'vaccines';
}

function vaccinationDateColumn(): string
{
    $table = vaccinationTableName();
    return tableHasColumn($table, 'administration_date') ? 'administration_date' : 'date_given';
}

function vaccinationPrimaryKeyColumn(): string
{
    $table = vaccinationTableName();
    return tableHasColumn($table, 'id') ? 'id' : 'vaccination_id';
}

function userPasswordColumn(): string
{
    return tableHasColumn('users', 'password_hash') ? 'password_hash' : 'password';
}

function userActiveColumn(): string
{
    return tableHasColumn('users', 'is_active') ? 'is_active' : '1 AS is_active';
}
