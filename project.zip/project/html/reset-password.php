<?php
require_once __DIR__ . '/../config/auth.php';
startPetCareSession();
preventAuthPageCaching();
$token = (string) ($_GET['token'] ?? '');
$validToken = (bool) preg_match('/^[a-f0-9]{64}$/', $token);
?>
<!doctype html>
<html lang="en">
<head>
  <?php include __DIR__ . '/../includes/header.php'; ?>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Choose a new password | PetCare Log</title>
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/fonts.css')); ?>" />
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/material-symbols.css')); ?>" />
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/tailwind.css')); ?>" />
</head>
<body class="flex min-h-screen items-center justify-center px-4 py-8">
  <main class="w-full max-w-lg">
    <div class="petcare-page-toolbar">
      <?php include __DIR__ . '/../includes/theme-toggle.php'; ?>
    </div>
    <div class="rounded-2xl bg-white p-6 shadow-xl sm:p-8">
    <h1 class="mb-3 text-2xl font-bold">Choose a new password</h1>
    <?php if (!$validToken || isset($_GET['error'])): ?>
      <p class="mb-4" role="alert">This reset link is invalid, expired, or was already used. Request a new link to continue.</p>
      <a class="font-semibold text-primary" href="<?php echo escapeHtml(appUrl('/html/forgot-password.php')); ?>">Request another link</a>
    <?php else: ?>
      <form method="post" action="<?php echo escapeHtml(appUrl('/php/reset-password.php')); ?>" class="space-y-4" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
        <input type="hidden" name="token" value="<?php echo escapeHtml($token); ?>" />
        <label class="block text-sm font-semibold">New password (8 to 72 characters)
          <input class="mt-1 w-full rounded-xl border px-4 py-3" type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" readonly onfocus="this.removeAttribute('readonly')" required />
        </label>
        <label class="block text-sm font-semibold">Confirm new password
          <input class="mt-1 w-full rounded-xl border px-4 py-3" type="password" name="confirm_password" minlength="8" maxlength="72" autocomplete="new-password" readonly onfocus="this.removeAttribute('readonly')" required />
        </label>
        <button class="w-full rounded-xl bg-primary px-4 py-3 font-semibold text-white" type="submit">Update password</button>
      </form>
      <script>
        const resetPasswordForm = document.querySelector("form");
        window.addEventListener("pageshow", (event) => {
          if (!resetPasswordForm) return;
          resetPasswordForm.reset();
          resetPasswordForm.querySelectorAll('input[type="password"]').forEach((input) => {
            if (event.persisted) input.blur();
            input.value = "";
            input.readOnly = true;
          });
        });
      </script>
    <?php endif; ?>
    </div>
  </main>
  <?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
