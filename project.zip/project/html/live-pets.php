<?php
$activePage = 'pets';
$pageTitle = 'My Pets';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6 flex flex-wrap items-center justify-between gap-4">
  <div><p class="text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Pet profiles</p><h1 class="mt-2 text-3xl font-bold">My Pets</h1></div>
  <a class="rounded-xl bg-primary px-4 py-2 font-semibold text-white" href="<?php echo escapeHtml(appUrl('/php/addpet.php')); ?>">Add a pet</a>
</header>
<?php if (!empty($_GET['saved'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Pet profile saved.</p><?php endif; ?>
<?php if (!empty($_GET['deleted'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Pet and associated records deleted.</p><?php endif; ?>
<?php if (!empty($_GET['error'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)"><?php echo escapeHtml($_GET['error'] === 'photo' ? 'Photo upload failed. Use a JPG, PNG, or WebP image no larger than 5 MB.' : 'Please review the pet details and try again.'); ?></p><?php endif; ?>
<?php include __DIR__ . '/../includes/pet-management.php'; ?>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
