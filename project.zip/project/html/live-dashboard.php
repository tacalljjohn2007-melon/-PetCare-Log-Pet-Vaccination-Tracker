<?php
$activePage = 'dashboard';
$pageTitle = 'Dashboard';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6 flex flex-wrap items-start justify-between gap-4">
  <div>
    <p class="text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Pet health overview</p>
    <h1 class="mt-2 text-3xl font-bold text-on-surface">Welcome back, <?php echo escapeHtml($user['name'] ?? ''); ?></h1>
    <p class="mt-2 text-on-surface-variant"><?php echo escapeHtml(date('l, F j, Y')); ?> · Your pets and upcoming care.</p>
  </div>
  <div class="flex flex-wrap gap-2">
    <a class="rounded-xl bg-primary px-4 py-2 font-semibold text-white" href="<?php echo escapeHtml(appUrl('/php/addpet.php')); ?>">Add pet</a>
  </div>
</header>
<section class="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3" aria-label="Your pets">
  <?php foreach ($pets as $pet): ?>
    <article class="petcare-card flex items-center gap-4 rounded-2xl p-4 shadow-sm">
      <?php if (!empty($pet['photo'])): ?>
        <img class="h-16 w-16 shrink-0 rounded-xl object-cover" src="<?php echo escapeHtml(appUrl('/' . ltrim($pet['photo'], '/'))); ?>" alt="<?php echo escapeHtml($pet['name']); ?>" />
      <?php else: ?>
        <div class="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-primary text-white" aria-hidden="true"><span class="material-symbols-outlined">pets</span></div>
      <?php endif; ?>
      <div>
        <h2 class="font-bold text-on-surface"><?php echo escapeHtml($pet['name']); ?></h2>
        <p class="text-sm text-on-surface-variant"><?php echo escapeHtml($pet['species']); ?><?php if (!empty($pet['breed'])): ?> · <?php echo escapeHtml($pet['breed']); ?><?php endif; ?></p>
      </div>
    </article>
  <?php endforeach; ?>
</section>
<section class="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Account summary">
  <?php foreach ([
      [
          'label' => 'Total pets',
          'count' => $counts['pets'],
          'href' => appUrl('/php/petprofile.php'),
          'icon' => 'pets',
          'tone' => 'primary',
          'aria_label' => 'View ' . $counts['pets'] . ' ' . ($counts['pets'] === 1 ? 'pet' : 'pets'),
      ],
      [
          'label' => 'Upcoming vaccines',
          'count' => $counts['upcoming'],
          'href' => null,
          'icon' => 'vaccines',
          'tone' => 'secondary',
          'aria_label' => $counts['upcoming'] . ' ' . ($counts['upcoming'] === 1 ? 'vaccine due soon' : 'vaccines due soon'),
      ],
      [
          'label' => 'Overdue vaccines',
          'count' => $counts['overdue'],
          'href' => null,
          'icon' => 'warning',
          'tone' => $counts['overdue'] > 0 ? 'danger' : 'warning',
          'aria_label' => $counts['overdue'] . ' ' . ($counts['overdue'] === 1 ? 'overdue vaccine' : 'overdue vaccines'),
      ],
      [
          'label' => 'All pending reminders',
          'count' => $counts['pending_reminders'],
          'href' => appUrl('/php/reminders.php?status=pending'),
          'icon' => 'notifications_active',
          'tone' => 'primary',
          'aria_label' => 'View ' . $counts['pending_reminders'] . ' ' . ($counts['pending_reminders'] === 1 ? 'pending reminder' : 'pending reminders'),
      ],
  ] as $card): ?>
    <?php if ($card['href'] !== null): ?><a class="petcare-card petcare-summary-link flex min-w-0 items-start justify-between gap-3 rounded-2xl p-5 shadow-sm" href="<?php echo escapeHtml($card['href']); ?>" aria-label="<?php echo escapeHtml($card['aria_label']); ?>"><?php else: ?><div class="petcare-card flex min-w-0 items-start justify-between gap-3 rounded-2xl p-5 shadow-sm" aria-label="<?php echo escapeHtml($card['aria_label']); ?>"><?php endif; ?>
      <div class="min-w-0">
        <h2 class="text-sm font-medium text-on-surface-variant"><?php echo escapeHtml($card['label']); ?></h2>
        <p class="mt-2 text-3xl font-bold text-on-surface"><?php echo (int) $card['count']; ?></p>
      </div>
      <span class="petcare-summary-icon petcare-summary-icon-<?php echo escapeHtml($card['tone']); ?>" aria-hidden="true"><span class="material-symbols-outlined"><?php echo escapeHtml($card['icon']); ?></span></span>
    <?php if ($card['href'] !== null): ?></a><?php else: ?></div><?php endif; ?>
  <?php endforeach; ?>
</section>
<div class="grid gap-6 xl:grid-cols-2">
  <section class="petcare-card rounded-2xl p-5 shadow-sm">
    <div class="mb-4 flex items-center justify-between gap-3">
      <h2 class="text-xl font-bold text-on-surface">Upcoming vaccines</h2>
    </div>
    <?php if (!$upcomingVaccines): ?>
      <p class="text-on-surface-variant">No upcoming vaccines are recorded.</p>
    <?php else: ?>
      <ul class="space-y-3">
        <?php foreach (array_slice($upcomingVaccines, 0, 6) as $vaccine): ?>
          <li class="flex flex-wrap items-center justify-between gap-3 rounded-xl p-3" style="background:var(--bg-card-hover)">
            <span class="font-semibold"><?php echo escapeHtml($vaccine['pet_name'] . ' · ' . $vaccine['vaccine_name']); ?></span>
            <span class="text-sm text-on-surface-variant"><?php echo escapeHtml($vaccine['next_due_date']); ?> · <?php echo escapeHtml(str_replace('_', ' ', $vaccine['computed_status'])); ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
  <section class="petcare-card rounded-2xl p-5 shadow-sm">
    <div class="mb-4 flex items-center justify-between gap-3">
      <h2 class="text-xl font-bold text-on-surface">Reminders due in the next 30 days</h2>
      <a class="font-semibold text-primary hover:underline" href="<?php echo escapeHtml(appUrl('/php/reminders.php')); ?>">Manage</a>
    </div>
    <?php if (!$upcomingReminders): ?>
      <p class="text-on-surface-variant">You have no pending reminders due in the next 30 days.</p>
    <?php else: ?>
      <ul class="space-y-3">
        <?php foreach ($upcomingReminders as $reminder): ?>
          <li class="flex flex-wrap items-center justify-between gap-3 rounded-xl p-3" style="background:var(--bg-card-hover)">
            <span class="font-semibold"><?php echo escapeHtml($reminder['pet_name'] . ' · ' . ($reminder['vaccine_name'] ?? $reminder['message'])); ?></span>
            <span class="text-sm font-medium <?php echo escapeHtml($reminder['remind_date'] < date('Y-m-d') ? 'text-red-700' : 'text-on-surface-variant'); ?>"><?php echo escapeHtml($reminder['remind_date']); ?><?php echo escapeHtml($reminder['remind_date'] < date('Y-m-d') ? ' · Overdue' : ''); ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</div>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
