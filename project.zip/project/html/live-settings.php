<?php
$activePage = 'settings';
$pageTitle = 'Settings';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6">
  <p class="text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Account</p>
  <h1 class="mt-2 text-3xl font-bold">Settings</h1>
</header>
<?php if (!empty($_GET['saved'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Profile updated.</p><?php endif; ?>
<?php if (!empty($_GET['preferences_saved'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Notification preferences saved.</p><?php endif; ?>
<?php if (!empty($_GET['password_saved'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-primary" style="background:var(--success-soft)">Password changed.</p><?php endif; ?>
<?php if (!empty($_GET['password_error'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)">Current password is incorrect or the new password is too short.</p><?php endif; ?>
<?php if (!empty($_GET['error'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)">Please enter a valid name and email address not used by another account.</p><?php endif; ?>
<?php if (!empty($_GET['upload_error'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)">Profile photo upload failed. Use a valid JPG, PNG, or WebP image no larger than 5 MB.</p><?php endif; ?>
<section class="petcare-card mb-6 rounded-2xl p-5 shadow-sm">
  <h2 class="mb-4 text-xl font-bold">Profile</h2>
  <form method="post" enctype="multipart/form-data" action="<?php echo escapeHtml(appUrl('/php/setting.php')); ?>" class="grid gap-4 md:grid-cols-2">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <div class="flex items-center gap-4 md:col-span-2">
      <img class="h-20 w-20 rounded-full object-cover" src="<?php echo escapeHtml(profilePhotoUrl($user['profile_photo'] ?? null)); ?>" alt="<?php echo escapeHtml(($user['name'] ?? 'User') . ' profile photo'); ?>" />
      <label class="text-sm font-semibold">Profile photo (JPG, PNG, WebP; max 5 MB)
        <input class="mt-1 block w-full text-sm" type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp" />
      </label>
    </div>
    <label class="text-sm font-semibold">Name<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="text" name="fullName" maxlength="100" value="<?php echo escapeHtml($user['name'] ?? ''); ?>" required /></label>
    <label class="text-sm font-semibold">Email<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="email" name="email" maxlength="190" value="<?php echo escapeHtml($user['email'] ?? ''); ?>" required /></label>
    <label class="text-sm font-semibold">Phone<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="tel" name="phone" maxlength="30" value="<?php echo escapeHtml($user['phone'] ?? ''); ?>" /></label>
    <label class="text-sm font-semibold">Preferred clinic<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="text" name="clinic" maxlength="150" value="<?php echo escapeHtml($user['preferred_clinic'] ?? ''); ?>" /></label>
    <button class="rounded-xl bg-primary px-4 py-2 font-semibold text-white md:col-span-2 md:justify-self-start" type="submit">Save profile</button>
  </form>
</section>
<section class="petcare-card mb-6 rounded-2xl p-5 shadow-sm">
  <h2 class="mb-2 text-xl font-bold">Notifications</h2>
  <p class="mb-4 text-sm text-on-surface-variant">Choose whether reminders should be enabled for your account.</p>
  <form method="post" action="<?php echo escapeHtml(appUrl('/php/setting.php')); ?>" class="flex flex-wrap items-center gap-4">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <input type="hidden" name="action" value="save_preferences" />
    <label class="inline-flex items-center gap-2 font-medium"><input type="checkbox" name="notifications_enabled" value="1"<?php echo escapeHtml(!empty($preferences['notifications_enabled']) ? ' checked' : ''); ?> /> Enable reminders</label>
    <button class="rounded-xl bg-primary px-4 py-2 font-semibold text-white" type="submit">Save preferences</button>
  </form>
</section>
<?php include __DIR__ . '/../includes/settings-password.php'; ?>
<section class="petcare-card mb-6 rounded-2xl p-5 shadow-sm">
  <h2 class="mb-2 text-xl font-bold">Language</h2>
  <p class="mb-4 text-sm text-on-surface-variant">Choose the language used across your account</p>
  <div class="flex flex-col items-start gap-2">
    <label class="text-sm font-semibold" for="languageSelect">Language</label>
    <select id="languageSelect" class="petcare-field rounded-xl px-3 py-2">
      <option value="en-US">English (US)</option>
      <option value="en-GB">English (UK)</option>
      <option value="es-ES">Español</option>
      <option value="fr-CA">Français (Canada)</option>
      <option value="de-DE">Deutsch</option>
      <option value="tl-PH">Tagalog</option>
    </select>
    <span id="languageSavedMessage" class="text-sm font-semibold text-primary" aria-live="polite" hidden>Language saved</span>
  </div>
</section>
<form method="post" action="<?php echo escapeHtml(appUrl('/logout.php')); ?>" data-logout-form>
  <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
  <button class="inline-flex rounded-xl border px-4 py-2 font-semibold" style="border-color:var(--border)" type="submit">Log out</button>
</form>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
