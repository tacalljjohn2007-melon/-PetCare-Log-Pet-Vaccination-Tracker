<?php
$activePage = 'pets';
$pageTitle = 'Edit Pet';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6">
  <p class="text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Pet profile</p>
  <h1 class="mt-2 text-3xl font-bold">Edit <?php echo escapeHtml($pet['name']); ?></h1>
</header>
<?php if (!empty($_GET['error'])): ?>
  <p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)"><?php echo escapeHtml($_GET['error'] === 'photo' ? 'Photo upload failed. Use a JPG, PNG, or WebP image no larger than 5 MB.' : 'Please review the pet details and try again.'); ?></p>
<?php endif; ?>
<section class="petcare-card max-w-3xl rounded-2xl p-5 shadow-sm">
  <?php if (!empty($pet['photo'])): ?>
    <div class="mb-4">
      <img class="h-24 w-24 rounded-xl object-cover" src="<?php echo escapeHtml(appUrl('/' . ltrim($pet['photo'], '/'))); ?>" alt="<?php echo escapeHtml($pet['name']); ?>" />
      <p class="mt-2 text-sm text-on-surface-variant">Choose a new photo to replace it</p>
    </div>
  <?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="grid gap-4 md:grid-cols-2">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <input type="hidden" name="pet_id" value="<?php echo (int) $pet['id']; ?>" />
    <label class="text-sm font-semibold">Pet name
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="name" maxlength="100" required value="<?php echo escapeHtml($pet['name']); ?>" />
    </label>
    <label class="text-sm font-semibold">Species
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="species" maxlength="50" required value="<?php echo escapeHtml($pet['species']); ?>" />
    </label>
    <label class="text-sm font-semibold">Breed
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="breed" maxlength="100" value="<?php echo escapeHtml($pet['breed'] ?? ''); ?>" />
    </label>
    <label class="text-sm font-semibold">Birthdate
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="date" name="birthdate" value="<?php echo escapeHtml($pet['birthdate'] ?? ''); ?>" />
    </label>
    <label class="text-sm font-semibold">Sex
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="sex" maxlength="30" list="pet-sex-options" value="<?php echo escapeHtml($pet['sex'] ?? ''); ?>" />
      <datalist id="pet-sex-options"><option value="Male"></option><option value="Female"></option><option value="Unknown"></option></datalist>
    </label>
    <label class="text-sm font-semibold">Weight
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="number" name="weight" min="0.1" max="9999" step="0.01" value="<?php echo escapeHtml($pet['weight'] ?? ''); ?>" />
    </label>
    <label class="text-sm font-semibold">Weight unit
      <select class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="weight_unit">
        <option value="lbs"<?php echo escapeHtml(($pet['weight_unit'] ?? 'lbs') === 'lbs' ? ' selected' : ''); ?>>Pounds</option>
        <option value="kg"<?php echo escapeHtml(($pet['weight_unit'] ?? '') === 'kg' ? ' selected' : ''); ?>>Kilograms</option>
      </select>
    </label>
    <label class="text-sm font-semibold">Microchip number
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="microchip_number" maxlength="100" value="<?php echo escapeHtml($pet['microchip_number'] ?? ''); ?>" />
    </label>
    <label class="text-sm font-semibold">Clinic
      <input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="clinic" maxlength="150" value="<?php echo escapeHtml($pet['clinic'] ?? ''); ?>" />
    </label>
    <label class="text-sm font-semibold md:col-span-2">Pet photo (JPG, PNG, WebP; max 5 MB)
      <input class="mt-2 block w-full text-sm" type="file" name="photo" accept="image/jpeg,image/png,image/webp" />
    </label>
    <div class="flex flex-wrap gap-3 md:col-span-2">
      <button class="rounded-xl bg-primary px-4 py-2 font-semibold text-white" type="submit">Save changes</button>
      <a class="rounded-xl border px-4 py-2 font-semibold" style="border-color:var(--border)" href="<?php echo escapeHtml(appUrl('/php/petprofile.php')); ?>">Cancel</a>
    </div>
  </form>
  <form class="mt-4" method="post" action="<?php echo escapeHtml(appUrl('/php/petprofile.php')); ?>" onsubmit="return confirm('Delete this pet and its records?');">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <input type="hidden" name="action" value="delete_pet" />
    <input type="hidden" name="pet_id" value="<?php echo (int) $pet['id']; ?>" />
    <button class="rounded-xl bg-red-600 px-4 py-2 font-semibold text-white" type="submit">Delete pet</button>
  </form>
</section>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
