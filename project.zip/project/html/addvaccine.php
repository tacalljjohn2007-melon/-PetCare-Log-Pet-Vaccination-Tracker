<?php
require_once __DIR__ . '/../config/auth.php';
requireLogin();
if (currentUserRole() === 'admin') {
    redirectToAdminDashboard();
}
redirectToUserDashboard();
