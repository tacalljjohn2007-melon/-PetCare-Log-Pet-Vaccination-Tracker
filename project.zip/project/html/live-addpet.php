<?php
$activePage = 'pets';
$pageTitle = 'Add a Pet';
include __DIR__ . '/../includes/page-start.php';
?>
<header class="mb-6"><p class="text-sm font-semibold uppercase tracking-wider text-on-surface-variant">Pet profile</p><h1 class="mt-2 text-3xl font-bold">Add a Pet</h1></header>
<?php if (!empty($_GET['error'])): ?><p class="mb-4 rounded-xl p-3 font-semibold text-red-700" style="background:var(--danger-soft)"><?php echo escapeHtml($_GET['error'] === 'photo' ? 'Photo upload failed. Use a JPG, PNG, or WebP image no larger than 5 MB.' : 'Please complete the required pet details and try again.'); ?></p><?php endif; ?>
<section class="petcare-card max-w-3xl rounded-2xl p-5 shadow-sm">
  <form method="post" enctype="multipart/form-data" class="grid gap-4 md:grid-cols-2">
    <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
    <label class="text-sm font-semibold">Pet name<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="petName" maxlength="100" required /></label>
    <label class="text-sm font-semibold">Species<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="species" maxlength="50" placeholder="Dog, Cat, Bird..." required /></label>
    <label class="text-sm font-semibold">Breed<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="petBreed" maxlength="100" /></label>
    <label class="text-sm font-semibold">Birthdate<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="date" name="petBirthDate" /></label>
    <label class="text-sm font-semibold">Sex<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="gender" maxlength="30" /></label>
    <label class="text-sm font-semibold">Weight<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" type="number" name="petWeight" min="0.1" max="9999" step="0.01" /></label>
    <label class="text-sm font-semibold">Weight unit<select class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="weightUnit"><option value="lbs">Pounds</option><option value="kg">Kilograms</option></select></label>
    <label class="text-sm font-semibold">Microchip number<input class="petcare-field mt-1 w-full rounded-xl px-3 py-2" name="microchipId" maxlength="100" /></label>
    <label class="text-sm font-semibold md:col-span-2">Pet photo (JPG, PNG, WebP; max 5 MB)<input class="mt-2 block w-full text-sm" type="file" name="photo" accept="image/jpeg,image/png,image/webp" /></label>
    <div class="flex gap-3 md:col-span-2"><button class="rounded-xl bg-primary px-4 py-2 font-semibold text-white" type="submit">Save pet</button><a class="rounded-xl border px-4 py-2 font-semibold" style="border-color:var(--border)" href="<?php echo escapeHtml(appUrl('/php/petprofile.php')); ?>">Cancel</a></div>
  </form>
</section>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
