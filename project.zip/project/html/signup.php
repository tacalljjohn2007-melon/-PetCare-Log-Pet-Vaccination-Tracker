<?php
require_once __DIR__ . '/../config/auth.php';
startPetCareSession();
preventAuthPageCaching();
if (currentUserId() > 0) {
    currentUserRole() === 'admin' ? redirectToAdminDashboard() : redirectToUserDashboard();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Sign Up | PetCare Log</title>
    <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/fonts.css')); ?>" />
    <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/material-symbols.css')); ?>" />
    <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/tailwind.css')); ?>" />
    </head>
  <body class="flex min-h-screen items-center justify-center bg-surface px-4 py-8 font-body text-ink">
    <main class="w-full max-w-lg">
      <div class="petcare-page-toolbar">
        <?php include __DIR__ . '/../includes/theme-toggle.php'; ?>
      </div>
      <div class="rounded-2xl bg-white p-6 shadow-xl sm:p-8">
      <div class="mb-6 text-center">
        <div class="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#dff7ef] text-primary"><span class="material-symbols-outlined text-3xl">pets</span></div>
        <div class="mb-2 inline-flex rounded-full bg-surface-low px-3 py-1 text-xs font-semibold text-primary">Vaccine &amp; Wellness Records</div>
        <h1 class="font-headline text-3xl font-bold">Create your account</h1>
        <p class="mt-2 text-sm text-muted">Start keeping your pets' health records organized.</p>
      </div>
      <div id="formError" class="mb-4 hidden rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700" aria-live="polite"></div>
      <form action="<?php echo escapeHtml(appUrl('/php/signup.php')); ?>" class="space-y-4" method="post" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
        <label class="block text-sm font-semibold" for="fullName">Full Name<input class="mt-1 w-full rounded-xl bg-surface-low px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary" id="fullName" name="full_name" required type="text" /></label>
        <label class="block text-sm font-semibold" for="email">Email Address<input class="mt-1 w-full rounded-xl bg-surface-low px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary" id="email" name="email" autocomplete="off" readonly onfocus="this.removeAttribute('readonly')" required type="email" /></label>
        <label class="block text-sm font-semibold" for="password">Password<input class="mt-1 w-full rounded-xl bg-surface-low px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary" id="password" minlength="8" name="password" autocomplete="new-password" readonly onfocus="this.removeAttribute('readonly')" required type="password" /></label>
        <label class="block text-sm font-semibold" for="confirmPassword">Confirm Password<input class="mt-1 w-full rounded-xl bg-surface-low px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary" id="confirmPassword" minlength="8" name="confirm_password" autocomplete="new-password" readonly onfocus="this.removeAttribute('readonly')" required type="password" /></label>
        <button class="flex w-full items-center justify-center gap-2 rounded-xl bg-primary-container px-4 py-3.5 text-sm font-bold text-white shadow-md transition hover:bg-primary" type="submit">Create Account<span class="material-symbols-outlined text-lg">arrow_forward</span></button>
      </form>
      <p class="mt-6 text-center text-sm text-muted">Already have an account? <a class="font-semibold text-primary hover:underline" href="login.php">Log in</a></p>
      </div>
    </main>
    <script>
      const signupForm = document.querySelector("form");
      window.addEventListener("pageshow", (event) => {
        if (!signupForm) return;
        signupForm.reset();
        signupForm.querySelectorAll('input[type="email"], input[type="password"]').forEach((input) => {
          if (event.persisted) input.blur();
          input.value = "";
          input.readOnly = true;
        });
      });
      const error = new URLSearchParams(window.location.search).get("error");
      const csrfError = new URLSearchParams(window.location.search).get("csrf_error");
      const box = document.getElementById("formError");
      if ((error || csrfError) && box) {
        box.textContent = csrfError ? "Your sign-up form expired. Please try again." : error === "2" ? "An account with this email already exists." : "Enter a name, valid email, matching passwords, and a password with at least 8 characters.";
        box.classList.remove("hidden");
      }
    </script>
  <?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
