<?php
$activePage = 'reminders';
$pageTitle = 'Reminders';
include __DIR__ . '/../includes/page-start.php';
$today = date('Y-m-d');
?>
<div class="flex items-center justify-between pb-6">
  <div>
    <p class="text-sm uppercase tracking-[0.18em] text-on-surface-variant">Alert center</p>
    <h1 class="mt-2 text-3xl font-bold text-on-surface">Reminders Overview</h1>
  </div>
</div>
<?php if ($reminderStatusFilter !== 'all'): ?>
  <p class="petcare-card mb-5 flex flex-wrap items-center gap-x-2 gap-y-1 rounded-xl p-3 text-sm">
    <span>Showing: <?php echo escapeHtml(ucfirst($reminderStatusFilter)); ?> reminders</span>
    <span aria-hidden="true">·</span>
    <a class="font-semibold text-primary underline" href="<?php echo escapeHtml(appUrl('/php/reminders.php')); ?>">Clear filter</a>
  </p>
<?php endif; ?>
<div class="overflow-hidden rounded-2xl border border-[#dfe7f2] bg-[#f9fbff] shadow-sm">
  <table class="min-w-full text-left text-sm">
    <thead class="bg-white text-on-surface-variant">
      <tr>
        <th class="px-4 py-3">Pet</th>
        <th class="px-4 py-3">Vaccine</th>
        <th class="px-4 py-3">Due date</th>
        <th class="px-4 py-3">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($reminders as $reminder):
        $isCompleted = $reminder['status'] === 'completed' || !empty($reminder['is_done']);
        $statusLabel = $isCompleted ? 'Completed' : ($reminder['remind_date'] < $today ? 'Overdue' : 'Upcoming');
      ?>
        <tr class="border-t border-[#e5ebf7]">
          <td class="px-4 py-3 font-medium text-on-surface"><?php echo escapeHtml($reminder['pet_name']); ?></td>
          <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($reminder['vaccine_name'] ?? 'General reminder'); ?></td>
          <td class="px-4 py-3 text-on-surface-variant"><?php echo escapeHtml($reminder['remind_date']); ?></td>
          <td class="px-4 py-3"><span class="rounded-full px-2 py-1 text-xs font-medium <?php echo $statusLabel === 'Overdue' ? 'bg-[#fee2e2] text-red-700' : 'bg-[#dff7ef] text-primary'; ?>"><?php echo escapeHtml($statusLabel); ?></span></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php if (!$reminders): ?>
  <p class="mt-4 text-on-surface-variant">No reminders yet.</p>
<?php endif; ?>
<?php include __DIR__ . '/../includes/page-end.php'; ?>
