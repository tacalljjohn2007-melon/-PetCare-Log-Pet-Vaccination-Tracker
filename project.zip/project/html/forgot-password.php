<?php
require_once __DIR__ . '/../config/auth.php';
startPetCareSession();
preventAuthPageCaching();
?>
<!doctype html>
<html lang="en">
<head>
  <?php include __DIR__ . '/../includes/header.php'; ?>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Forgot password | PetCare Log</title>
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/fonts.css')); ?>" />
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/material-symbols.css')); ?>" />
  <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/tailwind.css')); ?>" />
</head>
<body class="flex min-h-screen items-center justify-center px-4 py-8">
  <main class="w-full max-w-lg">
    <div class="petcare-page-toolbar">
      <?php include __DIR__ . '/../includes/theme-toggle.php'; ?>
    </div>
    <div class="rounded-2xl bg-white p-6 shadow-xl sm:p-8">
    <h1 class="mb-3 text-2xl font-bold">Reset your password</h1>
    <?php if (isset($_GET['sent'])): ?>
      <p class="mb-4">If an active account uses that email, password reset instructions will be sent.</p>
    <?php else: ?>
      <p class="mb-4">Enter your account email. If it matches an active account, we’ll email a reset link.</p>
      <form method="post" action="<?php echo escapeHtml(appUrl('/php/request-password-reset.php')); ?>" class="space-y-4" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
        <label class="block text-sm font-semibold">Email address
          <input class="mt-1 w-full rounded-xl border px-4 py-3" type="email" name="email" maxlength="190" autocomplete="off" readonly onfocus="this.removeAttribute('readonly')" required />
        </label>
        <button class="w-full rounded-xl bg-primary px-4 py-3 font-semibold text-white" type="submit">Send reset link</button>
      </form>
      <script>
        const forgotPasswordForm = document.querySelector("form");
        window.addEventListener("pageshow", (event) => {
          if (!forgotPasswordForm) return;
          forgotPasswordForm.reset();
          const emailInput = forgotPasswordForm.querySelector('input[type="email"]');
          if (emailInput) {
            if (event.persisted) emailInput.blur();
            emailInput.value = "";
            emailInput.readOnly = true;
          }
        });
      </script>
    <?php endif; ?>
    <a class="mt-5 inline-block font-semibold text-primary" href="<?php echo escapeHtml(appUrl('/html/login.php')); ?>">Back to login</a>
    </div>
  </main>
  <?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
