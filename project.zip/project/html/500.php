<?php
require_once __DIR__ . '/../config/auth.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Something went wrong | PetCare Log</title>
</head>
<body>
  <main>
    <h1>We couldn't complete that request</h1>
    <p>An unexpected error occurred. Please try again later.</p>
    <a href="<?php echo escapeHtml(appUrl('/html/login.php')); ?>">Return to PetCare Log</a>
  </main>
</body>
</html>
