<?php
require_once __DIR__ . '/../config/auth.php';
startPetCareSession();
preventAuthPageCaching();
if (currentUserId() > 0) {
    currentUserRole() === 'admin' ? redirectToAdminDashboard() : redirectToUserDashboard();
}
?>
<!doctype html>

<html lang="en">
  <head>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>PetCare Log</title>
    <style>
      @layer base {
        html,
        body {
          margin: 0;
          padding: 0;
        }
        body {
          overscroll-behavior: none;
        }
        main > :first-child {
          margin-top: 0 !important;
        }
        main > :last-child {
          margin-bottom: 0 !important;
        }
      }
      ::-webkit-scrollbar {
        display: none;
      }
    </style>
    <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/fonts.css')); ?>" />
    <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/material-symbols.css')); ?>" />
    <link rel="stylesheet" href="<?php echo escapeHtml(appUrl('/assets/css/tailwind.css')); ?>" />
    </head>
  <body
    class="bg-surface font-body-md text-on-surface antialiased min-h-screen flex items-center justify-center p-margin"
  >
    <main class="w-full max-w-lg mx-auto bg-surface">
      <div class="flex flex-col w-full relative">
        <div
          class="relative w-full rounded-2xl bg-surface-container-lowest shadow-xl overflow-hidden p-6 sm:p-8 flex flex-col"
        >
          <div class="petcare-page-toolbar">
            <?php include __DIR__ . '/../includes/theme-toggle.php'; ?>
          </div>
          <div
            class="absolute -top-16 -right-16 w-48 h-48 bg-primary-fixed/20 rounded-full blur-3xl pointer-events-none"
          ></div>
          <div
            class="absolute -bottom-20 -left-20 w-52 h-52 bg-secondary-fixed/30 rounded-full blur-3xl pointer-events-none"
          ></div>
          <!-- Header Section with Logo and Titles -->
          <div
            class="relative z-10 flex flex-col items-center text-center mb-6"
          >
            <div class="relative mb-3 flex items-center justify-center">
              <div
                class="w-16 h-16 rounded-2xl bg-surface-container-low shadow-sm flex items-center justify-center overflow-hidden p-2"
              >
                <img
                  alt="PetCare Log Icon Logo"
                  class="w-full h-full object-contain"
                  src="<?php echo escapeHtml(appUrl('/assets/img/246e25e2926b.jpg')); ?>"
                />
              </div>
            </div>
            <div
              class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container-low text-primary text-label-sm font-label-sm mb-2 shadow-sm"
            >
              <span
                class="w-1.5 h-1.5 rounded-full bg-primary-container"
              ></span>
              Vaccine &amp; Wellness Records
            </div>
            <h1
              class="font-headline-lg text-headline-lg text-on-surface tracking-tight"
            >
              PetCare Log
            </h1>
          </div>
          <!-- Authentication Form -->
          <form
            class="relative z-10 flex flex-col space-y-4"
            id="loginForm"
            action="<?php echo escapeHtml(appUrl('/php/login.php')); ?>"
            method="post"
            autocomplete="off"
          >
            <input type="hidden" name="csrf_token" value="<?php echo escapeHtml(csrfToken()); ?>" />
            <div
              id="errorMessage"
              class="hidden rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700"
              aria-live="polite"
            >
              Invalid email or password. Please check your details and try again.
            </div>
            <div
              id="successMessage"
              class="hidden rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700"
              aria-live="polite"
            >
              Account created successfully. You can now log in.
            </div>

            <!-- Email Input Field -->
            <div class="flex flex-col space-y-1.5">
              <label
                class="font-label-md text-label-md text-on-surface-variant text-left"
                for="emailInput"
              >
                Email Address
              </label>
              <div class="relative flex items-center">
                <span
                  class="material-symbols-outlined absolute left-3.5 text-on-surface-variant text-headline-sm pointer-events-none select-none"
                >
                  mail
                </span>
                <input
                  class="w-full bg-surface-container-lowest text-on-surface placeholder:text-outline-variant font-body-md text-body-md rounded-xl pl-11 pr-4 py-3 shadow-sm focus:outline-none focus:bg-surface-container-low transition-all duration-150"
                  id="emailInput"
                  name="email"
                  placeholder="name@example.com"
                  autocomplete="off"
                  readonly
                  onfocus="this.removeAttribute('readonly')"
                  required=""
                  type="email"
                />
              </div>
            </div>
            <!-- Password Input Field -->
            <div class="flex flex-col space-y-1.5">
              <div class="flex items-center justify-between">
                <label
                  class="font-label-md text-label-md text-on-surface-variant"
                  for="passwordInput"
                >
                  Password
                </label>
              </div>
              <div class="relative flex items-center">
                <span
                  class="material-symbols-outlined absolute left-3.5 text-on-surface-variant text-headline-sm pointer-events-none select-none"
                >
                  lock
                </span>
                <input
                  class="w-full bg-surface-container-lowest text-on-surface placeholder:text-outline-variant font-body-md text-body-md rounded-xl pl-11 pr-11 py-3 shadow-sm focus:outline-none focus:bg-surface-container-low transition-all duration-150"
                  id="passwordInput"
                  name="password"
                  placeholder="••••••••"
                  autocomplete="new-password"
                  readonly
                  onfocus="this.removeAttribute('readonly')"
                  required=""
                  type="password"
                />
                <button
                  aria-label="Toggle password visibility"
                  class="absolute right-3.5 text-on-surface-variant hover:text-on-surface p-1 rounded-lg flex items-center justify-center transition-colors"
                  id="togglePasswordBtn"
                  type="button"
                >
                  <span
                    class="material-symbols-outlined text-headline-sm"
                    id="passwordEyeIcon"
                    >visibility</span
                  >
                </button>
              </div>
            </div>
            <div class="flex items-center justify-between pt-1">
              <span
                class="font-label-sm text-label-sm text-on-surface-variant flex items-center gap-1"
              >
                <span
                  class="material-symbols-outlined text-label-sm text-primary"
                  >verified_user</span
                >
                Encrypted session
              </span>
            </div>
            <!-- Submit Button -->
            <button
              class="w-full mt-2 bg-primary-container hover:bg-primary text-on-primary font-label-lg text-label-lg py-3.5 px-4 rounded-xl shadow-md active:scale-[0.99] transition-all duration-150 flex items-center justify-center gap-2"
              id="submitBtn"
              type="submit"
            >
              <span>Log In to PetCare Log</span>
              <span class="material-symbols-outlined text-headline-sm"
                >arrow_forward</span
              >
            </button>
          </form>
          <!-- Sign Up Callout -->
          <div
            class="relative z-10 mt-6 pt-5 bg-surface-container-lowest flex flex-col sm:flex-row items-center justify-center gap-1 text-center font-body-md text-body-md text-on-surface-variant"
          >
            <span>New to tracking pet immunizations?</span>
            <a
              class="text-primary font-label-lg text-label-lg hover:underline inline-flex items-center gap-0.5"
              href="signup.php"
            >
              <span>Sign up for free</span>
              <span class="material-symbols-outlined text-label-sm"
                >chevron_right</span
              >
            </a>
          </div>
        </div>
      </div>
      <script>
        // Password Visibility Toggle
        const toggleBtn = document.getElementById("togglePasswordBtn");
        const passwordInput = document.getElementById("passwordInput");
        const passwordIcon = document.getElementById("passwordEyeIcon");

        if (toggleBtn && passwordInput && passwordIcon) {
          toggleBtn.addEventListener("click", () => {
            const isPassword = passwordInput.type === "password";
            passwordInput.type = isPassword ? "text" : "password";
            passwordIcon.textContent = isPassword
              ? "visibility_off"
              : "visibility";
          });
        }

        const emailInput = document.getElementById("emailInput");
        const loginForm = document.getElementById("loginForm");
        const clearLoginFields = (event) => {
          if (loginForm) loginForm.reset();
          [emailInput, passwordInput].forEach((input) => {
            if (!input) return;
            if (event?.persisted) input.blur();
            input.value = "";
            input.readOnly = true;
          });
        };
        window.addEventListener("pageshow", clearLoginFields);

        const urlParams = new URLSearchParams(window.location.search);
        const errorBox = document.getElementById("errorMessage");
        const successBox = document.getElementById("successMessage");

        if ((urlParams.get("error") === "1" || urlParams.get("csrf_error") === "1") && errorBox) {
          clearLoginFields();
          errorBox.classList.remove("hidden");
          if (urlParams.get("csrf_error") === "1") {
            errorBox.textContent = "Your sign-in form expired. Please enter your details and try again.";
          }
        }
        if (urlParams.get("registered") === "1" && successBox) {
          successBox.classList.remove("hidden");
        }
      </script>
    </main>
  <?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
